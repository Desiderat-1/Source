package porttests;

import com.kyanite.deeperdarker.client.render.DDCrystalTrail;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public final class FullClientSmoke implements ClientModInitializer {
    private boolean done;
    private int ticks;
    public void onInitializeClient(){
        var type=DDCrystalTrail.TYPE;
        if(Boolean.getBoolean("fabric.client.gametest"))return;
        ClientTickEvents.END_CLIENT_TICK.register(client->{
            if(done)return;
            if(++ticks>1200)throw new AssertionError("Full client resource load timed out");
            if(client.gui.overlay()!=null||client.gui.screen()==null||ticks<3)return;
            var pipeline=RenderSystem.getCompiledPipeline(DDCrystalTrail.PIPELINE);
            if(pipeline==null||pipeline.isClosed()||type.pipeline()!=DDCrystalTrail.PIPELINE)throw new AssertionError("Crystal pipeline failed");
            done=true;
            System.out.println("FULL_CLIENT_STARTUP_PASSED: complete mod client entrypoint, initial resource reload and GPU shader compilation");
            client.stop();
        });
    }
}
