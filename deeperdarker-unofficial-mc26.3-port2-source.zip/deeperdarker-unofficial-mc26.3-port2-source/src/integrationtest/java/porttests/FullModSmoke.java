package porttests;

import com.google.gson.JsonParser;
import com.kyanite.deeperdarker.content.DDBlocks;
import com.kyanite.deeperdarker.world.otherside.gen.OthersideGeneration;
import net.fabricmc.fabric.api.gametest.v1.GameTest;
import net.minecraft.core.registries.Registries;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.Registry;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public final class FullModSmoke {
    private static final com.google.gson.JsonObject MANIFEST;
    static {
        var stream=FullModSmoke.class.getResourceAsStream("/runtime-data-manifest.json");
        if(stream==null)throw new AssertionError("Runtime manifest missing; run tools/migrate-runtime-data.py");
        try(var reader=new InputStreamReader(stream,StandardCharsets.UTF_8)){
            MANIFEST=JsonParser.parseReader(reader).getAsJsonObject();
        }catch(java.io.IOException e){throw new AssertionError(e);}
    }
    private static <T> void checkRegistry(HolderLookup.Provider access, ResourceKey<Registry<T>> registry, String directory){
        var entries=access.lookupOrThrow(registry);
        for(var json:MANIFEST.getAsJsonArray(directory)){
            var id=Identifier.parse(json.getAsString());
            if(entries.get(ResourceKey.create(registry,id)).isEmpty())throw new AssertionError("Resource missing: "+directory+"/"+id);
        }
    }
    @GameTest(maxTicks=400)
    public void allRuntimeDataAndStructures(GameTestHelper helper){
        var server=helper.getLevel().getServer();
        var world=server.registryAccess();
        checkRegistry(world,Registries.BIOME,"worldgen/biome");
        checkRegistry(world,Registries.FEATURE,"worldgen/feature");
        checkRegistry(world,Registries.PLACED_FEATURE,"worldgen/placed_feature");
        checkRegistry(world,Registries.STRUCTURE,"worldgen/structure");
        checkRegistry(server.reloadableRegistries().lookup(),Registries.LOOT_TABLE,"loot_table");
        checkRegistry(server.reloadableRegistries().lookup(),Registries.ADVANCEMENT,"advancement");
        for(var json:MANIFEST.getAsJsonArray("recipe")){
            var key=ResourceKey.create(Registries.RECIPE,Identifier.parse(json.getAsString()));
            if(server.getRecipeManager().byKey(key).isEmpty())throw new AssertionError("Recipe missing: "+key);
        }
        int count=0;
        for(var json:MANIFEST.getAsJsonArray("structure_nbt")){
            var id=Identifier.parse(json.getAsString());
            var template=helper.getLevel().getStructureTemplateManager().get(id).orElseThrow(()->new AssertionError("Structure template missing: "+id));
            if(template.getSize().getX()<=0)throw new AssertionError("Structure empty: "+id);
            count++;
        }
        System.out.println("FULL_MOD_DATA_PASSED: every expected runtime resource plus "+count+" real structure templates loaded");
        helper.succeed();
    }
    @GameTest(maxTicks=600)
    public void othersideChunksAndShears(GameTestHelper helper){
        var level=helper.getLevel().getServer().getLevel(com.kyanite.deeperdarker.world.otherside.OthersideDimension.OTHERSIDE_LEVEL);
        if(level==null)throw new AssertionError("Otherside dimension missing");
        if(level.getMinY()!=0||level.getHeight()!=128)throw new AssertionError("Otherside height changed");
        // Real terrain, carvers, biome decoration and structure generation.
        for(var pos:new int[][]{{0,0},{-8,5},{32,-24}}){
            var chunk=level.getChunk(pos[0],pos[1]);
            if(chunk.isEmpty())throw new AssertionError("Otherside chunk empty");
        }
        var shears=new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.SHEARS);
        if(shears.getDestroySpeed(DDBlocks.SCULK_TISSUE.defaultBlockState())!=5.0F)throw new AssertionError("Shears no longer cut tissue at original speed");
        System.out.println("OTHERSIDE_CHUNKS_PASSED: real 128-block terrain generation at three positive/negative chunk positions");
        helper.succeed();
    }
    @GameTest
    public void everyRegisteredBlockEntity(GameTestHelper helper){
        int count=0;
        var access=helper.getLevel().registryAccess();
        for(var block:net.minecraft.core.registries.BuiltInRegistries.BLOCK){
            var id=net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(block);
            if(!id.getNamespace().equals("deeperdarker")||!(block instanceof net.minecraft.world.level.block.EntityBlock factory))continue;
            var state=block.defaultBlockState();
            var pos=new net.minecraft.core.BlockPos(1,2,1);
            var entity=factory.newBlockEntity(pos,state);
            if(entity==null||!entity.isValidBlockState(state)||!entity.getType().isValid(state))throw new AssertionError("Invalid custom block entity: "+id);
            var saved=entity.saveWithFullMetadata(access);
            var restored=net.minecraft.world.level.block.entity.BlockEntity.loadStatic(pos,state,saved,access);
            if(restored==null||restored.getType()!=entity.getType())throw new AssertionError("Custom block entity save/load changed type: "+id);
            count++;
        }
        System.out.println("ALL_BLOCK_ENTITIES_PASSED: "+count+" registered mod blocks construct and save/load their actual custom entity types");
        helper.succeed();
    }
    @GameTest(maxTicks=200)
    public void actualOthersidePortal(GameTestHelper helper){
        var overworld=helper.getLevel();
        var otherside=overworld.getServer().getLevel(com.kyanite.deeperdarker.world.otherside.OthersideDimension.OTHERSIDE_LEVEL);
        var entry=new net.minecraft.core.BlockPos(64,80,64);
        var exit=new net.minecraft.core.BlockPos(64,80,64);
        overworld.setChunkForced(4,4,true);otherside.setChunkForced(4,4,true);
        portalFrame(overworld,entry);portalFrame(otherside,exit);
        for(var level:java.util.List.of(overworld,otherside)){
            dev.kyanitemods.kyaniteportals.content.registry.PortalTriggers.USE_ITEM.trigger(level,entry,null,
                new net.minecraft.world.item.ItemStack(com.kyanite.deeperdarker.content.DDItems.HEART_OF_THE_DEEP));
            if(!(level.getBlockEntity(entry) instanceof dev.kyanitemods.kyaniteportals.content.blocks.entities.CustomPortalBlockEntity entity)
                ||!entity.getPortalKey().equals(com.kyanite.deeperdarker.DeeperDarker.OTHERSIDE_PORTAL))throw new AssertionError("Actual Heart of the Deep portal ignition failed");
        }
        var cow=net.minecraft.world.entity.EntityTypes.COW.create(overworld,net.minecraft.world.entity.EntitySpawnReason.COMMAND);
        cow.setNoAi(true);cow.setNoGravity(true);cow.setPos(net.minecraft.world.phys.Vec3.atBottomCenterOf(entry));
        overworld.addFreshEntity(cow);var uuid=cow.getUUID();
        helper.runAfterDelay(60,()->{
            var arrived=otherside.getEntity(uuid);
            if(arrived==null){
                var portalState=(dev.kyanitemods.kyaniteportals.content.interfaces.EntityInPortal)cow;
                throw new AssertionError("Portal collision travel failed: entityTicks="+cow.tickCount+", inside="+portalState.isInsidePortal()+", portalTicks="+portalState.getTimeInPortal()+", tickingChunk="+overworld.areEntitiesActuallyLoadedAndTicking(new net.minecraft.world.level.ChunkPos(4,4)));
            }
            arrived.setPos(net.minecraft.world.phys.Vec3.atBottomCenterOf(exit));arrived.setPortalCooldown(0);
            var portal=otherside.registryAccess().lookupOrThrow(dev.kyanitemods.kyaniteportals.KyanitePortals.RESOURCE_KEY)
                .getOrThrow(com.kyanite.deeperdarker.DeeperDarker.OTHERSIDE_PORTAL).value();
            dev.kyanitemods.kyaniteportals.content.Portal.executeAll(otherside,exit,arrived,portal.travelActions());
            if(overworld.getEntity(uuid)==null)throw new AssertionError("Actual portal's return actions did not return to Overworld");
            overworld.getEntity(uuid).discard();
            overworld.setChunkForced(4,4,false);otherside.setChunkForced(4,4,false);
            System.out.println("OTHERSIDE_PORTAL_PASSED: real reinforced-deepslate frames, Heart ignition, automatic collision travel to Otherside, return travel actions");
            helper.succeed();
        });
    }
    private static void portalFrame(net.minecraft.server.level.ServerLevel level,net.minecraft.core.BlockPos origin){
        for(int x=-1;x<=2;x++)for(int y=-1;y<=3;y++)level.setBlock(origin.offset(x,y,0),
            (x==-1||x==2||y==-1||y==3?net.minecraft.world.level.block.Blocks.REINFORCED_DEEPSLATE:net.minecraft.world.level.block.Blocks.AIR).defaultBlockState(),3);
    }
}
