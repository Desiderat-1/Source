package porttests;

import com.kyanite.deeperdarker.world.otherside.OthersideDimension;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;

/** A real integrated world, actual player connection, chunk rendering and custom entities. */
public final class FullWorldClientSmoke implements FabricClientGameTest {
    public void runTest(ClientGameTestContext context){
        System.out.println("F11_REGRESSION_START");
        context.waitTicks(60);
        context.runOnClient(client->{
            client.options.exclusiveFullscreen().set(false);
            client.getWindow().setExclusiveFullscreen(false);
        });
        verifyFullscreenSwitches(context, "TITLE", 2);
        try(var world=context.worldBuilder().adjustSettings(settings->settings.setSeed("-6459362312905392282")).create()){
            var server=world.getServer();
            server.runOnServer(instance->{
                if(instance.getLevel(OthersideDimension.OTHERSIDE_LEVEL)==null)throw new AssertionError("Otherside missing from a normally created integrated world");
                var level=instance.getLevel(OthersideDimension.OTHERSIDE_LEVEL);
                System.out.println("FLOES_CRASH_REGION_START: seed="+level.getSeed()+", chunk=-24,-7");
                for(int x=-25;x<=-23;x++)for(int z=-8;z<=-6;z++)level.getChunk(x,z);
                int basalt=0;
                for(int x=-400;x<-352;x++)for(int z=-128;z<-80;z++)for(int y=0;y<64;y++){
                    if(level.getBlockState(new net.minecraft.core.BlockPos(x,y,z)).is(com.kyanite.deeperdarker.content.DDBlocks.SCULK_BASALT))basalt++;
                }
                if(basalt==0)throw new AssertionError("Regression region no longer generates its acid floes");
                System.out.println("FLOES_CRASH_REGION_PASSED: nine real decorated chunks at reported crash location, basalt="+basalt);
                for(int x=-1;x<=0;x++)for(int z=-1;z<=0;z++)level.setChunkForced(x,z,true);
            });
            server.waitFor(instance->{
                var level=instance.getLevel(OthersideDimension.OTHERSIDE_LEVEL);
                return level.hasChunkAt(new net.minecraft.core.BlockPos(-10,88,-10))&&level.hasChunkAt(new net.minecraft.core.BlockPos(10,88,10))
                    &&level.hasChunkAt(new net.minecraft.core.BlockPos(-10,88,10))&&level.hasChunkAt(new net.minecraft.core.BlockPos(10,88,-10));
            },1200);
            server.runCommand("gamemode creative @a");
            server.runCommand("execute in deeperdarker:otherside run tp @a -376 95 -104 0 55");
            world.getConnection().waitForChunksRender();
            context.waitTicks(20);
            context.takeScreenshot("acid-floes-crash-region");
            System.out.println("FLOES_CLIENT_VISIT_PASSED: player entered Otherside and rendered reported crash region");
            server.runCommand("execute in deeperdarker:otherside run fill -10 88 -10 10 88 10 deeperdarker:sculk_stone");
            server.runCommand("execute in deeperdarker:otherside run fill -10 89 -10 10 100 10 air");
            server.runCommand("execute in deeperdarker:otherside run fill -5 88 -5 5 88 5 deeperdarker:sculk_gleam");
            server.runCommand("execute in deeperdarker:otherside run tp @a 0 89 7 180 10");
            world.getConnection().waitForChunksRender();
            verifyFullscreenSwitches(context, "OTHERSIDE", 4);
            context.waitTicks(20);
            server.runOnServer(instance->{
                var level=instance.getLevel(OthersideDimension.OTHERSIDE_LEVEL);
                var p=new net.minecraft.core.BlockPos(0,89,0);
                if(!level.getBlockState(p.below()).is(com.kyanite.deeperdarker.content.DDBlocks.SCULK_GLEAM))throw new AssertionError("Test light platform did not place");
                if(level.getBrightness(net.minecraft.world.level.LightLayer.BLOCK,p)<9)throw new AssertionError("Sculk light sources no longer illuminate Otherside");
                System.out.println("OTHERSIDE_SERVER_LIGHT: "+level.getBrightness(net.minecraft.world.level.LightLayer.BLOCK,p));
            });
            context.runOnClient(client->{
                var p=new net.minecraft.core.BlockPos(0,89,0);
                System.out.println("OTHERSIDE_CLIENT_LIGHT: "+client.level.getBrightness(net.minecraft.world.level.LightLayer.BLOCK,p));
            });
            server.runCommand("execute in deeperdarker:otherside run setblock -3 89 0 deeperdarker:dead_mans_chest");
            server.runCommand("execute in deeperdarker:otherside run setblock 0 89 0 deeperdarker:crystallized_amber");
            server.runCommand("execute in deeperdarker:otherside run setblock 3 89 0 deeperdarker:shattered_head");
            server.runOnServer(instance->{
                var level=instance.getLevel(OthersideDimension.OTHERSIDE_LEVEL);
                if(!(level.getBlockEntity(new net.minecraft.core.BlockPos(3,89,0)) instanceof com.kyanite.deeperdarker.content.entities.blocks.DDSkullBlockEntity))throw new AssertionError("Shattered head failed to place");
            });
            for(String name:new String[]{"sculk_leech","angler_fish","sludge","overseer_crystal","overseer","overcast_vessel"}){
                server.runCommand("execute in deeperdarker:otherside run summon deeperdarker:"+name+" 0 92 -3 {NoAI:1b}");
                server.runOnServer(instance->{
                    var level=instance.getLevel(OthersideDimension.OTHERSIDE_LEVEL);
                    var type=net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getValue(net.minecraft.resources.Identifier.fromNamespaceAndPath("deeperdarker",name));
                    if(level.getEntities(type,new net.minecraft.world.phys.AABB(-2,89,-5,2,99,-1),entity->true).isEmpty())throw new AssertionError("Custom entity failed to spawn: "+name);
                });
                world.getConnection().waitForClientboundPackets();
                context.waitTicks(5);
                server.runCommand("execute in deeperdarker:otherside run kill @e[type=deeperdarker:"+name+"]");
            }
            context.waitTicks(20);
            context.takeScreenshot("otherside-full-port");
            context.runOnClient(client->client.options.setCameraType(net.minecraft.client.CameraType.THIRD_PERSON_BACK));
            server.runCommand("item replace entity @a armor.head with deeperdarker:warden_helmet[deeperdarker:has_horns=true]");
            server.runCommand("item replace entity @a armor.chest with deeperdarker:soul_elytra");
            world.getConnection().waitForClientboundPackets();context.waitTicks(10);
            context.takeScreenshot("otherside-horns-and-wings");
            server.runCommand("item replace entity @a armor.head with deeperdarker:sunglasses");
            world.getConnection().waitForClientboundPackets();context.waitTicks(10);
            context.takeScreenshot("otherside-sunglasses");
            context.runOnClient(client->client.options.setCameraType(net.minecraft.client.CameraType.FIRST_PERSON));
            // First-person eye overlay must also survive an actual acid immersion.
            server.runCommand("execute in deeperdarker:otherside run fill -1 89 5 1 92 7 deeperdarker:acid");
            server.runCommand("execute in deeperdarker:otherside run tp @a 0 89 6 180 0");
            world.getConnection().waitForClientboundPackets();
            context.waitTicks(15);
            context.takeScreenshot("otherside-acid-overlay");
            System.out.println("FULL_WORLD_CLIENT_PASSED: actual Otherside player connection, rendered chunks, custom block/entity renderers and acid immersion");
        }
    }

    private static void verifyFullscreenSwitches(ClientGameTestContext context, String location, int count){
        for(int cycle=0;cycle<count;cycle++){
            boolean[] before = new boolean[1];
            context.runOnClient(client->before[0]=client.options.fullscreen().get());
            System.out.println("F11_"+location+"_PRESS: previous="+before[0]);
            context.getInput().pressKey(com.mojang.blaze3d.platform.InputConstants.KEY_F11);
            context.waitTicks(15);
            context.runOnClient(client->{
                var window=client.getWindow();
                if(client.options.fullscreen().get()==before[0])throw new AssertionError("F11 did not toggle fullscreen at "+location);
                if(window.isExclusiveFullscreen())throw new AssertionError("Borderless fullscreen workaround was not active");
                if(window.getWidth()<=0||window.getHeight()<=0)throw new AssertionError("Fullscreen resize left an invalid framebuffer");
                System.out.println("F11_"+location+"_VERIFIED: fullscreen="+client.options.fullscreen().get()+", framebuffer="+window.getWidth()+"x"+window.getHeight());
            });
        }
    }
}
