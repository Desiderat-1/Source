// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.client.model;

import com.kyanite.deeperdarker.client.state.DDModelRenderState;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.animation.AnimationDefinition;
import net.minecraft.client.animation.KeyframeAnimation;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.world.entity.AnimationState;
import net.minecraft.world.entity.Entity;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

/** Keeps the original animation algorithms in the extraction phase of 26.3 rendering. */
public abstract class DDHierarchicalModel<T extends Entity> extends EntityModel<DDModelRenderState> {
    private final List<ModelPart> parts;
    private final Map<AnimationDefinition, KeyframeAnimation> animations = new IdentityHashMap<>();
    protected DDHierarchicalModel(ModelPart root) { super(root); parts = List.copyOf(root.getAllParts()); }
    protected DDHierarchicalModel(ModelPart root, java.util.function.Function<net.minecraft.resources.Identifier,
            net.minecraft.client.renderer.rendertype.RenderType> renderType) {
        super(root, renderType);
        parts = List.copyOf(root.getAllParts());
    }
    public abstract void setupAnim(T entity, float swing, float swingAmount, float age, float headYaw, float headPitch);
    public final synchronized List<DDModelRenderState.Part> capturePose(T entity, DDModelRenderState state) {
        parts.forEach(ModelPart::resetPose);
        setupAnim(entity, state.walkAnimationPos, state.walkAnimationSpeed, state.ageInTicks, state.yRot, state.xRot);
        return parts.stream().map(p -> new DDModelRenderState.Part(p.storePose(), p.visible, p.skipDraw)).toList();
    }
    @Override public void setupAnim(DDModelRenderState state) {
        super.setupAnim(state);
        if (state.parts.isEmpty()) return;
        if (state.parts.size() != parts.size()) throw new IllegalArgumentException("Render-state model geometry mismatch");
        for (int i = 0; i < parts.size(); i++) {
            ModelPart part = parts.get(i); var saved = state.parts.get(i);
            part.loadPose(saved.pose()); part.visible = saved.visible(); part.skipDraw = saved.skipDraw();
        }
    }
    protected final void animateWalk(AnimationDefinition definition, float position, float speed, float scale, float multiplier) {
        animation(definition).applyWalk(position, speed, scale, multiplier);
    }
    protected final void animate(AnimationState state, AnimationDefinition definition, float age) { animation(definition).apply(state, age); }
    protected final void animate(AnimationState state, AnimationDefinition definition, float age, float scale) { animation(definition).apply(state, age, scale); }
    private KeyframeAnimation animation(AnimationDefinition definition) { return animations.computeIfAbsent(definition, d -> d.bake(root())); }
    public void renderToBuffer(PoseStack poses, VertexConsumer consumer, int light, int overlay, float red, float green, float blue, float alpha) {
        renderToBuffer(poses, consumer, light, overlay, net.minecraft.util.ARGB.colorFromFloat(alpha, red, green, blue));
    }
}
