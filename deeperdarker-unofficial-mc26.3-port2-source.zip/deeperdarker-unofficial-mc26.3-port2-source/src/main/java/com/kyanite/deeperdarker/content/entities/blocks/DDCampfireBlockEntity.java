package com.kyanite.deeperdarker.content.entities.blocks;

import com.kyanite.deeperdarker.content.DDBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.CampfireBlockEntity;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.NotNull;

public class DDCampfireBlockEntity extends CampfireBlockEntity {
    private final net.minecraft.world.item.crafting.RecipeManager.CachedCheck<net.minecraft.world.item.crafting.SingleRecipeInput, net.minecraft.world.item.crafting.CampfireCookingRecipe> cookingCheck =
            net.minecraft.world.item.crafting.RecipeManager.createCheck(net.minecraft.world.item.crafting.RecipeType.CAMPFIRE_COOKING);
    public DDCampfireBlockEntity(BlockPos pPos, BlockState pBlockState) {
        super(pPos, pBlockState);
    }

    @Override public boolean isValidBlockState(BlockState state) { return getType().isValid(state); }

    @Override
    public @NotNull BlockEntityType<?> getType() {
        return DDBlockEntities.CAMPFIRE;
    }

    public static void cookTick(net.minecraft.world.level.Level level, BlockPos pos, BlockState state, DDCampfireBlockEntity campfire) {
        if (level instanceof net.minecraft.server.level.ServerLevel server)
            CampfireBlockEntity.cookTick(server, pos, state, campfire, campfire.cookingCheck);
    }
}
