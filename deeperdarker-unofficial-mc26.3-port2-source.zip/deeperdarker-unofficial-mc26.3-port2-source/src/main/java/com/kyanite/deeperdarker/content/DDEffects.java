// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.content;


import com.kyanite.deeperdarker.content.entities.DDMobType;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import org.jetbrains.annotations.Nullable;

public class DDEffects {
    public static final net.minecraft.core.Holder<MobEffect> SCULK_AFFINITY = register("sculk_affinity", new MobEffect(MobEffectCategory.BENEFICIAL, 0x00ffd0) {
        @Override
        public boolean shouldApplyEffectTickThisTick(int pDuration, int pAmplifier) {
            return true;
        }
    });

    public static final net.minecraft.core.Holder<MobEffect> HEMOPHILIA = register("hemophilia", new MobEffect(MobEffectCategory.HARMFUL, 0x63030a) {});

    public static final net.minecraft.core.Holder<MobEffect> CORRUPTION = register("corruption", new InstantaneousMobEffect(MobEffectCategory.HARMFUL, 0x0d031a) {
        @Override
        public boolean applyEffectTick(net.minecraft.server.level.ServerLevel server, LivingEntity livingEntity, int i) {
            boolean converted = SculkConversionRegistry.corruptionConversion(livingEntity);
            if (!converted) {
                if (DDMobType.isSculk(livingEntity)) {
                    livingEntity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 260, 1));
                } else {
                    livingEntity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 260, 0));
                    livingEntity.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 0));
                }
            }
            return true;
        }

        @Override
        public void applyInstantaneousEffect(net.minecraft.server.level.ServerLevel server, @Nullable Entity entity, @Nullable Entity entity2, LivingEntity livingEntity, int i, double d) {
            boolean converted = SculkConversionRegistry.corruptionConversion(livingEntity);
            if (!converted) {
                if (DDMobType.isSculk(livingEntity)) {
                    livingEntity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 260, 1));
                } else {
                    livingEntity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 260, 0));
                    livingEntity.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 0));
                }
            }
        }
    });
    public static final net.minecraft.core.Holder<MobEffect> PURITY = register("purity", new InstantaneousMobEffect(MobEffectCategory.BENEFICIAL, 0x42cf67) {
        @Override
        public boolean applyEffectTick(net.minecraft.server.level.ServerLevel server, LivingEntity livingEntity, int i) {
            boolean converted = SculkConversionRegistry.corruptionConversion(livingEntity);
            if (!converted) {
                if (DDMobType.isSculk(livingEntity)) {
                    livingEntity.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 0));
                    livingEntity.addEffect(new MobEffectInstance(MobEffects.INSTANT_DAMAGE, 1, 6));
                } else {
                    livingEntity.removeEffect(MobEffects.DARKNESS);
                    livingEntity.removeEffect(MobEffects.WITHER);
                }
            }
            return true;
        }

        @Override
        public void applyInstantaneousEffect(net.minecraft.server.level.ServerLevel server, @Nullable Entity entity, @Nullable Entity entity2, LivingEntity livingEntity, int i, double d) {
            boolean converted = SculkConversionRegistry.purityConversion(livingEntity);
            if (!converted) {
                if (DDMobType.isSculk(livingEntity)) {
                    livingEntity.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 0));
                    livingEntity.addEffect(new MobEffectInstance(MobEffects.INSTANT_DAMAGE, 1, 8));
                } else {
                    livingEntity.removeEffect(MobEffects.DARKNESS);
                    livingEntity.removeEffect(MobEffects.WITHER);
                }
            }
        }
    });

    private static net.minecraft.core.Holder<MobEffect> register(String id, MobEffect mobEffect) {
        return Registry.registerForHolder(BuiltInRegistries.MOB_EFFECT, Identifier.fromNamespaceAndPath("deeperdarker", id), mobEffect);
    }

    public static void init() {
        org.slf4j.LoggerFactory.getLogger("deeperdarker").debug("Registering effects");
    }
}

