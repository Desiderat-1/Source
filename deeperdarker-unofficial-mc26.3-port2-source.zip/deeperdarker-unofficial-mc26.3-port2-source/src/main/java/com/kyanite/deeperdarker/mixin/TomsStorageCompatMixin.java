package com.kyanite.deeperdarker.mixin;

import com.kyanite.deeperdarker.content.items.SculkTransmitterItem;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Pseudo
@Mixin(targets = "com.tom.storagemod.block.entity.StorageTerminalBlockEntity", remap = false)
public abstract class TomsStorageCompatMixin {
    @Inject(method = "canInteractWith", at = @At("HEAD"), cancellable = true, remap = false)
    private void deeperdarker$tomsStorageCompat(Player player, boolean remote, CallbackInfoReturnable<Boolean> cir) {
        if (((BlockEntity) (Object) this).getLevel() instanceof ServerLevel serverLevel && SculkTransmitterItem.stillValid(player, serverLevel, ((BlockEntity) (Object) this).getBlockPos())) {
            cir.setReturnValue(true);
            cir.cancel();
        }
    }
}
