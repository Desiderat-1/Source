// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.client.item;

import com.kyanite.deeperdarker.content.components.DDItemProperties;
import com.kyanite.deeperdarker.content.components.TransmitterLink;
import com.kyanite.deeperdarker.mixin.ConditionalItemModelPropertiesAccessor;
import com.mojang.serialization.MapCodec;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.item.properties.conditional.ConditionalItemModelProperty;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

public final class DDItemModelProperties {
    public record Linked() implements ConditionalItemModelProperty {
        public static final MapCodec<Linked> CODEC = MapCodec.unit(Linked::new);
        @Override public MapCodec<Linked> type() { return CODEC; }
        @Override public boolean get(ItemStack stack, ClientLevel level, LivingEntity entity, int seed, ItemDisplayContext context) {
            return TransmitterLink.read(stack).isPresent();
        }
    }
    public record HasHorns() implements ConditionalItemModelProperty {
        public static final MapCodec<HasHorns> CODEC = MapCodec.unit(HasHorns::new);
        @Override public MapCodec<HasHorns> type() { return CODEC; }
        @Override public boolean get(ItemStack stack, ClientLevel level, LivingEntity entity, int seed, ItemDisplayContext context) {
            return DDItemProperties.hasHorns(stack);
        }
    }
    public static void init() {
        var properties = ConditionalItemModelPropertiesAccessor.deeperdarker$properties();
        properties.put(Identifier.fromNamespaceAndPath("deeperdarker", "linked"), Linked.CODEC);
        properties.put(Identifier.fromNamespaceAndPath("deeperdarker", "has_horns"), HasHorns.CODEC);
    }
    private DDItemModelProperties() {}
}
