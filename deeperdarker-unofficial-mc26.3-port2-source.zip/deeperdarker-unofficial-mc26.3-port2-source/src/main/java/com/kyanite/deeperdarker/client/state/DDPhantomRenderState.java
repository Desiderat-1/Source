package com.kyanite.deeperdarker.client.state;
import net.minecraft.client.renderer.entity.state.PhantomRenderState;
public final class DDPhantomRenderState extends PhantomRenderState { public boolean sculkTexture; }
