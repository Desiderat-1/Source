// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.network;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

public record SoulElytraBoostPacket() implements CustomPacketPayload {
    public static final Type<SoulElytraBoostPacket> TYPE = new Type<>(Identifier.fromNamespaceAndPath("deeperdarker", "soul_elytra_boost"));
    public static final StreamCodec<ByteBuf, SoulElytraBoostPacket> CODEC = StreamCodec.unit(new SoulElytraBoostPacket());


    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
