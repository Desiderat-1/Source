// Unofficial Minecraft 26.3 API port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.content.entities;

import com.kyanite.deeperdarker.network.LinkOwnedEntityPacket;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.UUIDUtil;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.TraceableEntity;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

public abstract class SyncedOwnedEntity extends Entity implements TraceableEntity {
    @Nullable
    private UUID ownerUUID;
    @Nullable
    private Entity owner;
    private int delayedOwnerId;

    public static final String OWNER_TAG = "owner";

    public SyncedOwnedEntity(EntityType<?> entityType, Level level) {
        super(entityType, level);
    }

    public SyncedOwnedEntity(EntityType<?> entityType, Level level, @NotNull Entity owner) {
        this(entityType, level);
        ownerUUID = owner.getUUID();
    }

    @Override
    protected void defineSynchedData(net.minecraft.network.syncher.SynchedEntityData.Builder builder) {
    }

    @Override
    @Nullable
    public Entity getOwner() {
        if (owner == null && delayedOwnerId != 0 && level().isClientSide()) {
            owner = level().getEntity(delayedOwnerId);
        }
        return owner;
    }

    public void setOwner(@Nullable Entity entity, boolean broadcast) {
        owner = entity;
        ownerUUID = null;
        if (entity == null) return;
        if (!level().isClientSide() && broadcast && level() instanceof ServerLevel serverLevel) {
            final CustomPacketPayload packet = new LinkOwnedEntityPacket(owner, this);
            PlayerLookup.level(serverLevel).forEach(player -> ServerPlayNetworking.send(player, packet));
        }
    }

    public void setDelayedOwnerId(int value) {
        delayedOwnerId = value;
    }

    protected void tickOwner() {
        restoreOwnerFromSave();
        if (owner != null && !owner.isAlive()) discard();
    }

    private void restoreOwnerFromSave() {
        if (ownerUUID != null && level() instanceof ServerLevel serverLevel) {
            Entity entity = serverLevel.getEntity(ownerUUID);
            if (entity != null) {
                setOwner(entity, true);
            }
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide()) {
            tickOwner();
        }
    }

    @Override
    protected void readAdditionalSaveData(ValueInput input) {
        owner = null;
        delayedOwnerId = 0;
        ownerUUID = input.read(OWNER_TAG, UUIDUtil.CODEC).orElse(null);
    }

    @Override
    protected void addAdditionalSaveData(ValueOutput output) {
        UUID id = owner != null ? owner.getUUID() : ownerUUID;
        if (id != null) output.store(OWNER_TAG, UUIDUtil.CODEC, id);
    }
}
