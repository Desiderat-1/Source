package com.kyanite.deeperdarker.client.render;

import com.kyanite.deeperdarker.client.DDModelLayers;
import com.kyanite.deeperdarker.client.model.OverseerCrystalModel;
import com.kyanite.deeperdarker.client.state.DDModelRenderState;
import com.kyanite.deeperdarker.content.entities.overseer.OverseerCrystal;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.Vec3;

public final class OverseerCrystalRenderer<T extends OverseerCrystal> extends EntityRenderer<T,OverseerCrystalRenderer.State> {
    public static final class State extends EntityRenderState {
        final DDModelRenderState model=new DDModelRenderState();Vec3 offset,beam;
    }
    private static final Identifier TEXTURE=Identifier.fromNamespaceAndPath("deeperdarker","textures/entity/overseer/overseer_crystal.png");
    private final OverseerCrystalModel<T> model;
    public OverseerCrystalRenderer(EntityRendererProvider.Context context){super(context);model=new OverseerCrystalModel<>(context.bakeLayer(DDModelLayers.OVERSEER_CRYSTAL));}
    @Override
    public State createRenderState(){return new State();}
    @Override
    public void extractRenderState(T entity,State state,float partial){
        super.extractRenderState(entity,state,partial);state.model.ageInTicks=entity.tickCount+partial;
        state.model.parts=model.capturePose(entity,state.model);state.offset=null;state.beam=null;
        var owner=entity.getOwner();
        if(owner!=null){
            Vec3 direction=entity.position().subtract(owner.position().add(0,owner.getBbHeight()/2,0));
            Vec3 crystal=direction.normalize().scale(0.5).add(0,-entity.getBbHeight()/2,0);
            direction=direction.subtract(crystal);state.offset=crystal.scale(-1);
            state.beam=direction.scale(-1).add(direction.normalize().scale(2));
        }
    }
    @Override
    public void submit(State state,PoseStack poses,SubmitNodeCollector nodes,CameraRenderState camera){
        super.submit(state,poses,nodes,camera);poses.pushPose();poses.translate(0,state.boundingBoxHeight/2,0);poses.scale(-1,-1,1);
        nodes.submitModel(model,state.model,poses,model.renderType(TEXTURE),state.lightCoords,OverlayTexture.NO_OVERLAY,0xFFFFFFFF);poses.popPose();
        if(state.offset!=null){
            poses.pushPose();poses.translate(state.offset.x,state.offset.y,state.offset.z);
            OverseerRenderer.renderBeams((float)state.beam.x,(float)state.beam.y,(float)state.beam.z,0,poses,nodes,state.lightCoords,DDCrystalTrail.TYPE,1,0.2F);poses.popPose();
        }
    }
    @Override
    protected int getBlockLightLevel(T entity,BlockPos pos){return 15;}
    @Override
    public boolean shouldRender(T entity,Frustum frustum,double x,double y,double z,float partial){return entity.getOwner()!=null||super.shouldRender(entity,frustum,x,y,z,partial);}
}
