// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.content;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.storage.loot.LootTable;
public final class DDLootTables {
    public static final ResourceKey<LootTable> ANCIENT_TEMPLE_BASEMENT = key("chests/ancient_temple_basement");
    public static final ResourceKey<LootTable> ANCIENT_TEMPLE_SECRET = key("chests/ancient_temple_secret");
    public static final ResourceKey<LootTable> ANCIENT_TEMPLE_STORAGE = key("chests/ancient_temple_storage");
    public static final ResourceKey<LootTable> ANCIENT_TEMPLE_APEX = key("chests/ancient_temple_apex");
    public static final ResourceKey<LootTable> ANCIENT_TEMPLE_FOUNTAIN = key("chests/ancient_temple_fountain");
    public static final ResourceKey<LootTable> CRYSTALLIZED_AMBER = key("chests/crystallized_amber");
    public static final ResourceKey<LootTable> BLOOMAZE_BASIC = key("chests/bloomaze_basic");
    public static final ResourceKey<LootTable> BLOOMAZE_ADVANCED = key("chests/bloomaze_advanced");
    public static final ResourceKey<LootTable> BLOOMAZE_SECRET = key("chests/bloomaze_secret");
    public static final ResourceKey<LootTable> GLOOMAZE_BASIC = key("chests/gloomaze_basic");
    public static final ResourceKey<LootTable> GLOOMAZE_ADVANCED = key("chests/gloomaze_advanced");
    public static final ResourceKey<LootTable> GLOOMAZE_SECRET = key("chests/gloomaze_secret");
    public static final ResourceKey<LootTable> CASTLE_BASIC = key("chests/castle_basic");
    public static final ResourceKey<LootTable> CASTLE_ROYAL = key("chests/castle_royal");
    public static final ResourceKey<LootTable> SCULK_RUINS = key("chests/sculk_ruins");
    private static ResourceKey<LootTable> key(String path) { return ResourceKey.create(Registries.LOOT_TABLE, Identifier.fromNamespaceAndPath("deeperdarker", path)); }
    private DDLootTables() {}
}
