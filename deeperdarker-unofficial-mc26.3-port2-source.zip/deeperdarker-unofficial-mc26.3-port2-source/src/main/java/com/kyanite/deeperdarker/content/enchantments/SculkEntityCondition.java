// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.content.enchantments;
import com.kyanite.deeperdarker.content.entities.DDMobType;
import com.mojang.serialization.MapCodec;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraft.util.context.ContextKey;
import java.util.Set;
/** Includes the original dimension-dependent Phantom rule through the common classifier. */
public record SculkEntityCondition() implements LootItemCondition {
    public static final MapCodec<SculkEntityCondition> CODEC = MapCodec.unit(new SculkEntityCondition());
    @Override public boolean test(LootContext context) {
        return context.getOptional(LootContextParams.THIS_ENTITY) instanceof LivingEntity living && DDMobType.isSculk(living);
    }
    @Override public MapCodec<SculkEntityCondition> codec() { return CODEC; }
    @Override public Set<ContextKey<?>> getReferencedContextParams() { return Set.of(LootContextParams.THIS_ENTITY); }
}
