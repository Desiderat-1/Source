package com.kyanite.deeperdarker.client.render;

import com.kyanite.deeperdarker.content.blocks.DarkFountainBlock;
import com.kyanite.deeperdarker.content.entities.blocks.DarkFountainBlockEntity;
import com.kyanite.deeperdarker.util.DDUtil;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.blockentity.*;
import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

public final class DarkFountainBlockRenderer implements BlockEntityRenderer<DarkFountainBlockEntity,DarkFountainBlockRenderer.State> {
    private static final Identifier TEXTURE=Identifier.fromNamespaceAndPath("deeperdarker","textures/entity/dark_fountain/beam.png");
    private static final Identifier LIGHT_TEXTURE=Identifier.fromNamespaceAndPath("deeperdarker","textures/entity/dark_fountain/beam_light.png");
    public static final class State extends BlockEntityRenderState {
        boolean visible;int color,down,up;float animationTime;int[] lights=new int[0];
    }
    public DarkFountainBlockRenderer(BlockEntityRendererProvider.Context context){}
    @Override
    public State createRenderState(){return new State();}
    @Override
    public void extractRenderState(DarkFountainBlockEntity entity,State state,float partial,Vec3 camera,ModelFeatureRenderer.CrumblingOverlay overlay){
        BlockEntityRenderer.super.extractRenderState(entity,state,partial,camera,overlay);
        state.visible=!entity.getBlockState().hasProperty(DarkFountainBlock.HAS_BEAM)||entity.getBlockState().getValue(DarkFountainBlock.HAS_BEAM);
        float alpha=entity.getFountainTicksLeft()>10?1:Mth.lerp(partial,Math.min(10,entity.getFountainTicksLeftOld()),entity.getFountainTicksLeft())/10F;
        state.color=0xFFFFFF|((int)(Mth.clamp(alpha,0,1)*255)<<24);
        state.down=entity.getBeamBlocksDown();state.up=entity.getBeamBlocksUp();
        state.animationTime=Math.floorMod(entity.hasLevel()?entity.getLevel().getGameTime():0,360)+partial;
        state.lights=extractLights(entity.getLevel(),entity.getBlockPos(),state.down,state.up);
    }
    @Override
    public void submit(State state,PoseStack poses,SubmitNodeCollector nodes,CameraRenderState camera){
        if(!state.visible)return;
        poses.pushPose();poses.translate(0.5,0.5,0.5);
        submitFountainBeam(poses,nodes,Vec3.atCenterOf(state.blockPos),camera.pos,state.animationTime,state.lights,
                OverlayTexture.NO_OVERLAY,state.color,state.down,state.up);poses.popPose();
    }
    static int[] extractLights(net.minecraft.world.level.Level level,BlockPos origin,int down,int up){
        int[] result=new int[down+up+1];var pos=origin.mutable();
        for(int i=-down;i<=up;i++)result[i+down]=level==null?0xFFFFFF:net.minecraft.util.LightCoordsUtil.getLightCoords(level,pos.setY(origin.getY()+i));
        return result;
    }
    public static void submitFountainBeam(PoseStack poses,SubmitNodeCollector nodes,Vec3 center,Vec3 camera,float animationTime,
                                           int[] lights,int overlay,int color,int down,int up){
        float rotation=(float)Mth.atan2(center.x()-camera.x(),center.z()-camera.z());
        float scale=2.25F+Mth.sin(Mth.DEG_TO_RAD*animationTime*8)*0.25F;
        for(int offset=-down;offset<=up;offset++){
            int light=lights[offset+down];poses.pushPose();poses.translate(0,offset,0);
            poses.pushPose();poses.scale(scale,1,scale);poses.rotate(Axis.YP.rotation(rotation));poses.translate(-0.5,-0.5,-0.5);
            nodes.submitCustomGeometry(poses,RenderTypes.entityTranslucentCull(LIGHT_TEXTURE),(pose,vertices)->
                    DDUtil.renderFlatFace(pose,vertices,color,7,0,8,2,16,0,2F/32,32,32,light,overlay));poses.popPose();
            poses.rotate(Axis.YP.rotationDegrees(animationTime-45));poses.translate(-0.5,-0.5,-0.5);
            nodes.submitCustomGeometry(poses,RenderTypes.entityTranslucent(TEXTURE),(pose,vertices)->
                    DDUtil.renderCuboidSides(pose,vertices,color,7,0,7,2,16,2,0,0,32,32,light,overlay));poses.popPose();
        }
    }
    @Override
    public boolean shouldRenderOffScreen(){return true;}
    @Override
    public int getViewDistance(){return 16;}
    @Override
    public boolean shouldRender(DarkFountainBlockEntity entity,Vec3 camera){
        return Vec3.atCenterOf(entity.getBlockPos()).multiply(1,0,1).closerThan(camera.multiply(1,0,1),getViewDistance());
    }
}
