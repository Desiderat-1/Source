// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.content.items;

import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.Equippable;

public class ResonariumArmorItem extends Item {
    public ResonariumArmorItem(ArmorMaterial material, ArmorType type, Properties properties) {
        // Preserve the original enchanting-table immunity by omitting ENCHANTABLE.
        super(properties.durability(type.getDurability(material.durability()))
            .attributes(material.createAttributes(type)).repairable(material.repairIngredient())
            .component(DataComponents.EQUIPPABLE, Equippable.builder(type.getSlot())
                .setEquipSound(material.equipSound()).setAsset(material.assetId()).build()));
    }
}
