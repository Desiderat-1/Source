// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.world.features;

import com.kyanite.deeperdarker.content.DDBlocks;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.GrowingPlantHeadBlock;
import net.minecraft.world.level.levelgen.feature.Feature;

public class SculkTendrilsFeature implements Feature {
    public static final MapCodec<SculkTendrilsFeature> CODEC = MapCodec.unit(SculkTendrilsFeature::new);
    public SculkTendrilsFeature() {}
    @Override public MapCodec<SculkTendrilsFeature> codec() { return CODEC; }

    @Override
    public boolean place(net.minecraft.world.level.WorldGenLevel level, net.minecraft.world.level.chunk.ChunkGenerator generator, net.minecraft.util.RandomSource random, net.minecraft.core.BlockPos origin) {
        return generate(new DDFeatureContext<>(null, level, generator, random, origin));
    }
    private boolean generate(DDFeatureContext<Void> pContext) {
        WorldGenLevel level = pContext.level();
        BlockPos origin = pContext.origin();
        if(isValidPlacementLocation(level, origin)) {
            RandomSource random = pContext.random();
            int width = 8;
            int height = 4;
            int maxHeight = 8;
            BlockPos.MutableBlockPos blockPos = new BlockPos.MutableBlockPos();

            for(int i = 0; i < width * width; i++) {
                blockPos.set(origin).move(Mth.nextInt(random, -width, width), Mth.nextInt(random, -height, height), Mth.nextInt(random, -width, width));
                if(findAirAboveGround(level, blockPos) && isValidPlacementLocation(level, blockPos)) {
                    int length = Mth.nextInt(random, 1, maxHeight);
                    if(random.nextInt(6) == 0) length *= 2;
                    if(random.nextInt(5) == 0) length = 1;

                    placeColumn(level, random, blockPos, length);
                }
            }

            return true;
        }

        return false;
    }

    private boolean isValidPlacementLocation(LevelAccessor level, BlockPos pos) {
        return level.getBlockState(pos.below()).is(Blocks.SCULK);
    }

    private boolean findAirAboveGround(LevelAccessor level, BlockPos.MutableBlockPos pos) {
        do {
            pos.move(0, -1, 0);
            if(level.isOutsideBuildHeight(pos)) return false;
        } while(level.getBlockState(pos).isAir());

        pos.move(0, 1, 0);
        return true;
    }

    private void placeColumn(LevelAccessor level, RandomSource random, BlockPos.MutableBlockPos pos, int length) {
        for(int i = 1; i <= length; i++) {
            if(level.isEmptyBlock(pos)) {
                if(i == length || !level.isEmptyBlock(pos.above())) {
                    level.setBlock(pos, DDBlocks.SCULK_TENDRILS.defaultBlockState().setValue(GrowingPlantHeadBlock.AGE, Mth.nextInt(random, 17, 25)), 3);
                    break;
                }

                level.setBlock(pos, DDBlocks.SCULK_TENDRILS_PLANT.defaultBlockState(), 3);
            }

            pos.move(Direction.UP);
        }
    }
}
