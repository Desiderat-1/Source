// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.util.recipes;

import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.CraftingBookCategory;
import net.minecraft.world.item.crafting.RecipeSerializer;

import java.util.function.Predicate;

public class AugmentShieldRecipe extends ItemCombinerCustomRecipe {
    public AugmentShieldRecipe() { super(); }

    @Override
    public Predicate<ItemStack> getFirst() {
        return stack -> stack.is(Items.SHIELD);
    }

    @Override
    public Predicate<ItemStack> getSecond() {
        return stack -> stack.is(net.minecraft.core.registries.BuiltInRegistries.ITEM.getValue(Identifier.fromNamespaceAndPath("deeperdarker", "shield_augment")));
    }

    @Override
    public ItemStack assemble(ItemStack first, ItemStack second) {
        ItemStack result = first.copyWithCount(1);
        com.kyanite.deeperdarker.content.components.DDItemProperties.setAugmented(result);
        return result;
    }

    @Override
    public RecipeSerializer<? extends net.minecraft.world.item.crafting.CustomRecipe> getSerializer() {
        return DDRecipeSerializers.AUGMENT_SHIELD;
    }
}
