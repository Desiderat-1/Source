// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.client.render;

import com.kyanite.deeperdarker.DeeperDarker;
import com.kyanite.deeperdarker.client.DDModelLayers;
import com.kyanite.deeperdarker.client.model.OvercastVesselModel;
import com.kyanite.deeperdarker.content.entities.overcastvessel.OvercastVessel;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

@SuppressWarnings("NullableProblems")
public class OvercastVesselRenderer extends DDMobRenderer<OvercastVessel, OvercastVesselModel> {
    private static final Identifier TEXTURE = Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "textures/entity/overcast_vessel/overcast_vessel.png");
    private static final Identifier TEXTURE_SLEEPING = Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "textures/entity/overcast_vessel/overcast_vessel_sleeping.png");

    public OvercastVesselRenderer(EntityRendererProvider.Context context) {
        super(context, new OvercastVesselModel(context.bakeLayer(DDModelLayers.OVERCAST_VESSEL)), 1.0f);
        addLayer(new OvercastVesselCrackLayer<>(this));
    }

    @Override
    public void extractRenderState(OvercastVessel entity,
            com.kyanite.deeperdarker.client.state.DDModelRenderState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);
        state.crackDirections = java.util.List.copyOf(entity.getCrackDirections());
    }

    @Override
    public Identifier getTextureLocation(OvercastVessel entity) {
        return entity.isGolemSleeping() ? TEXTURE_SLEEPING : TEXTURE;
    }

    @Override
    protected void setupRotations(OvercastVessel vessel, PoseStack poseStack, float f, float g, float h) {
    }
}
