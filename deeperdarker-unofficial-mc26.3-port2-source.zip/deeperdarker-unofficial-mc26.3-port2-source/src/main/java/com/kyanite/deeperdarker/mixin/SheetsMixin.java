package com.kyanite.deeperdarker.mixin;

import com.kyanite.deeperdarker.client.render.DDChestSprites;
import com.kyanite.deeperdarker.client.state.DDChestRenderState;
import com.llamalad7.mixinextras.injector.wrapoperation.*;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.client.renderer.blockentity.ChestRenderer;
import net.minecraft.client.renderer.blockentity.state.ChestRenderState;
import net.minecraft.client.resources.model.sprite.SpriteId;
import net.minecraft.world.level.block.state.properties.ChestType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(ChestRenderer.class)
public abstract class SheetsMixin {
    @WrapOperation(method="submit",at=@At(value="INVOKE",target="Lnet/minecraft/client/renderer/Sheets;chooseSprite(Lnet/minecraft/client/renderer/blockentity/state/ChestRenderState$ChestMaterialType;Lnet/minecraft/world/level/block/state/properties/ChestType;)Lnet/minecraft/client/resources/model/sprite/SpriteId;"))
    private SpriteId deeperdarker$recoveryChestSprite(ChestRenderState.ChestMaterialType material,ChestType type,
                                                      Operation<SpriteId> original,@Local(argsOnly=true) ChestRenderState state){
        return state instanceof DDChestRenderState?DDChestSprites.choose(type):original.call(material,type);
    }
}
