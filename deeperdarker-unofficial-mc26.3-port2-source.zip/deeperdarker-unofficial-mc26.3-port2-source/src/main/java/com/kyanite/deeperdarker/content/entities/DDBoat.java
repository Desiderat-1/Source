// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.content.entities;

import com.kyanite.deeperdarker.content.DDBlocks;
import com.kyanite.deeperdarker.content.DDEntities;
import com.kyanite.deeperdarker.content.DDItems;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.vehicle.boat.Boat;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;

@SuppressWarnings("NullableProblems")
public class DDBoat extends Boat implements DDBoatLike {
    private static final EntityDataAccessor<String> WOOD_TYPE = SynchedEntityData.defineId(DDBoat.class, EntityDataSerializers.STRING);

    public DDBoat(EntityType<? extends Boat> pEntityType, Level pLevel) {
        this(pEntityType, pLevel, new DDBoatDropSupplier(false));
    }

    private DDBoat(EntityType<? extends Boat> type, Level level, DDBoatDropSupplier drop) {
        super(type, level, drop);
        drop.bind(this);
    }

    public DDBoat(Level level, double x, double y, double z) {
        this(DDEntities.BOAT, level);
        this.setPos(x, y, z);
        this.xo = x;
        this.yo = y;
        this.zo = z;
    }

    @Override
    protected void defineSynchedData(net.minecraft.network.syncher.SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(WOOD_TYPE, "deeperdarker:echo");
    }


    @Override
    protected void addAdditionalSaveData(net.minecraft.world.level.storage.ValueOutput pCompound) {
        super.addAdditionalSaveData(pCompound);
        pCompound.putString("Type", this.getWoodType().getSerializedName());
    }

    @Override
    protected void readAdditionalSaveData(net.minecraft.world.level.storage.ValueInput pCompound) {
        super.readAdditionalSaveData(pCompound);
        this.setWoodType(Type.byName(pCompound.getStringOr("Type", "")));
    }

    @Override
    public Type getWoodType() {
        return Type.byName(this.entityData.get(WOOD_TYPE));
    }

    @Override
    public void setWoodType(Type woodType) {
        this.entityData.set(WOOD_TYPE, woodType.getSerializedName());
    }


    public enum Type implements StringRepresentable {
        ECHO(DDBlocks.ECHO_PLANKS, "echo"),
        BLOOM(DDBlocks.BLOOM_PLANKS, "bloom"),
        SCULK_SPRUCE(DDBlocks.SCULK_SPRUCE_PLANKS, "sculk_spruce");

        private final String name;
        private final Block planks;
        public static final StringRepresentable.EnumCodec<Type> CODEC;

        Type(Block block, String string2) {
            this.name = string2;
            this.planks = block;
        }

        @Override
        public String getSerializedName() {
            return this.name;
        }

        public String getName() {
            return this.name;
        }

        public Block getPlanks() {
            return this.planks;
        }

        public String toString() {
            return this.name;
        }

        public static Type byName(String string) {
            return CODEC.byName(string, ECHO);
        }

        static {
            CODEC = StringRepresentable.fromEnum(Type::values);
        }
    }
}
