// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.client.render;
import net.minecraft.client.renderer.rendertype.RenderTypes;

import com.kyanite.deeperdarker.DeeperDarker;
import com.kyanite.deeperdarker.content.entities.overcastvessel.OvercastVessel;
import com.kyanite.deeperdarker.util.DDUtil;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import com.kyanite.deeperdarker.client.state.DDModelRenderState;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.Direction;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class OvercastVesselCrackLayer<M extends EntityModel<DDModelRenderState>> extends RenderLayer<DDModelRenderState, M> {
    public static final Identifier TEXTURE = Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "textures/entity/overcast_vessel/overcast_vessel_crack.png");

    public OvercastVesselCrackLayer(RenderLayerParent<DDModelRenderState, M> renderLayerParent) {
        super(renderLayerParent);
    }

    @Override
    public void submit(PoseStack poseStack, SubmitNodeCollector nodes, int light, DDModelRenderState state, float headYaw, float headPitch) {
        for (Direction direction : state.crackDirections) {
            poseStack.pushPose();
            if (direction == Direction.NORTH) {
                poseStack.translate(1.5f, -1.5f, 1.5f);
                poseStack.rotate(Axis.YP.rotationDegrees(180.0f));
            }
            if (direction == Direction.SOUTH) {
                poseStack.translate(-1.5f, -1.5f, -1.5f);
            }
            if (direction == Direction.EAST) {
                poseStack.translate(1.5f, -1.5f, -1.5f);
                poseStack.rotate(Axis.YN.rotationDegrees(90.0f));
            }
            if (direction == Direction.WEST) {
                poseStack.translate(-1.5f, -1.5f, 1.5f);
                poseStack.rotate(Axis.YP.rotationDegrees(90.0f));
            }
            if (direction == Direction.UP) {
                poseStack.translate(-1.5f, -1.5f, 1.5f);
                poseStack.rotate(Axis.XN.rotationDegrees(90.0f));
            }
            if (direction == Direction.DOWN) {
                poseStack.translate(-1.5f, 1.5f, -1.5f);
                poseStack.rotate(Axis.XP.rotationDegrees(90.0f));
            }
            nodes.submitCustomGeometry(poseStack, net.minecraft.client.renderer.rendertype.RenderTypes.entityCutoutZOffset(TEXTURE), (pose, vertices) -> {
                PoseStack captured = new PoseStack();
                captured.mulPose(pose.pose());
                DDUtil.renderFlatFace(captured, vertices, 0xFFFFFFFF, 0, 0, 0, 48, 48, 0, 0, 48, 48, light, OverlayTexture.NO_OVERLAY);
            });
            poseStack.popPose();
        }
    }
}
