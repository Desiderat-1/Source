package com.kyanite.deeperdarker.mixin;

import com.kyanite.deeperdarker.client.state.AcidOverlayState;
import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.level.*;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ScreenEffectRenderer.class)
public abstract class ScreenEffectMixin {
    @Inject(method="submit",at=@At(value="FIELD",target="Lnet/minecraft/client/renderer/state/level/PlayerRenderState;waterOverlay:Lnet/minecraft/client/renderer/state/level/PlayerRenderState$WaterOverlay;",ordinal=0))
    private void deeperdarker$submitAcid(float partial,SubmitNodeCollector nodes,PlayerRenderState state,CameraRenderState camera,boolean renderItemActivation,
                                        CallbackInfo ci,@Local PoseStack poses){
        var acid=((AcidOverlayState)state).deeperdarker$acidOverlay();if(acid==null)return;
        float u=acid.uOffset(),v=acid.vOffset();int color=acid.color();
        nodes.submitCustomGeometry(poses,RenderTypes.blockScreenEffect(Identifier.fromNamespaceAndPath("deeperdarker","textures/misc/acid.png")),(pose,vertices)->{
            vertices.addVertex(pose.pose(),-1,-1,-0.5F).setUv(4+u,4+v).setColor(color);
            vertices.addVertex(pose.pose(),1,-1,-0.5F).setUv(u,4+v).setColor(color);
            vertices.addVertex(pose.pose(),1,1,-0.5F).setUv(u,v).setColor(color);
            vertices.addVertex(pose.pose(),-1,1,-0.5F).setUv(4+u,v).setColor(color);
        });
    }
}
