// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.world.features.config;

import com.kyanite.deeperdarker.util.DDTags;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.registries.Registries;
import net.minecraft.tags.TagKey;
import net.minecraft.util.valueproviders.ConstantInt;
import net.minecraft.util.valueproviders.IntProvider;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.levelgen.feature.stateproviders.BlockStateProvider;

public class ConeFeatureConfiguration {
    public static final MapCodec<ConeFeatureConfiguration> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            TagKey.codec(Registries.BLOCK).fieldOf("replaceable").orElse(DDTags.Blocks.SCULK_SPRUCE_FOREST_REPLACEABLE).forGetter(config -> config.replaceable),
            BlockStateProvider.DIRECT_CODEC.fieldOf("state_provider").forGetter(config -> config.blockStateProvider),
            net.minecraft.util.valueproviders.IntProviders.codec(1, 128).fieldOf("width").orElse(UniformInt.of(4, 5)).forGetter(config -> config.widthProvider),
            net.minecraft.util.valueproviders.IntProviders.codec(1, 128).fieldOf("depth").orElse(UniformInt.of(5, 7)).forGetter(config -> config.depthProvider),
            net.minecraft.util.valueproviders.IntProviders.codec(1, 128).fieldOf("maxFloeHeight").orElse(UniformInt.of(6, 8)).forGetter(config -> config.heightProvider),
            net.minecraft.util.valueproviders.IntProviders.codec(-16, 16).fieldOf("tip_x_shift").orElse(UniformInt.of(-3, 3)).forGetter(config -> config.tipXShiftProvider),
            net.minecraft.util.valueproviders.IntProviders.codec(-128, 0).fieldOf("y_shift").orElse(ConstantInt.of(0)).forGetter(config -> config.yShiftProvider),
            net.minecraft.util.valueproviders.IntProviders.codec(-16, 16).fieldOf("tip_z_shift").orElse(UniformInt.of(-3, 3)).forGetter(config -> config.tipZShiftProvider)
    ).apply(instance, ConeFeatureConfiguration::new));
    public final TagKey<Block> replaceable;
    public final BlockStateProvider blockStateProvider;
    public final IntProvider widthProvider;
    public final IntProvider depthProvider;
    public final IntProvider heightProvider;
    public final IntProvider tipXShiftProvider;
    public final IntProvider yShiftProvider;
    public final IntProvider tipZShiftProvider;

    public ConeFeatureConfiguration(TagKey<Block> replaceable, BlockStateProvider blockStateProvider, IntProvider widthProvider, IntProvider depthProvider, IntProvider heightProvider, IntProvider tipXShiftProvider, IntProvider yShiftProvider, IntProvider tipZShiftProvider) {
        this.replaceable = replaceable;
        this.blockStateProvider = blockStateProvider;
        this.widthProvider = widthProvider;
        this.depthProvider = depthProvider;
        this.heightProvider = heightProvider;
        this.tipXShiftProvider = tipXShiftProvider;
        this.yShiftProvider = yShiftProvider;
        this.tipZShiftProvider = tipZShiftProvider;
    }
}
