// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.content.entities;

import com.kyanite.deeperdarker.content.DDEntities;
import com.kyanite.deeperdarker.content.DDItems;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.vehicle.boat.Boat;
import net.minecraft.world.entity.vehicle.boat.ChestBoat;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

@SuppressWarnings("NullableProblems")
public class DDChestBoat extends ChestBoat implements DDBoatLike {
    private static final EntityDataAccessor<String> WOOD_TYPE = SynchedEntityData.defineId(DDChestBoat.class, EntityDataSerializers.STRING);

    public DDChestBoat(EntityType<? extends ChestBoat> pEntityType, Level pLevel) {
        this(pEntityType, pLevel, new DDBoatDropSupplier(true));
    }

    private DDChestBoat(EntityType<? extends ChestBoat> type, Level level, DDBoatDropSupplier drop) {
        super(type, level, drop);
        drop.bind(this);
    }

    public DDChestBoat(Level level, double x, double y, double z) {
        this(DDEntities.CHEST_BOAT, level);
        this.setPos(x, y, z);
        this.xo = x;
        this.yo = y;
        this.zo = z;
    }

    @Override
    protected void defineSynchedData(net.minecraft.network.syncher.SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(WOOD_TYPE, "echo");
    }


    @Override
    protected void addAdditionalSaveData(net.minecraft.world.level.storage.ValueOutput pCompound) {
        super.addAdditionalSaveData(pCompound);
        pCompound.putString("Type", this.getWoodType().getSerializedName());
    }

    @Override
    protected void readAdditionalSaveData(net.minecraft.world.level.storage.ValueInput pCompound) {
        super.readAdditionalSaveData(pCompound);
        this.setWoodType(DDBoat.Type.byName(pCompound.getStringOr("Type", "")));
    }

    @Override
    public DDBoat.Type getWoodType() {
        return DDBoat.Type.byName(this.entityData.get(WOOD_TYPE));
    }

    @Override
    public void setWoodType(DDBoat.Type woodType) {
        this.entityData.set(WOOD_TYPE, woodType.getSerializedName());
    }

}
