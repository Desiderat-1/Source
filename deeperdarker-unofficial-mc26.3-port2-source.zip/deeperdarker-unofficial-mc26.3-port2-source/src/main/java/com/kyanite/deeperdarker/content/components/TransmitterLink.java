// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.content.components;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import java.util.Optional;

/** Persistent, synchronized link plus a reader for the alpha's custom NBT layout. */
public record TransmitterLink(GlobalPos target, String blockDescription) {
    public static final Codec<TransmitterLink> CODEC = RecordCodecBuilder.create(instance -> instance.group(
        GlobalPos.CODEC.fieldOf("target").forGetter(TransmitterLink::target),
        Codec.STRING.fieldOf("block").forGetter(TransmitterLink::blockDescription)
    ).apply(instance, TransmitterLink::new));
    public static final StreamCodec<ByteBuf, TransmitterLink> STREAM_CODEC = StreamCodec.composite(
        GlobalPos.STREAM_CODEC, TransmitterLink::target, ByteBufCodecs.STRING_UTF8, TransmitterLink::blockDescription, TransmitterLink::new);
    public static Optional<TransmitterLink> read(ItemStack stack) {
        TransmitterLink link = stack.get(DDDataComponents.TRANSMITTER_LINK);
        if (link != null) return Optional.of(link);
        CompoundTag legacy = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        return readLegacy(legacy).map(pos -> new TransmitterLink(pos, legacy.getStringOr("block", "")));
    }
    public static Optional<GlobalPos> readLegacy(CompoundTag legacy) {
        Identifier dimension = Identifier.tryParse(legacy.getStringOr("dimension", ""));
        var position = legacy.getCompound("block_pos");
        if (dimension == null || position.isEmpty()) return Optional.empty();
        CompoundTag tag = position.get();
        var x = tag.getInt("X"); var y = tag.getInt("Y"); var z = tag.getInt("Z");
        if (x.isEmpty() || y.isEmpty() || z.isEmpty()) return Optional.empty();
        return Optional.of(new GlobalPos(ResourceKey.create(Registries.DIMENSION, dimension), new BlockPos(x.get(), y.get(), z.get())));
    }
    public static void write(ItemStack stack, TransmitterLink link) {
        if (link == null) stack.remove(DDDataComponents.TRANSMITTER_LINK);
        else stack.set(DDDataComponents.TRANSMITTER_LINK, link);
        CustomData.update(DataComponents.CUSTOM_DATA, stack, legacy -> {
            legacy.remove("block"); legacy.remove("block_pos"); legacy.remove("dimension");
        });
    }
}
