package com.kyanite.deeperdarker.client.render;

import com.kyanite.deeperdarker.client.DDModelLayers;
import com.kyanite.deeperdarker.content.entities.DDBoat;
import com.kyanite.deeperdarker.content.entities.DDBoatLike;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.renderer.entity.state.BoatRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.world.entity.vehicle.boat.AbstractBoat;
import java.util.Map;

/** Native rowing, damage rocking and water masking, with our synchronized wood variants. */
public final class DDBoatRenderer<T extends AbstractBoat & DDBoatLike> extends EntityRenderer<T,DDBoatRenderer.State> {
    public static final class State extends BoatRenderState { DDBoat.Type wood; }
    private final Map<DDBoat.Type,BoatRenderer> variants;
    public DDBoatRenderer(EntityRendererProvider.Context context,boolean chest) {
        super(context);
        variants=Map.of(
                DDBoat.Type.ECHO,new BoatRenderer(context,chest?DDModelLayers.ECHO_CHEST_BOAT:DDModelLayers.ECHO_BOAT),
                DDBoat.Type.BLOOM,new BoatRenderer(context,chest?DDModelLayers.BLOOM_CHEST_BOAT:DDModelLayers.BLOOM_BOAT),
                DDBoat.Type.SCULK_SPRUCE,new BoatRenderer(context,chest?DDModelLayers.SCULK_SPRUCE_CHEST_BOAT:DDModelLayers.SCULK_SPRUCE_BOAT));
    }
    @Override
    public State createRenderState(){return new State();}
    @Override
    public void extractRenderState(T entity,State state,float partial){
        state.wood=entity.getWoodType();variants.get(state.wood).extractRenderState(entity,state,partial);
    }
    @Override
    public void submit(State state,PoseStack poses,SubmitNodeCollector nodes,CameraRenderState camera){
        variants.get(state.wood).submit(state,poses,nodes,camera);
    }
}
