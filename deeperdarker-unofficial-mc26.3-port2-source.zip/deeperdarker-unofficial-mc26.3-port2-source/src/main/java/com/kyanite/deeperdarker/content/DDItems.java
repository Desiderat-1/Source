// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.content;

import com.kyanite.deeperdarker.util.DDRegistration;

import com.kyanite.deeperdarker.DeeperDarker;
import com.kyanite.deeperdarker.content.entities.DDBoat;
import com.kyanite.deeperdarker.content.items.*;
import com.kyanite.deeperdarker.util.DDArmorMaterials;
import com.kyanite.deeperdarker.util.DDTiers;
import net.minecraft.ChatFormatting;
import net.minecraft.util.Util;
import net.minecraft.core.Direction;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.*;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.component.Consumables;
import net.minecraft.world.item.consume_effects.ApplyStatusEffectsConsumeEffect;

import java.util.List;

@SuppressWarnings("unused")
public class DDItems {
    public static final Item GRIME_BALL = register("grime_ball", new Item(DDRegistration.itemProperties("grime_ball")));
    public static final Item GRIME_BRICK = register("grime_brick", new Item(DDRegistration.itemProperties("grime_brick")));

    public static final Item SOUL_ELYTRA = register("soul_elytra", new SoulElytraItem(DDRegistration.itemProperties("soul_elytra").durability(956).rarity(Rarity.UNCOMMON)));
    public static final Item ECHO_BOAT = register("echo_boat", new DDBoatItem(false, DDRegistration.itemProperties("echo_boat").stacksTo(1), DDBoat.Type.ECHO));
    public static final Item ECHO_CHEST_BOAT = register("echo_chest_boat", new DDBoatItem(true, DDRegistration.itemProperties("echo_chest_boat").stacksTo(1), DDBoat.Type.ECHO));
    public static final Item BLOOM_BOAT = register("bloom_boat", new DDBoatItem(false, DDRegistration.itemProperties("bloom_boat").stacksTo(1), DDBoat.Type.BLOOM));
    public static final Item BLOOM_CHEST_BOAT = register("bloom_chest_boat", new DDBoatItem(true, DDRegistration.itemProperties("bloom_chest_boat").stacksTo(1), DDBoat.Type.BLOOM));
    public static final Item SCULK_SPRUCE_BOAT = register("sculk_spruce_boat", new DDBoatItem(false, DDRegistration.itemProperties("sculk_spruce_boat").stacksTo(1), DDBoat.Type.SCULK_SPRUCE));
    public static final Item SCULK_SPRUCE_CHEST_BOAT = register("sculk_spruce_chest_boat", new DDBoatItem(true, DDRegistration.itemProperties("sculk_spruce_chest_boat").stacksTo(1), DDBoat.Type.SCULK_SPRUCE));

    public static final Item ICE_LILY = register("ice_lily", new IceLilyItem(DDBlocks.ICE_LILY, DDRegistration.itemProperties("ice_lily")));
    public static final Item LILY_FLOWER = register("lily_flower", new LilyFlowerItem(DDBlocks.LILY_FLOWER, DDRegistration.itemProperties("lily_flower")));

    public static final Item SCULK_BONE = register("sculk_bone", new Item(DDRegistration.itemProperties("sculk_bone")));
    public static final Item SCULK_BONE_SHARD = register("sculk_bone_shard", new Item(DDRegistration.itemProperties("sculk_bone_shard")));
    public static final Item OTHERSIDE_FIRE_STRIKER = register("otherside_fire_striker", new OthersideFireStrikerItem(DDRegistration.itemProperties("otherside_fire_striker").durability(64)));
    public static final Item SOUL_DUST = register("soul_dust", new Item(DDRegistration.itemProperties("soul_dust")));
    public static final Item SOUL_CRYSTAL = register("soul_crystal", new Item(DDRegistration.itemProperties("soul_crystal")));
    public static final Item HEART_OF_THE_DEEP = register("heart_of_the_deep", new HeartOfTheDeepItem(DDRegistration.itemProperties("heart_of_the_deep").rarity(Rarity.RARE).fireResistant().stacksTo(1)));
    public static final Item WARDEN_CARAPACE = register("warden_carapace", new Item(DDRegistration.itemProperties("warden_carapace").rarity(Rarity.RARE).fireResistant()));
    public static final Item REINFORCED_ECHO_SHARD = register("reinforced_echo_shard", new Item(DDRegistration.itemProperties("reinforced_echo_shard").rarity(Rarity.RARE).fireResistant()));
    public static final Item RESONARIUM = register("resonarium", new Item(DDRegistration.itemProperties("resonarium").fireResistant()));
    public static final Item RESONARIUM_PLATE = register("resonarium_plate", new Item(DDRegistration.itemProperties("resonarium_plate").fireResistant()));
    public static final Item RAW_LEAD = register("raw_lead", new Item(DDRegistration.itemProperties("raw_lead")));
    public static final Item LEAD_INGOT = register("lead_ingot", new Item(DDRegistration.itemProperties("lead_ingot")));
    public static final Item RADIOACTIVE_INGOT = register("radioactive_ingot", new Item(DDRegistration.itemProperties("radioactive_ingot")));
    public static final Item WARDEN_UPGRADE_SMITHING_TEMPLATE = register("warden_upgrade_smithing_template", createWardenUpgradeSmithingTemplate(DDRegistration.itemProperties("warden_upgrade_smithing_template")));
    public static final Item GUARDIAN_UPGRADE_SMITHING_TEMPLATE = register("guardian_upgrade_smithing_template", createGuardianUpgradeSmithingTemplate(DDRegistration.itemProperties("guardian_upgrade_smithing_template")));
    public static final Item ROYAL_SCEPTER = register("royal_scepter", new Item(DDRegistration.itemProperties("royal_scepter").rarity(Rarity.RARE).stacksTo(1)));

    public static final Item PATIENCE_SOUL = register("patience_soul", new PatienceSoulItem(DDBlocks.PATIENCE_SOUL_FIRE, DDRegistration.itemProperties("patience_soul").rarity(Rarity.RARE).fireResistant(), DDParticleTypes.PATIENCE_SOUL));
    public static final Item FORTITUDE_SOUL = register("fortitude_soul", new FortitudeSoulItem(DDBlocks.FORTITUDE_SOUL_FIRE, DDRegistration.itemProperties("fortitude_soul").rarity(Rarity.RARE).fireResistant(), DDParticleTypes.FORTITUDE_SOUL));
    public static final Item CORRUPTION_SOUL = register("corruption_soul", new CorruptionSoulItem(DDBlocks.CORRUPTION_SOUL_FIRE, DDRegistration.itemProperties("corruption_soul").rarity(Rarity.RARE).fireResistant(), DDParticleTypes.CORRUPTION_SOUL));
    public static final Item PURITY_SOUL = register("purity_soul", new PuritySoulItem(DDBlocks.PURITY_SOUL_FIRE, DDRegistration.itemProperties("purity_soul").rarity(Rarity.RARE).fireResistant(), DDParticleTypes.PURITY_SOUL));
    public static final Item VIRTUE_SOUL = register("virtue_soul", new VirtueSoulItem(DDBlocks.VIRTUE_SOUL_FIRE, DDRegistration.itemProperties("virtue_soul").rarity(Rarity.RARE).fireResistant(), DDParticleTypes.VIRTUE_SOUL));

    public static final Item WARDEN_SHOVEL = register("warden_shovel", new Item(DDRegistration.itemProperties("warden_shovel").rarity(Rarity.RARE).fireResistant().shovel(DDTiers.WARDEN, 1.5f, -3)));
    public static final Item WARDEN_PICKAXE = register("warden_pickaxe", new Item(DDRegistration.itemProperties("warden_pickaxe").rarity(Rarity.RARE).fireResistant().pickaxe(DDTiers.WARDEN, 1, -2.8f)));
    public static final Item WARDEN_AXE = register("warden_axe", new Item(DDRegistration.itemProperties("warden_axe").rarity(Rarity.RARE).fireResistant().axe(DDTiers.WARDEN, 5, -3)));
    public static final Item WARDEN_HOE = register("warden_hoe", new Item(DDRegistration.itemProperties("warden_hoe").rarity(Rarity.RARE).fireResistant().hoe(DDTiers.WARDEN, -4, 0)));
    public static final Item WARDEN_SWORD = register("warden_sword", new Item(DDRegistration.itemProperties("warden_sword").rarity(Rarity.RARE).fireResistant().sword(DDTiers.WARDEN, 3, -2.4f)));
    public static final Item WARDEN_HELMET = register("warden_helmet", new WardenArmorItem(DDArmorMaterials.WARDEN, ArmorType.HELMET, DDRegistration.itemProperties("warden_helmet").rarity(Rarity.RARE).fireResistant(), List.of(MobEffects.BLINDNESS, MobEffects.DARKNESS)));
    public static final Item WARDEN_CHESTPLATE = register("warden_chestplate", new WardenArmorItem(DDArmorMaterials.WARDEN, ArmorType.CHESTPLATE, DDRegistration.itemProperties("warden_chestplate").rarity(Rarity.RARE).fireResistant()));
    public static final Item WARDEN_LEGGINGS = register("warden_leggings", new WardenArmorItem(DDArmorMaterials.WARDEN, ArmorType.LEGGINGS, DDRegistration.itemProperties("warden_leggings").rarity(Rarity.RARE).fireResistant()));
    public static final Item WARDEN_BOOTS = register("warden_boots", new WardenArmorItem(DDArmorMaterials.WARDEN, ArmorType.BOOTS, DDRegistration.itemProperties("warden_boots").rarity(Rarity.RARE).fireResistant()));

    public static final Item RESONARIUM_HELMET = register("resonarium_helmet", new ResonariumArmorItem(DDArmorMaterials.RESONARIUM, ArmorType.HELMET, DDRegistration.itemProperties("resonarium_helmet").rarity(Rarity.UNCOMMON).fireResistant()));
    public static final Item RESONARIUM_CHESTPLATE = register("resonarium_chestplate", new ResonariumArmorItem(DDArmorMaterials.RESONARIUM, ArmorType.CHESTPLATE, DDRegistration.itemProperties("resonarium_chestplate").rarity(Rarity.UNCOMMON).fireResistant()));
    public static final Item RESONARIUM_LEGGINGS = register("resonarium_leggings", new ResonariumArmorItem(DDArmorMaterials.RESONARIUM, ArmorType.LEGGINGS, DDRegistration.itemProperties("resonarium_leggings").rarity(Rarity.UNCOMMON).fireResistant()));
    public static final Item RESONARIUM_BOOTS = register("resonarium_boots", new ResonariumArmorItem(DDArmorMaterials.RESONARIUM, ArmorType.BOOTS, DDRegistration.itemProperties("resonarium_boots").rarity(Rarity.UNCOMMON).fireResistant()));
    public static final Item RESONARIUM_SHOVEL = register("resonarium_shovel", new Item(DDRegistration.itemProperties("resonarium_shovel").rarity(Rarity.UNCOMMON).fireResistant().shovel(DDTiers.RESONARIUM, 1.5f, -3)));
    public static final Item RESONARIUM_PICKAXE = register("resonarium_pickaxe", new Item(DDRegistration.itemProperties("resonarium_pickaxe").rarity(Rarity.UNCOMMON).fireResistant().pickaxe(DDTiers.RESONARIUM, 1, -2.8f)));
    public static final Item RESONARIUM_AXE = register("resonarium_axe", new Item(DDRegistration.itemProperties("resonarium_axe").rarity(Rarity.UNCOMMON).fireResistant().axe(DDTiers.RESONARIUM, 5, -3)));
    public static final Item RESONARIUM_HOE = register("resonarium_hoe", new Item(DDRegistration.itemProperties("resonarium_hoe").rarity(Rarity.UNCOMMON).fireResistant().hoe(DDTiers.RESONARIUM, -4, 0)));
    public static final Item RESONARIUM_SWORD = register("resonarium_sword", new Item(DDRegistration.itemProperties("resonarium_sword").rarity(Rarity.UNCOMMON).fireResistant().sword(DDTiers.RESONARIUM, 3, -2.4f)));

    public static final Item LEAD_HELMET = register("lead_helmet", new Item(DDRegistration.itemProperties("lead_helmet").humanoidArmor(DDArmorMaterials.LEAD, ArmorType.HELMET)));
    public static final Item LEAD_CHESTPLATE = register("lead_chestplate", new Item(DDRegistration.itemProperties("lead_chestplate").humanoidArmor(DDArmorMaterials.LEAD, ArmorType.CHESTPLATE)));
    public static final Item LEAD_LEGGINGS = register("lead_leggings", new Item(DDRegistration.itemProperties("lead_leggings").humanoidArmor(DDArmorMaterials.LEAD, ArmorType.LEGGINGS)));
    public static final Item LEAD_BOOTS = register("lead_boots", new Item(DDRegistration.itemProperties("lead_boots").humanoidArmor(DDArmorMaterials.LEAD, ArmorType.BOOTS)));
    public static final Item LEAD_SHOVEL = register("lead_shovel", new Item(DDRegistration.itemProperties("lead_shovel").shovel(DDTiers.LEAD, 1.5f, -3.0f)));
    public static final Item LEAD_PICKAXE = register("lead_pickaxe", new Item(DDRegistration.itemProperties("lead_pickaxe").pickaxe(DDTiers.LEAD, 1, -2.8f)));
    public static final Item LEAD_AXE = register("lead_axe", new Item(DDRegistration.itemProperties("lead_axe").axe(DDTiers.LEAD, 6.0f, -3.1f)));
    public static final Item LEAD_HOE = register("lead_hoe", new Item(DDRegistration.itemProperties("lead_hoe").hoe(DDTiers.LEAD, -2, -1.0f)));
    public static final Item LEAD_SWORD = register("lead_sword", new Item(DDRegistration.itemProperties("lead_sword").sword(DDTiers.LEAD, 3, -2.4f)));

    public static final Item RADIOACTIVE_HELMET = register("radioactive_helmet", new Item(DDRegistration.itemProperties("radioactive_helmet").humanoidArmor(DDArmorMaterials.RADIOACTIVE, ArmorType.HELMET)));
    public static final Item RADIOACTIVE_CHESTPLATE = register("radioactive_chestplate", new Item(DDRegistration.itemProperties("radioactive_chestplate").humanoidArmor(DDArmorMaterials.RADIOACTIVE, ArmorType.CHESTPLATE)));
    public static final Item RADIOACTIVE_LEGGINGS = register("radioactive_leggings", new Item(DDRegistration.itemProperties("radioactive_leggings").humanoidArmor(DDArmorMaterials.RADIOACTIVE, ArmorType.LEGGINGS)));
    public static final Item RADIOACTIVE_BOOTS = register("radioactive_boots", new Item(DDRegistration.itemProperties("radioactive_boots").humanoidArmor(DDArmorMaterials.RADIOACTIVE, ArmorType.BOOTS)));
    public static final Item RADIOACTIVE_SHOVEL = register("radioactive_shovel", new Item(DDRegistration.itemProperties("radioactive_shovel").shovel(DDTiers.RADIOACTIVE, 1.5f, -3.0f)));
    public static final Item RADIOACTIVE_PICKAXE = register("radioactive_pickaxe", new Item(DDRegistration.itemProperties("radioactive_pickaxe").pickaxe(DDTiers.RADIOACTIVE, 1, -2.8f)));
    public static final Item RADIOACTIVE_AXE = register("radioactive_axe", new Item(DDRegistration.itemProperties("radioactive_axe").axe(DDTiers.RADIOACTIVE, 5.0f, -3.1f)));
    public static final Item RADIOACTIVE_HOE = register("radioactive_hoe", new Item(DDRegistration.itemProperties("radioactive_hoe").hoe(DDTiers.RADIOACTIVE, -3, 0.0f)));
    public static final Item RADIOACTIVE_SWORD = register("radioactive_sword", new Item(DDRegistration.itemProperties("radioactive_sword").sword(DDTiers.RADIOACTIVE, 3, -2.4f)));

    public static final Item GUARDIAN_HELMET = register("guardian_helmet", new WardenArmorItem(DDArmorMaterials.GUARDIAN, ArmorType.HELMET, DDRegistration.itemProperties("guardian_helmet").rarity(Rarity.EPIC).fireResistant(), List.of(MobEffects.BLINDNESS, MobEffects.DARKNESS)));
    public static final Item GUARDIAN_CHESTPLATE = register("guardian_chestplate", new WardenArmorItem(DDArmorMaterials.GUARDIAN, ArmorType.CHESTPLATE, DDRegistration.itemProperties("guardian_chestplate").rarity(Rarity.EPIC).fireResistant()));
    public static final Item GUARDIAN_LEGGINGS = register("guardian_leggings", new WardenArmorItem(DDArmorMaterials.GUARDIAN, ArmorType.LEGGINGS, DDRegistration.itemProperties("guardian_leggings").rarity(Rarity.EPIC).fireResistant()));
    public static final Item GUARDIAN_BOOTS = register("guardian_boots", new WardenArmorItem(DDArmorMaterials.GUARDIAN, ArmorType.BOOTS, DDRegistration.itemProperties("guardian_boots").rarity(Rarity.EPIC).fireResistant()));
    public static final Item GUARDIAN_SHOVEL = register("guardian_shovel", new Item(DDRegistration.itemProperties("guardian_shovel").rarity(Rarity.EPIC).fireResistant().shovel(DDTiers.GUARDIAN, 1.5f, -3.0f)));
    public static final Item GUARDIAN_PICKAXE = register("guardian_pickaxe", new Item(DDRegistration.itemProperties("guardian_pickaxe").rarity(Rarity.EPIC).fireResistant().pickaxe(DDTiers.GUARDIAN, 1, -2.8f)));
    public static final Item GUARDIAN_AXE = register("guardian_axe", new Item(DDRegistration.itemProperties("guardian_axe").rarity(Rarity.EPIC).fireResistant().axe(DDTiers.GUARDIAN, 5.0f, -3.1f)));
    public static final Item GUARDIAN_HOE = register("guardian_hoe", new Item(DDRegistration.itemProperties("guardian_hoe").rarity(Rarity.EPIC).fireResistant().hoe(DDTiers.GUARDIAN, -3, 0.0f)));
    public static final Item GUARDIAN_SWORD = register("guardian_sword", new Item(DDRegistration.itemProperties("guardian_sword").rarity(Rarity.EPIC).fireResistant().sword(DDTiers.GUARDIAN, 3, -2.4f)));

    public static final Item SCULK_TRANSMITTER = register("sculk_transmitter", new SculkTransmitterItem(DDRegistration.itemProperties("sculk_transmitter").stacksTo(1).rarity(Rarity.RARE)));
    public static final Item WHITE_SCULK_TRANSMITTER = register("white_sculk_transmitter", new SculkTransmitterItem(DDRegistration.itemProperties("white_sculk_transmitter").stacksTo(1).rarity(Rarity.RARE)));
    public static final Item ORANGE_SCULK_TRANSMITTER = register("orange_sculk_transmitter", new SculkTransmitterItem(DDRegistration.itemProperties("orange_sculk_transmitter").stacksTo(1).rarity(Rarity.RARE)));
    public static final Item MAGENTA_SCULK_TRANSMITTER = register("magenta_sculk_transmitter", new SculkTransmitterItem(DDRegistration.itemProperties("magenta_sculk_transmitter").stacksTo(1).rarity(Rarity.RARE)));
    public static final Item LIGHT_BLUE_SCULK_TRANSMITTER = register("light_blue_sculk_transmitter", new SculkTransmitterItem(DDRegistration.itemProperties("light_blue_sculk_transmitter").stacksTo(1).rarity(Rarity.RARE)));
    public static final Item YELLOW_SCULK_TRANSMITTER = register("yellow_sculk_transmitter", new SculkTransmitterItem(DDRegistration.itemProperties("yellow_sculk_transmitter").stacksTo(1).rarity(Rarity.RARE)));
    public static final Item LIME_SCULK_TRANSMITTER = register("lime_sculk_transmitter", new SculkTransmitterItem(DDRegistration.itemProperties("lime_sculk_transmitter").stacksTo(1).rarity(Rarity.RARE)));
    public static final Item PINK_SCULK_TRANSMITTER = register("pink_sculk_transmitter", new SculkTransmitterItem(DDRegistration.itemProperties("pink_sculk_transmitter").stacksTo(1).rarity(Rarity.RARE)));
    public static final Item GRAY_SCULK_TRANSMITTER = register("gray_sculk_transmitter", new SculkTransmitterItem(DDRegistration.itemProperties("gray_sculk_transmitter").stacksTo(1).rarity(Rarity.RARE)));
    public static final Item LIGHT_GRAY_SCULK_TRANSMITTER = register("light_gray_sculk_transmitter", new SculkTransmitterItem(DDRegistration.itemProperties("light_gray_sculk_transmitter").stacksTo(1).rarity(Rarity.RARE)));
    public static final Item CYAN_SCULK_TRANSMITTER = register("cyan_sculk_transmitter", new SculkTransmitterItem(DDRegistration.itemProperties("cyan_sculk_transmitter").stacksTo(1).rarity(Rarity.RARE)));
    public static final Item PURPLE_SCULK_TRANSMITTER = register("purple_sculk_transmitter", new SculkTransmitterItem(DDRegistration.itemProperties("purple_sculk_transmitter").stacksTo(1).rarity(Rarity.RARE)));
    public static final Item BLUE_SCULK_TRANSMITTER = register("blue_sculk_transmitter", new SculkTransmitterItem(DDRegistration.itemProperties("blue_sculk_transmitter").stacksTo(1).rarity(Rarity.RARE)));
    public static final Item BROWN_SCULK_TRANSMITTER = register("brown_sculk_transmitter", new SculkTransmitterItem(DDRegistration.itemProperties("brown_sculk_transmitter").stacksTo(1).rarity(Rarity.RARE)));
    public static final Item GREEN_SCULK_TRANSMITTER = register("green_sculk_transmitter", new SculkTransmitterItem(DDRegistration.itemProperties("green_sculk_transmitter").stacksTo(1).rarity(Rarity.RARE)));
    public static final Item RED_SCULK_TRANSMITTER = register("red_sculk_transmitter", new SculkTransmitterItem(DDRegistration.itemProperties("red_sculk_transmitter").stacksTo(1).rarity(Rarity.RARE)));
    public static final Item BLACK_SCULK_TRANSMITTER = register("black_sculk_transmitter", new SculkTransmitterItem(DDRegistration.itemProperties("black_sculk_transmitter").stacksTo(1).rarity(Rarity.RARE)));
    public static final Item SUPER_SCULK_TRANSMITTER = register("super_sculk_transmitter", new SculkTransmitterItem(DDRegistration.itemProperties("super_sculk_transmitter").stacksTo(1).rarity(Rarity.EPIC)));
    public static final Item SONOROUS_STAFF = register("sonorous_staff", new SonorousStaffItem(DDRegistration.itemProperties("sonorous_staff").durability(320).rarity(Rarity.RARE)));

    public static final Item ANGLER_FISH_SPAWN_EGG = register("angler_fish_spawn_egg", new SpawnEggItem(DDRegistration.itemProperties("angler_fish_spawn_egg").spawnEgg(DDEntities.ANGLER_FISH)));
    public static final Item SCULK_CENTIPEDE_SPAWN_EGG = register("sculk_centipede_spawn_egg", new SpawnEggItem(DDRegistration.itemProperties("sculk_centipede_spawn_egg").spawnEgg(DDEntities.SCULK_CENTIPEDE)));
    public static final Item SCULK_LEECH_SPAWN_EGG = register("sculk_leech_spawn_egg", new SpawnEggItem(DDRegistration.itemProperties("sculk_leech_spawn_egg").spawnEgg(DDEntities.SCULK_LEECH)));
    public static final Item SCULK_SNAPPER_SPAWN_EGG = register("sculk_snapper_spawn_egg", new SpawnEggItem(DDRegistration.itemProperties("sculk_snapper_spawn_egg").spawnEgg(DDEntities.SCULK_SNAPPER)));
    public static final Item SHATTERED_SPAWN_EGG = register("shattered_spawn_egg", new SpawnEggItem(DDRegistration.itemProperties("shattered_spawn_egg").spawnEgg(DDEntities.SHATTERED)));
    public static final Item SHRIEK_WORM_SPAWN_EGG = register("shriek_worm_spawn_egg", new SpawnEggItem(DDRegistration.itemProperties("shriek_worm_spawn_egg").spawnEgg(DDEntities.SHRIEK_WORM)));
    public static final Item SLUDGE_SPAWN_EGG = register("sludge_spawn_egg", new SpawnEggItem(DDRegistration.itemProperties("sludge_spawn_egg").spawnEgg(DDEntities.SLUDGE)));
    public static final Item STALKER_SPAWN_EGG = register("stalker_spawn_egg", new SpawnEggItem(DDRegistration.itemProperties("stalker_spawn_egg").spawnEgg(DDEntities.STALKER)));
    public static final Item POTTY_SPAWN_EGG = register("potty_spawn_egg", new SpawnEggItem(DDRegistration.itemProperties("potty_spawn_egg").spawnEgg(DDEntities.POTTY)));
    public static final Item POT_SPAWN_EGG = register("pot_spawn_egg", new SpawnEggItem(DDRegistration.itemProperties("pot_spawn_egg").spawnEgg(DDEntities.POT)));
    public static final Item POTTER_SPAWN_EGG = register("potter_spawn_egg", new SpawnEggItem(DDRegistration.itemProperties("potter_spawn_egg").spawnEgg(DDEntities.POTTER)));
    public static final Item ACID_SPRITE_SPAWN_EGG = register("acid_sprite_spawn_egg", new SpawnEggItem(DDRegistration.itemProperties("acid_sprite_spawn_egg").spawnEgg(DDEntities.ACID_SPRITE)));

    public static final Item ECHO_SIGN = register("echo_sign", new StandingAndWallBlockItem(DDBlocks.ECHO_SIGN, DDBlocks.ECHO_WALL_SIGN, Direction.DOWN, DDRegistration.itemProperties("echo_sign").stacksTo(16).signText()));
    public static final Item ECHO_HANGING_SIGN = register("echo_hanging_sign", new HangingSignItem(DDBlocks.ECHO_HANGING_SIGN, DDBlocks.ECHO_WALL_HANGING_SIGN, DDRegistration.itemProperties("echo_hanging_sign").stacksTo(16)));
    public static final Item BLOOM_SIGN = register("bloom_sign", new StandingAndWallBlockItem(DDBlocks.BLOOM_SIGN, DDBlocks.BLOOM_WALL_SIGN, Direction.DOWN, DDRegistration.itemProperties("bloom_sign").stacksTo(16).signText()));
    public static final Item BLOOM_HANGING_SIGN = register("bloom_hanging_sign", new HangingSignItem(DDBlocks.BLOOM_HANGING_SIGN, DDBlocks.BLOOM_WALL_HANGING_SIGN, DDRegistration.itemProperties("bloom_hanging_sign").stacksTo(16)));
    public static final Item SCULK_SPRUCE_SIGN = register("sculk_spruce_sign", new StandingAndWallBlockItem(DDBlocks.SCULK_SPRUCE_SIGN, DDBlocks.SCULK_SPRUCE_WALL_SIGN, Direction.DOWN, DDRegistration.itemProperties("sculk_spruce_sign").stacksTo(16).signText()));
    public static final Item SCULK_SPRUCE_HANGING_SIGN = register("sculk_spruce_hanging_sign", new HangingSignItem(DDBlocks.SCULK_SPRUCE_HANGING_SIGN, DDBlocks.SCULK_SPRUCE_WALL_HANGING_SIGN, DDRegistration.itemProperties("sculk_spruce_hanging_sign").stacksTo(16)));

    public static final Item BLOOM_BERRIES = register("bloom_berries", new BlockItem(DDBlocks.GLOWING_VINES, DDRegistration.itemProperties("bloom_berries").food(new FoodProperties.Builder().nutrition(2).saturationModifier(0.1f).build(), Consumables.defaultFood().onConsume(new ApplyStatusEffectsConsumeEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0), 0.8f)).build()).useItemDescriptionPrefix()));
    public static final Item SCULK_TUBER = register("sculk_tuber", new Item(DDRegistration.itemProperties("sculk_tuber").food(new FoodProperties.Builder().nutrition(4).saturationModifier(0.6f).build())));
    public static final Item SCULK_BERRY = register("sculk_berry", new Item(DDRegistration.itemProperties("sculk_berry").food(new FoodProperties.Builder().nutrition(8).saturationModifier(0.8f).build())));
    public static final Item SCULK_BERRY_SPROUT = register("sculk_berry_sprout", new BlockItem(DDBlocks.SCULK_BERRY, DDRegistration.itemProperties("sculk_berry_sprout").food(new FoodProperties.Builder().nutrition(2).saturationModifier(0.2f).build()).useItemDescriptionPrefix()));

    public static final Item SCULK_TISSUE_BRICK = register("sculk_tissue_brick", new Item(DDRegistration.itemProperties("sculk_tissue_brick")));
    public static final Item SHADOW_CRYSTAL = register("shadow_crystal", new Item(DDRegistration.itemProperties("shadow_crystal")));
    public static final Item SUNGLASSES = register("sunglasses", new SunglassesItem(DDRegistration.itemProperties("sunglasses").stacksTo(1)));
    public static final Item DAINTY_KEY = register("dainty_key", new Item(DDRegistration.itemProperties("dainty_key").rarity(Rarity.RARE).stacksTo(1)));
    public static final Item KEYBRAND = register("keybrand", new Item(DDRegistration.itemProperties("keybrand").rarity(Rarity.EPIC).fireResistant().stacksTo(1)));

    public static final Item SHATTERED_HEAD = register("shattered_head", new StandingAndWallBlockItem(DDBlocks.SHATTERED_HEAD, DDBlocks.SHATTERED_WALL_HEAD, Direction.DOWN, DDRegistration.itemProperties("shattered_head").rarity(Rarity.UNCOMMON)));

    public static final Item SCULK_TORCH = register("sculk_torch", new StandingAndWallBlockItem(DDBlocks.SCULK_TORCH, DDBlocks.SCULK_WALL_TORCH, Direction.DOWN, DDRegistration.itemProperties("sculk_torch")));

    public static final Item ACID_BUCKET = register("acid_bucket", new BucketItem(DDFluids.ACID, DDRegistration.itemProperties("acid_bucket").craftRemainder(Items.BUCKET).stacksTo(1)));
    public static final Item FIZZ = register("fizz", new Item(DDRegistration.itemProperties("fizz")));
    public static final Item SCULK_DRINK = register("sculk_drink", new SculkDrinkItem(DDRegistration.itemProperties("sculk_drink").craftRemainder(Items.BUCKET).food(new FoodProperties.Builder().nutrition(10).saturationModifier(1.2f).build()).stacksTo(1)));
    public static final Item SHIELD_AUGMENT = register("shield_augment", new Item(DDRegistration.itemProperties("shield_augment").stacksTo(1).rarity(Rarity.RARE)));

    public static Item register(String id, Item item) {
        return Registry.register(BuiltInRegistries.ITEM, Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, id), item);
    }

    private static Item createWardenUpgradeSmithingTemplate(Item.Properties properties) {
        return new SmithingTemplateItem(Component.translatable(Util.makeDescriptionId("item", Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "smithing_template.warden_upgrade.applies_to"))).withStyle(ChatFormatting.BLUE),
                Component.translatable(Util.makeDescriptionId("item", Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "smithing_template.warden_upgrade.ingredients"))).withStyle(ChatFormatting.BLUE),
                Component.translatable(Util.makeDescriptionId("item", Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "smithing_template.warden_upgrade.base_slot_description"))),
                Component.translatable(Util.makeDescriptionId("item", Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "smithing_template.warden_upgrade.additions_slot_description"))),
                getWardenEmptyBaseSlotTextures(),
                getWardenEmptyAdditionsSlotTextures(),
                properties);
    }

    private static List<Identifier> getWardenEmptyBaseSlotTextures() {
        return List.of(Identifier.parse("item/empty_armor_slot_helmet"),
                Identifier.parse("item/empty_armor_slot_chestplate"),
                Identifier.parse("item/empty_armor_slot_leggings"),
                Identifier.parse("item/empty_armor_slot_boots"),
                Identifier.parse("item/empty_slot_sword"),
                Identifier.parse("item/empty_slot_pickaxe"),
                Identifier.parse("item/empty_slot_axe"),
                Identifier.parse("item/empty_slot_shovel"),
                Identifier.parse("item/empty_slot_hoe"));
    }

    private static List<Identifier> getWardenEmptyAdditionsSlotTextures() {
        return List.of(Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "item/empty_slot_reinforced_echo_shard"));
    }

    private static Item createGuardianUpgradeSmithingTemplate(Item.Properties properties) {
        return new SmithingTemplateItem(Component.translatable(Util.makeDescriptionId("item", Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "smithing_template.guardian_upgrade.applies_to"))).withStyle(ChatFormatting.BLUE),
                Component.translatable(Util.makeDescriptionId("item", Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "smithing_template.guardian_upgrade.ingredients"))).withStyle(ChatFormatting.BLUE),
                Component.translatable(Util.makeDescriptionId("item", Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "smithing_template.guardian_upgrade.base_slot_description"))),
                Component.translatable(Util.makeDescriptionId("item", Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "smithing_template.guardian_upgrade.additions_slot_description"))),
                getGuardianEmptyBaseSlotTextures(),
                getGuardianEmptyAdditionsSlotTextures(),
                properties);
    }

    private static List<Identifier> getGuardianEmptyBaseSlotTextures() {
        return List.of(Identifier.parse("item/empty_armor_slot_helmet"),
                Identifier.parse("item/empty_armor_slot_chestplate"),
                Identifier.parse("item/empty_armor_slot_leggings"),
                Identifier.parse("item/empty_armor_slot_boots"),
                Identifier.parse("item/empty_slot_sword"),
                Identifier.parse("item/empty_slot_pickaxe"),
                Identifier.parse("item/empty_slot_axe"),
                Identifier.parse("item/empty_slot_shovel"),
                Identifier.parse("item/empty_slot_hoe"));
    }

    private static List<Identifier> getGuardianEmptyAdditionsSlotTextures() {
        return List.of(Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "item/empty_slot_virtue_soul"));
    }

    public static void init() {
        DeeperDarker.LOGGER.debug("Registering items");








    }
}
