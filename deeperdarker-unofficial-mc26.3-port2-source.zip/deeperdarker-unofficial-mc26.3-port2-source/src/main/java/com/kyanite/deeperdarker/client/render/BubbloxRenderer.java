// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.client.render;
import com.kyanite.deeperdarker.client.DDModelLayers;
import com.kyanite.deeperdarker.client.model.BubbloxModel;
import com.kyanite.deeperdarker.client.state.DDModelRenderState;
import com.kyanite.deeperdarker.content.entities.Bubblox;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;
public class BubbloxRenderer<T extends Bubblox> extends EntityRenderer<T, DDModelRenderState> {
    private static final Identifier TEXTURE = Identifier.fromNamespaceAndPath("deeperdarker", "textures/entity/bubblox.png");
    private final BubbloxModel<T> model;
    public BubbloxRenderer(EntityRendererProvider.Context context) {
        super(context); model = new BubbloxModel<>(context.bakeLayer(DDModelLayers.BUBBLOX));
    }
    @Override public DDModelRenderState createRenderState() { return new DDModelRenderState(); }
    @Override protected int getBlockLightLevel(T entity, BlockPos pos) { return 15; }
    @Override public void extractRenderState(T entity, DDModelRenderState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);
        state.texture = TEXTURE;
        state.parts = model.capturePose(entity, state);
    }
    @Override public void submit(DDModelRenderState state, PoseStack poses, SubmitNodeCollector nodes, CameraRenderState camera) {
        super.submit(state, poses, nodes, camera);
        poses.pushPose();
        poses.translate(0, state.boundingBoxHeight / 2, 0);
        poses.scale(-1, -1, 1);
        nodes.submitModel(model, state, poses, model.renderType(TEXTURE), state.lightCoords, OverlayTexture.NO_OVERLAY, 0xFFFFFFFF);
        poses.popPose();
    }
}
