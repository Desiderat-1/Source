package com.kyanite.deeperdarker.content.entities;

import com.kyanite.deeperdarker.content.DDItems;
import net.minecraft.world.item.Item;
import java.util.function.Supplier;

/** Supplies the current synchronized wood variant to the engine's final drop/pick methods. */
final class DDBoatDropSupplier implements Supplier<Item> {
    private final boolean chest;
    private DDBoatLike boat;
    DDBoatDropSupplier(boolean chest) { this.chest = chest; }
    void bind(DDBoatLike boat) { this.boat = boat; }
    public Item get() {
        DDBoat.Type type = boat == null ? DDBoat.Type.ECHO : boat.getWoodType();
        if (chest) return switch (type) {
            case BLOOM -> DDItems.BLOOM_CHEST_BOAT;
            case SCULK_SPRUCE -> DDItems.SCULK_SPRUCE_CHEST_BOAT;
            default -> DDItems.ECHO_CHEST_BOAT;
        };
        return switch (type) {
            case BLOOM -> DDItems.BLOOM_BOAT;
            case SCULK_SPRUCE -> DDItems.SCULK_SPRUCE_BOAT;
            default -> DDItems.ECHO_BOAT;
        };
    }
}
