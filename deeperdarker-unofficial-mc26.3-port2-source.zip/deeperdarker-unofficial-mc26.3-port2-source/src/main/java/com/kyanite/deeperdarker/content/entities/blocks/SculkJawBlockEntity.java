package com.kyanite.deeperdarker.content.entities.blocks;

import com.kyanite.deeperdarker.content.DDBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class SculkJawBlockEntity extends BlockEntity {
    private int experience;

    public SculkJawBlockEntity(BlockPos blockPos, BlockState blockState) {
        super(DDBlockEntities.SCULK_JAW, blockPos, blockState);
    }

    @Override
    protected void loadAdditional(net.minecraft.world.level.storage.ValueInput compoundTag) {
        super.loadAdditional(compoundTag);
        this.experience = compoundTag.getIntOr("experience", 0);
    }

    @Override
    protected void saveAdditional(net.minecraft.world.level.storage.ValueOutput compoundTag) {
        super.saveAdditional(compoundTag);
        compoundTag.putInt("experience", this.experience);
    }

    public int getExperience() {
        return this.experience;
    }

    public void setExperience(int experience) {
        this.experience = experience;
        setChanged();
    }

    @Override
    public void preRemoveSideEffects(BlockPos pos, BlockState replacement) {
        super.preRemoveSideEffects(pos, replacement);
        if (getBlockState().is(replacement.getBlock())) return;
        if (level instanceof net.minecraft.server.level.ServerLevel server
                && getBlockState().getBlock() instanceof com.kyanite.deeperdarker.content.blocks.SculkJawBlock jaw) {
            jaw.releaseExperience(server, pos, experience);
            experience = 0;
        }
    }

    public void addExperience(int experience) {
        this.setExperience(this.getExperience() + experience);
    }

    public void stealExperienceFromPlayer(Player player, int amount) {
        amount = Math.min(player.totalExperience, amount);
        player.giveExperiencePoints(-amount);
        this.addExperience(amount);
    }
}
