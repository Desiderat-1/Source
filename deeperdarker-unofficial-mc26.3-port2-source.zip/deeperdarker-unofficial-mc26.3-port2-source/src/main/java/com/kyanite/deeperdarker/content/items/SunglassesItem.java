// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.content.items;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;

public class SunglassesItem extends Item {
    public SunglassesItem(Properties properties) { super(properties.equippable(EquipmentSlot.HEAD)); }
    public static boolean isWearingSunglasses(LivingEntity entity) {
        return entity.getItemBySlot(EquipmentSlot.HEAD).getItem() instanceof SunglassesItem;
    }
}
