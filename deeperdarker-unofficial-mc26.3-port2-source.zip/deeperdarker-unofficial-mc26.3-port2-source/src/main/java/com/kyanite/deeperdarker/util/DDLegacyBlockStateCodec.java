// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.util;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.Dynamic;
import net.minecraft.nbt.NbtOps;
import net.minecraft.world.level.block.state.BlockState;

/** Read saved custom structure palettes from 1.20; write the current block-state format. */
public final class DDLegacyBlockStateCodec {
    public static final Codec<BlockState> CODEC = Codec.PASSTHROUGH.comapFlatMap(
            DDLegacyBlockStateCodec::read, state ->
                new Dynamic<>(NbtOps.INSTANCE, BlockState.CODEC.encodeStart(NbtOps.INSTANCE, state).getOrThrow()));
    private DDLegacyBlockStateCodec() {}
    private static <T> DataResult<BlockState> read(Dynamic<T> input) {
        var name = input.get("Name").result();
        if (name.isPresent()) {
            var properties = input.get("Properties").result();
            input = input.remove("Name").remove("Properties").set("id", name.get());
            if (properties.isPresent()) input = input.set("properties", properties.get());
        }
        return BlockState.CODEC.parse(input);
    }
}
