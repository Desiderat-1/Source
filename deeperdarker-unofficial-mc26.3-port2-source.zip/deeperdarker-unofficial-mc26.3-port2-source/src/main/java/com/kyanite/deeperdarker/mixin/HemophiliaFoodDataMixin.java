// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.mixin;

import com.kyanite.deeperdarker.content.DDEffects;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodData;
import net.minecraft.world.level.gamerules.GameRules;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(FoodData.class)
public abstract class HemophiliaFoodDataMixin {
    @WrapOperation(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/gamerules/GameRules;get(Lnet/minecraft/world/level/gamerules/GameRule;)Ljava/lang/Object;"))
    private Object deeperdarker$removeFoodNaturalRegeneration(GameRules instance, net.minecraft.world.level.gamerules.GameRule<?> key, Operation<Object> original, @Local(argsOnly = true) net.minecraft.server.level.ServerPlayer player) {
        if (key == GameRules.NATURAL_HEALTH_REGENERATION && player.hasEffect(DDEffects.HEMOPHILIA)) return false;
        return original.call(instance, key);
    }
}
