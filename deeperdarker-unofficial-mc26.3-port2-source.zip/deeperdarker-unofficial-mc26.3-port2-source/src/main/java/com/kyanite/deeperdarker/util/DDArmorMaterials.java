// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.util;

import net.minecraft.core.Holder;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAssets;
import java.util.Map;

public final class DDArmorMaterials {
    public static final ArmorMaterial LEAD = create("lead", 15, 2, 5, 6, 2, 9,
        Holder.direct(SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("deeperdarker", "item.armor.equip_lead"))), 0, 0);
    public static final ArmorMaterial RADIOACTIVE = create("radioactive", 36, 3, 6, 8, 3, 11, SoundEvents.ARMOR_EQUIP_IRON, 2, 1);
    public static final ArmorMaterial RESONARIUM = create("resonarium", 30, 2, 6, 7, 3, 10, SoundEvents.ARMOR_EQUIP_IRON, 1, 0);
    public static final ArmorMaterial WARDEN = create("warden", 40, 4, 7, 9, 4, 18, SoundEvents.ARMOR_EQUIP_NETHERITE, 4, 0.1F);
    public static final ArmorMaterial GUARDIAN = create("guardian", 100, 4, 7, 9, 4, 22, SoundEvents.ARMOR_EQUIP_NETHERITE, 6, 0.2F);
    private DDArmorMaterials() {}
    private static ArmorMaterial create(String name, int durability, int boots, int legs, int chest, int helmet,
            int enchantability, Holder<SoundEvent> sound, float toughness, float knockbackResistance) {
        return new ArmorMaterial(durability, Map.of(ArmorType.BOOTS, boots, ArmorType.LEGGINGS, legs,
            ArmorType.CHESTPLATE, chest, ArmorType.HELMET, helmet), enchantability, sound, toughness, knockbackResistance,
            DDTiers.repairTag(name), ResourceKey.create(EquipmentAssets.ROOT_ID, Identifier.fromNamespaceAndPath("deeperdarker", name)));
    }
}
