package com.kyanite.deeperdarker.world;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.tags.TagKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.CarverOutput;
import net.minecraft.world.level.levelgen.WorldGenerationContext;
import net.minecraft.world.level.levelgen.carver.CaveWorldCarver;
import net.minecraft.world.level.levelgen.carver.WorldCarver;

/** Original cave-shaped tissue veins: replace permitted blocks and air, rather than excavating them. */
public record DDNoodleCarver(CaveWorldCarver shape, TagKey<Block> replaceable, BlockState fill) implements WorldCarver {
    public static final MapCodec<DDNoodleCarver> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            CaveWorldCarver.MAP_CODEC.codec().fieldOf("shape").forGetter(DDNoodleCarver::shape),
            TagKey.hashedCodec(Registries.BLOCK).fieldOf("replaceable").forGetter(DDNoodleCarver::replaceable),
            BlockState.CODEC.fieldOf("fill").forGetter(DDNoodleCarver::fill)
    ).apply(instance, DDNoodleCarver::new));

    public boolean isStartChunk(RandomSource random) { return shape.isStartChunk(random); }
    public int getRange() { return shape.getRange(); }
    public MapCodec<DDNoodleCarver> codec() { return MAP_CODEC; }

    public boolean carve(WorldGenerationContext context, RandomSource random, ChunkPos target, ChunkPos origin, CarverOutput output) {
        if (!(output instanceof DDChunkCarverOutput chunkOutput)) {
            throw new IllegalArgumentException("Tissue veins require the chunk-aware worldgen output supplied by Deeper and Darker's generator Mixin");
        }
        var chunk = chunkOutput.chunk();
        if (!chunk.getPos().equals(target)) throw new IllegalArgumentException("Carver output belongs to a different chunk");
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        return shape.carve(context, random, target, origin, new CarverOutput() {
            public int minY() { return output.minY(); }
            public int maxY() { return output.maxY(); }
            public void carve(int x, int y, int z) {
                pos.set(target.getMinBlockX() + x, y, target.getMinBlockZ() + z);
                BlockState previous = chunk.getBlockState(pos);
                if (previous.isAir() || previous.is(replaceable)) chunk.setBlockState(pos, fill, 0);
            }
        });
    }
}
