// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.world.features;

import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.chunk.ChunkGenerator;

/** Local placement inputs; feature instances now own their decoded configuration. */
record DDFeatureContext<C>(C config, WorldGenLevel level, ChunkGenerator chunkGenerator, RandomSource random, BlockPos origin) {}
