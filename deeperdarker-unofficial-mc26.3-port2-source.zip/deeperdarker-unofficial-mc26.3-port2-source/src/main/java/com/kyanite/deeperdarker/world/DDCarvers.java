package com.kyanite.deeperdarker.world;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.levelgen.carver.WorldCarver;

/** Carvers now own their configuration and are loaded from worldgen/carver. */
public final class DDCarvers {
    public static final MapCodec<DDNoodleCarver> NOODLES = Registry.register(BuiltInRegistries.CARVER_TYPE,
            Identifier.fromNamespaceAndPath("deeperdarker", "noodles"), DDNoodleCarver.MAP_CODEC);
    public static final ResourceKey<WorldCarver> CONFIGURED_LARGE_CAVE = key("large_cave");
    public static final ResourceKey<WorldCarver> CONFIGURED_CAVE = key("cave");
    public static final ResourceKey<WorldCarver> CONFIGURED_LOW_CAVE = key("low_cave");
    public static final ResourceKey<WorldCarver> CONFIGURED_NOODLES = key("noodles");
    private static ResourceKey<WorldCarver> key(String name) {
        return ResourceKey.create(Registries.CARVER, Identifier.fromNamespaceAndPath("deeperdarker", name));
    }
    public static void init() { }
}
