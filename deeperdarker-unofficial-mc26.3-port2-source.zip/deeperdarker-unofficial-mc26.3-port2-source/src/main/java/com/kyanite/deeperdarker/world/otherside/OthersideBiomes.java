// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.world.otherside;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.biome.Biome;
public final class OthersideBiomes {
    public static final ResourceKey<Biome> DEEPLANDS = createKey("deeplands");
    public static final ResourceKey<Biome> LUSH_DEEPLANDS = createKey("lush_deeplands");
    public static final ResourceKey<Biome> ECHOING_FOREST = createKey("echoing_forest");
    public static final ResourceKey<Biome> BLOOMING_CAVERNS = createKey("blooming_caverns");
    public static final ResourceKey<Biome> OVERCAST_COLUMNS = createKey("overcast_columns");
    public static final ResourceKey<Biome> DARKLANDS = createKey("darklands");
    public static final ResourceKey<Biome> SCULK_SPRUCE_FOREST = createKey("sculk_spruce_forest");
    public static final ResourceKey<Biome> ACID_FLOES = createKey("acid_floes");
    private static ResourceKey<Biome> createKey(String name) { return ResourceKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("deeperdarker", name)); }
    private OthersideBiomes() {}
}
