package com.kyanite.deeperdarker.mixin;

import com.kyanite.deeperdarker.client.DDModelLayers;
import com.kyanite.deeperdarker.client.model.ShatteredHeadModel;
import com.kyanite.deeperdarker.content.blocks.ShatteredHeadBlock;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.object.skull.SkullModelBase;
import net.minecraft.client.renderer.blockentity.SkullBlockRenderer;
import net.minecraft.client.renderer.rendertype.*;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.SkullBlock;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(SkullBlockRenderer.class)
public abstract class ShatteredHeadRenderMixin {
    @Inject(method="createModel",at=@At("HEAD"),cancellable=true)
    private static void deeperdarker$model(EntityModelSet models,SkullBlock.Type type,CallbackInfoReturnable<SkullModelBase> cir){
        if(type==ShatteredHeadBlock.SHATTERED)cir.setReturnValue(new ShatteredHeadModel(models.bakeLayer(DDModelLayers.SHATTERED_HEAD)));
    }
    @Inject(method="getSkullRenderType",at=@At("HEAD"),cancellable=true)
    private static void deeperdarker$texture(SkullBlock.Type type,Identifier skin,CallbackInfoReturnable<RenderType> cir){
        if(type==ShatteredHeadBlock.SHATTERED)cir.setReturnValue(RenderTypes.entityTranslucent(Identifier.fromNamespaceAndPath("deeperdarker","textures/entity/shattered.png")));
    }
}
