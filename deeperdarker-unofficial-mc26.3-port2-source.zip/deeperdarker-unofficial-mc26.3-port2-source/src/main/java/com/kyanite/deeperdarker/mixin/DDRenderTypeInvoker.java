package com.kyanite.deeperdarker.mixin;

import net.minecraft.client.renderer.rendertype.RenderSetup;
import net.minecraft.client.renderer.rendertype.RenderType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(RenderType.class)
public interface DDRenderTypeInvoker {
    @Invoker("create")
    static RenderType deeperdarker$create(String name,RenderSetup setup){throw new AssertionError("Mixin not applied");}
}
