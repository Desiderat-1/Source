// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.content;

import com.kyanite.deeperdarker.DeeperDarker;
import com.kyanite.deeperdarker.content.entities.*;
import com.kyanite.deeperdarker.content.entities.acidsprite.AcidSprite;
import com.kyanite.deeperdarker.content.entities.overcastvessel.OvercastVessel;
import com.kyanite.deeperdarker.content.entities.overcastvessel.OvercastVesselItem;
import com.kyanite.deeperdarker.content.entities.overseer.Overseer;
import com.kyanite.deeperdarker.content.entities.overseer.OverseerCrystal;
import com.kyanite.deeperdarker.content.entities.overseer.OverseerLaser;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.*;
import net.minecraft.world.level.levelgen.Heightmap;

public class DDEntities {
    public static final EntityType<DDBoat> BOAT = register("boat", EntityType.Builder.<DDBoat>of(DDBoat::new, MobCategory.MISC).sized(1.375f, 0.5625f).clientTrackingRange(10).build(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "boat"))));
    public static final EntityType<DDChestBoat> CHEST_BOAT = register("chest_boat", EntityType.Builder.<DDChestBoat>of(DDChestBoat::new, MobCategory.MISC).sized(1.375f, 0.5625f).clientTrackingRange(10).build(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "chest_boat"))));
    public static final EntityType<IcicleShard> ICICLE_SHARD = register("icicle_shard", EntityType.Builder.<IcicleShard>of(IcicleShard::new, MobCategory.MISC).sized(0.3f, 0.3f).clientTrackingRange(10).build(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "icicle_shard"))));
    public static final EntityType<OvercastVesselItem> OVERCAST_VESSEL_ITEM = register("overcast_vessel_item", EntityType.Builder.<OvercastVesselItem>of(OvercastVesselItem::new, MobCategory.MISC).sized(0.25f, 0.25f).clientTrackingRange(10).build(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "overcast_vessel_item"))));
    public static final EntityType<OverseerCrystal> OVERSEER_CRYSTAL = register("overseer_crystal", EntityType.Builder.<OverseerCrystal>of(OverseerCrystal::new, MobCategory.MISC).sized(0.5f, 0.5f).clientTrackingRange(10).build(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "overseer_crystal"))));
    public static final EntityType<OverseerLaser> OVERSEER_LASER = register("overseer_laser", EntityType.Builder.<OverseerLaser>of(OverseerLaser::new, MobCategory.MISC).sized(0.0f, 0.0f).clientTrackingRange(10).build(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "overseer_laser"))));

    public static final EntityType<AnglerFish> ANGLER_FISH = register("angler_fish", EntityType.Builder.of(AnglerFish::new, MobCategory.WATER_CREATURE).sized(0.7f, 0.4f).clientTrackingRange(10).build(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "angler_fish"))));
    public static final EntityType<SculkCentipede> SCULK_CENTIPEDE = register("sculk_centipede", EntityType.Builder.of(SculkCentipede::new, MobCategory.MONSTER).sized(1f, 0.2f).clientTrackingRange(10).build(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "sculk_centipede"))));
    public static final EntityType<SculkLeech> SCULK_LEECH = register("sculk_leech", EntityType.Builder.of(SculkLeech::new, MobCategory.MONSTER).sized(0.42f, 0.2f).clientTrackingRange(10).build(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "sculk_leech"))));
    public static final EntityType<SculkSnapper> SCULK_SNAPPER = register("sculk_snapper", EntityType.Builder.of(SculkSnapper::new, MobCategory.MONSTER).sized(0.65f, 0.65f).clientTrackingRange(10).build(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "sculk_snapper"))));
    public static final EntityType<Shattered> SHATTERED = register("shattered", EntityType.Builder.of(Shattered::new, MobCategory.MONSTER).sized(0.8f, 2.125f).clientTrackingRange(10).build(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "shattered"))));
    public static final EntityType<ShriekWorm> SHRIEK_WORM = register("shriek_worm", EntityType.Builder.of(ShriekWorm::new, MobCategory.MONSTER).sized(1.0f, 5.7f).clientTrackingRange(10).build(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "shriek_worm"))));
    public static final EntityType<Sludge> SLUDGE = register("sludge", EntityType.Builder.of(Sludge::new, MobCategory.MONSTER).sized(2.04f, 2.04f).clientTrackingRange(10).build(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "sludge"))));
    public static final EntityType<Stalker> STALKER = register("stalker", EntityType.Builder.of(Stalker::new, MobCategory.MONSTER).sized(1f, 4.4f).clientTrackingRange(10).build(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "stalker"))));
    public static final EntityType<BloomingGolem> BLOOMING_GOLEM = register("blooming_golem", EntityType.Builder.<BloomingGolem>of(BloomingGolem::new, MobCategory.MONSTER).sized(3f, 3f).clientTrackingRange(10).build(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "blooming_golem"))));
    public static final EntityType<OvercastPot> POTTY = register("potty", EntityType.Builder.of(OvercastPot::new, MobCategory.MONSTER).sized(0.85f, 1.875f).clientTrackingRange(10).build(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "potty"))));
    public static final EntityType<OvercastPot> POT = register("pot", EntityType.Builder.of(OvercastPot::new, MobCategory.MONSTER).sized(0.85f, 1.2f).clientTrackingRange(10).build(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "pot"))));
    public static final EntityType<OvercastPot> POTTER = register("potter", EntityType.Builder.of(OvercastPot::new, MobCategory.MONSTER).sized(1.3f, 1.2f).clientTrackingRange(10).build(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "potter"))));
    public static final EntityType<OvercastVessel> OVERCAST_VESSEL = register("overcast_vessel", EntityType.Builder.<OvercastVessel>of(OvercastVessel::new, MobCategory.MONSTER).sized(3f, 3f).clientTrackingRange(10).build(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "overcast_vessel"))));
    public static final EntityType<AcidSprite> ACID_SPRITE = register("acid_sprite", EntityType.Builder.of(AcidSprite::new, MobCategory.MONSTER).sized(0.5f, 0.6f).clientTrackingRange(10).build(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "acid_sprite"))));
    public static final EntityType<Bubblox> BUBBLOX = register("bubblox", EntityType.Builder.<Bubblox>of(Bubblox::new, MobCategory.MONSTER).sized(1.0f, 1.0f).clientTrackingRange(10).build(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "bubblox"))));
    public static final EntityType<Overseer> OVERSEER = register("overseer", EntityType.Builder.of(Overseer::new, MobCategory.MONSTER).sized(2.0f, 2.0f).clientTrackingRange(10).build(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "overseer"))));
    public static final EntityType<Floater> FLOATER = register("floater", EntityType.Builder.of(Floater::new, MobCategory.MONSTER).sized(0.625f, 0.625f).clientTrackingRange(10).build(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "floater"))));

    public static void init() {
        DeeperDarker.LOGGER.debug("Registering Deeper and Darker entity types");
        registerAttributes();
        registerSpawnPlacements();
        SculkConversionRegistry.init(SHATTERED, SLUDGE);
    }

    private static void registerAttributes() {
        FabricDefaultAttributeRegistry.register(ANGLER_FISH, AnglerFish.createAttributeSupplier());
        FabricDefaultAttributeRegistry.register(SCULK_SNAPPER, SculkSnapper.createAttributes());
        FabricDefaultAttributeRegistry.register(SHATTERED, Shattered.createAttributes());
        FabricDefaultAttributeRegistry.register(SCULK_LEECH, SculkLeech.createAttributes());
        FabricDefaultAttributeRegistry.register(SHRIEK_WORM, ShriekWorm.createAttributes());
        FabricDefaultAttributeRegistry.register(STALKER, Stalker.createAttributes());
        FabricDefaultAttributeRegistry.register(SLUDGE, Sludge.createAttributes());
        FabricDefaultAttributeRegistry.register(SCULK_CENTIPEDE, SculkCentipede.createAttributes());
        FabricDefaultAttributeRegistry.register(BLOOMING_GOLEM, BloomingGolem.createAttributes());
        FabricDefaultAttributeRegistry.register(POTTY, OvercastPot.createAttributes(-10));
        FabricDefaultAttributeRegistry.register(POT, OvercastPot.createAttributes(0));
        FabricDefaultAttributeRegistry.register(POTTER, OvercastPot.createAttributes(10));
        FabricDefaultAttributeRegistry.register(OVERCAST_VESSEL, OvercastVessel.createAttributes());
        FabricDefaultAttributeRegistry.register(ACID_SPRITE, AcidSprite.createAttributes());
        FabricDefaultAttributeRegistry.register(OVERSEER, Overseer.createAttributes());
        FabricDefaultAttributeRegistry.register(FLOATER, Floater.createFloaterAttributes());
    }

    private static <T extends Entity> EntityType<T> register(String name, EntityType<T> entity) {
        return Registry.register(BuiltInRegistries.ENTITY_TYPE, Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, name), entity);
    }

    public static void registerSpawnPlacements() {
        com.kyanite.deeperdarker.mixin.SpawnPlacementsInvoker.deeperdarker$register(ANGLER_FISH, net.minecraft.world.entity.SpawnPlacementTypes.IN_WATER, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, AnglerFish::checkAnglerFishSpawnRules);
        com.kyanite.deeperdarker.mixin.SpawnPlacementsInvoker.deeperdarker$register(SCULK_SNAPPER, net.minecraft.world.entity.SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mob::checkMobSpawnRules);
        com.kyanite.deeperdarker.mixin.SpawnPlacementsInvoker.deeperdarker$register(SHATTERED, net.minecraft.world.entity.SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mob::checkMobSpawnRules);
        com.kyanite.deeperdarker.mixin.SpawnPlacementsInvoker.deeperdarker$register(SCULK_LEECH, net.minecraft.world.entity.SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mob::checkMobSpawnRules);
        com.kyanite.deeperdarker.mixin.SpawnPlacementsInvoker.deeperdarker$register(SHRIEK_WORM, net.minecraft.world.entity.SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mob::checkMobSpawnRules);
        com.kyanite.deeperdarker.mixin.SpawnPlacementsInvoker.deeperdarker$register(STALKER, net.minecraft.world.entity.SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mob::checkMobSpawnRules);
        com.kyanite.deeperdarker.mixin.SpawnPlacementsInvoker.deeperdarker$register(SLUDGE, net.minecraft.world.entity.SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mob::checkMobSpawnRules);
        com.kyanite.deeperdarker.mixin.SpawnPlacementsInvoker.deeperdarker$register(SCULK_CENTIPEDE, net.minecraft.world.entity.SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mob::checkMobSpawnRules);
        com.kyanite.deeperdarker.mixin.SpawnPlacementsInvoker.deeperdarker$register(POTTY, net.minecraft.world.entity.SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mob::checkMobSpawnRules);
        com.kyanite.deeperdarker.mixin.SpawnPlacementsInvoker.deeperdarker$register(POT, net.minecraft.world.entity.SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mob::checkMobSpawnRules);
        com.kyanite.deeperdarker.mixin.SpawnPlacementsInvoker.deeperdarker$register(POTTER, net.minecraft.world.entity.SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mob::checkMobSpawnRules);
        com.kyanite.deeperdarker.mixin.SpawnPlacementsInvoker.deeperdarker$register(ACID_SPRITE, net.minecraft.world.entity.SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mob::checkMobSpawnRules);
    }
}
