package com.kyanite.deeperdarker.client.render;

import net.minecraft.client.renderer.Sheets;
import net.minecraft.client.resources.model.sprite.SpriteId;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.state.properties.ChestType;

public final class DDChestSprites {
    public static SpriteId choose(ChestType type){
        String suffix=switch(type){case LEFT->"_left";case RIGHT->"_right";default->"";};
        return new SpriteId(Sheets.CHEST_SHEET,Identifier.fromNamespaceAndPath("deeperdarker","entity/chest/dead_mans_chest_normal"+suffix));
    }
    private DDChestSprites(){}
}
