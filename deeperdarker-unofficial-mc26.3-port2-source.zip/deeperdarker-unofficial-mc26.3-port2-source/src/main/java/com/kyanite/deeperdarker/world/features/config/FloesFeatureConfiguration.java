// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.world.features.config;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.registries.Registries;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.levelgen.feature.stateproviders.BlockStateProvider;

import java.util.Optional;

public record FloesFeatureConfiguration(BlockStateProvider floeBlockState,
                                        Optional<BlockStateProvider> seamBlockState,
                                        int maxFloeHeight,
                                        int maxSeamHeight,
                                        float threshold,
                                        TagKey<Biome> allowedBiomes) {
    public static final MapCodec<FloesFeatureConfiguration> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            BlockStateProvider.DIRECT_CODEC.fieldOf("floe_block_state").forGetter(FloesFeatureConfiguration::floeBlockState),
            BlockStateProvider.DIRECT_CODEC.optionalFieldOf("seam_block_state").forGetter(FloesFeatureConfiguration::seamBlockState),
            Codec.INT.fieldOf("max_floe_height").forGetter(FloesFeatureConfiguration::maxFloeHeight),
            Codec.INT.fieldOf("max_seam_height").forGetter(FloesFeatureConfiguration::maxSeamHeight),
            Codec.floatRange(0f, 1f).fieldOf("threshold").forGetter(FloesFeatureConfiguration::threshold),
            TagKey.codec(Registries.BIOME).fieldOf("allowed_biomes").forGetter(FloesFeatureConfiguration::allowedBiomes)
    ).apply(instance, FloesFeatureConfiguration::new));
}
