package com.kyanite.deeperdarker.client.render;

import com.kyanite.deeperdarker.client.DDModelLayers;
import com.kyanite.deeperdarker.client.model.SunglassesModel;
import com.kyanite.deeperdarker.content.items.SunglassesItem;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Unit;

public final class SunglassesRenderer<S extends HumanoidRenderState,M extends HumanoidModel<S>> extends RenderLayer<S,M> {
    public static final Identifier TEXTURE=Identifier.fromNamespaceAndPath("deeperdarker","textures/entity/sunglasses.png");
    private final SunglassesModel model;
    public SunglassesRenderer(RenderLayerParent<S,M> parent,EntityModelSet models){super(parent);model=new SunglassesModel(models.bakeLayer(DDModelLayers.SUNGLASSES));}
    @Override public void submit(PoseStack poses,SubmitNodeCollector nodes,int light,S state,float yaw,float pitch){
        if(!(state.headEquipment.getItem() instanceof SunglassesItem))return;
        poses.pushPose();getParentModel().getHead().translateAndRotate(poses);
        poses.translate(0,-0.25,0);poses.scale(1.3F,1.3F,1.3F);poses.translate(0,0.25,0);
        nodes.submitModel(model,Unit.INSTANCE,poses,RenderTypes.entityTranslucent(TEXTURE),light,OverlayTexture.NO_OVERLAY,0xFFFFFFFF);poses.popPose();
    }
}
