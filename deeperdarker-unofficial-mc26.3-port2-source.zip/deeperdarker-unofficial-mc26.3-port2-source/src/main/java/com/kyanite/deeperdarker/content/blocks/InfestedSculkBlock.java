// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.content.blocks;

import com.kyanite.deeperdarker.content.DDEntities;
import com.kyanite.deeperdarker.content.entities.SculkLeech;
import com.kyanite.deeperdarker.content.entities.ShriekWorm;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

@SuppressWarnings("deprecation, NullableProblems")
public class InfestedSculkBlock extends Block {
    public InfestedSculkBlock(Block hostBlock, Properties properties) {
        super(properties.destroyTime(hostBlock.defaultDestroyTime() / 2.0f).explosionResistance(0.75f));
    }

    @Override
    public void stepOn(Level pLevel, BlockPos pPos, BlockState pState, Entity pEntity) {
        if(pEntity instanceof Player player) {
            pLevel.setBlock(pPos, Blocks.SCULK.defaultBlockState(), 3);
            player.knockback(1.5, player.getX() - pPos.getX(), player.getZ() - pPos.getZ(), pLevel.damageSources().generic(), 0F);
            if(pLevel instanceof ServerLevel serverLevel) DDEntities.SHRIEK_WORM.spawn(serverLevel, pPos, EntitySpawnReason.TRIGGERED);
        }

        if(pLevel.isClientSide() && pEntity instanceof LivingEntity) {
            RandomSource random = RandomSource.create();
            for(int i = 0; i < 20; i++) {
                double sX = random.nextGaussian() * 0.02;
                double sY = random.nextGaussian() * 0.02;
                double sZ = random.nextGaussian() * 0.02;
                pLevel.addParticle(ParticleTypes.POOF, pPos.getX() + random.nextDouble(), pPos.above().getY(), pPos.getZ() + random.nextDouble(), sX, sY, sZ);
            }
        }
    }

    @Override
    public void spawnAfterBreak(BlockState pState, ServerLevel pLevel, BlockPos pPos, ItemStack pStack, boolean pDropExperience) {
        super.spawnAfterBreak(pState, pLevel, pPos, pStack, pDropExperience);
        if(!com.kyanite.deeperdarker.util.DDEnchantmentChecks.hasSilkTouch(pLevel.registryAccess(), pStack)) {
            SculkLeech leech = DDEntities.SCULK_LEECH.create(pLevel, net.minecraft.world.entity.EntitySpawnReason.TRIGGERED);
            if(leech != null) {
                leech.snapTo(pPos.getX() + 0.5, pPos.getY(), pPos.getZ() + 0.5, 0, 0);
                pLevel.addFreshEntity(leech);
                leech.spawnAnim();
            }
        }
    }
}
