package com.kyanite.deeperdarker.client.render;

import com.kyanite.deeperdarker.content.entities.IcicleShard;
import com.kyanite.deeperdarker.util.DDUtil;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.Identifier;

public final class IcicleShardRenderer extends EntityRenderer<IcicleShard,EntityRenderState> {
    public static final Identifier TEXTURE=Identifier.fromNamespaceAndPath("deeperdarker","textures/entity/icicle_shard.png");
    public IcicleShardRenderer(EntityRendererProvider.Context context){super(context);}
    @Override
    public EntityRenderState createRenderState(){return new EntityRenderState();}
    @Override
    public void submit(EntityRenderState state,PoseStack poses,SubmitNodeCollector nodes,CameraRenderState camera){
        poses.pushPose();poses.rotate(camera.orientation);poses.translate(-0.5F,-0.5F,-0.5F);
        int light=state.lightCoords;
        nodes.submitCustomGeometry(poses,RenderTypes.entityTranslucentCull(TEXTURE),(pose,vertices)->
                DDUtil.renderFlatFace(pose,vertices,0xFFFFFFFF,0,0,8,16,16,0,16,16,-16,light,OverlayTexture.NO_OVERLAY));
        poses.popPose();super.submit(state,poses,nodes,camera);
    }
}
