package com.kyanite.deeperdarker.mixin;

import com.mojang.renderpearl.api.pipeline.RenderPipeline;
import net.minecraft.client.renderer.RenderPipelines;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(RenderPipelines.class)
public interface DDRenderPipelineInvoker {
    @Invoker("register")
    static RenderPipeline deeperdarker$register(RenderPipeline pipeline){throw new AssertionError("Mixin not applied");}
}
