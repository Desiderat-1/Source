// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.content;
import com.kyanite.deeperdarker.content.enchantments.CatalysisEffect;
import com.kyanite.deeperdarker.content.enchantments.SculkEntityCondition;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.enchantment.Enchantment;
public final class DDEnchantments {
    public static final ResourceKey<Enchantment> CATALYSIS = key("catalysis");
    public static final ResourceKey<Enchantment> SCULK_SMITE = key("sculk_smite");
    private static ResourceKey<Enchantment> key(String id) {
        return ResourceKey.create(Registries.ENCHANTMENT, Identifier.fromNamespaceAndPath("deeperdarker", id));
    }
    public static void init() {
        Registry.register(BuiltInRegistries.ENCHANTMENT_ENTITY_EFFECT_TYPE,
                Identifier.fromNamespaceAndPath("deeperdarker", "catalysis"), CatalysisEffect.CODEC);
        Registry.register(BuiltInRegistries.LOOT_CONDITION_TYPE,
                Identifier.fromNamespaceAndPath("deeperdarker", "is_sculk"), SculkEntityCondition.CODEC);
    }
}
