package com.kyanite.deeperdarker.world.otherside;

import com.kyanite.deeperdarker.util.DDSettings;
import net.minecraft.client.renderer.fog.FogData;
import org.joml.Vector3f;
import org.joml.Vector3fc;

/** Dynamic client preference; static sky/cloud settings live in the dimension's environment attributes. */
public final class OthersideEffects {
    public static Vector3fc fogColor(){return new Vector3f(DDSettings.CONFIG.client.whiteFog()?1:0);}
    public static void applyFogDistances(FogData fog,float farPlane){
        fog.environmentalStart=farPlane*0.05F;
        fog.environmentalEnd=Math.min(farPlane,192)*0.5F;
        fog.skyEnd=fog.environmentalEnd;
    }
    private OthersideEffects(){}
}
