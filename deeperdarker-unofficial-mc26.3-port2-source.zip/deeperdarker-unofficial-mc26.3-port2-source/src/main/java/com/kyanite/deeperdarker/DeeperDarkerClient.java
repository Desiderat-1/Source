// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker;

import com.kyanite.deeperdarker.client.DDModelLayers;
import com.kyanite.deeperdarker.client.Keybinds;
import com.kyanite.deeperdarker.client.model.*;
import com.kyanite.deeperdarker.client.render.*;

import com.kyanite.deeperdarker.content.*;
import com.kyanite.deeperdarker.content.entities.blocks.DeadMansChestBlockEntity;
import com.kyanite.deeperdarker.content.items.SculkTransmitterItem;
import com.kyanite.deeperdarker.content.items.SoulElytraItem;
import com.kyanite.deeperdarker.network.Messages;
import com.kyanite.deeperdarker.network.SoulElytraBoostPacket;
import com.kyanite.deeperdarker.network.UseTransmitterPacket;
import com.kyanite.deeperdarker.util.DDUtil;
import com.kyanite.deeperdarker.world.otherside.OthersideEffects;
import net.fabricmc.api.ClientModInitializer;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.particle.v1.ParticleProviderRegistry;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderingRegistry;

import net.fabricmc.fabric.api.client.rendering.v1.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.object.boat.BoatModel;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.particle.DripParticle;
import net.minecraft.client.particle.FlameParticle;
import net.minecraft.client.particle.EmissiveRisingParticle;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.Sheets;
import net.minecraft.client.renderer.blockentity.*;

import net.minecraft.client.resources.model.sprite.Material;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;

public class DeeperDarkerClient implements ClientModInitializer {
    public static final Identifier ACID_TEXTURE = Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "block/acid_still");
    public static final Identifier FLOWING_ACID_TEXTURE = Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "block/acid_flow");
    public static final Identifier ACID_SCREEN_EFFECT_TEXTURE = Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "textures/misc/acid.png");

    @Override
    public void onInitializeClient() {
        DDModelLayers.init();
        Keybinds.init();
        com.kyanite.deeperdarker.client.item.DDItemModelProperties.init();
        // Terrain layers are selected automatically from sprite alpha in 26.3.
        FluidRenderingRegistry.register(DDFluids.ACID, DDFluids.FLOWING_ACID, new net.minecraft.client.renderer.block.FluidModel.Unbaked(
                new Material(ACID_TEXTURE), new Material(FLOWING_ACID_TEXTURE), null, net.minecraft.client.color.block.BlockTintSources.constant(0xFFFFFFFF)));

        // Otherside sky/cloud attributes are data-driven; the atmospheric fog Mixin honors whiteFog.

        BlockEntityRenderers.register(DDBlockEntities.HANGING_SIGN, HangingSignRenderer::new);
        BlockEntityRenderers.register(DDBlockEntities.SIGN, StandingSignRenderer::new);
        BlockEntityRenderers.register(DDBlockEntities.CRYSTALLIZED_AMBER, CrystallizedAmberBlockRenderer::new);
        BlockEntityRenderers.register(DDBlockEntities.SKULL, SkullBlockRenderer::new);
        BlockEntityRenderers.register(DDBlockEntities.DARK_FOUNTAIN, DarkFountainBlockRenderer::new);
        BlockEntityRenderers.register(DDBlockEntities.CAMPFIRE, CampfireRenderer::new);
        BlockEntityRenderers.register(DDBlockEntities.DEAD_MANS_CHEST, DeadMansChestRenderer::new);
        // Inventory rendering is supplied by the migrated native chest special-model JSON.

        DeeperDarker.LOGGER.info("Registering models");
        ModelLayerRegistry.registerModelLayer(DDModelLayers.HELMET_HORNS, HelmetHornsModel::getTexturedModelData);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.ECHO_BOAT, BoatModel::createBoatModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.ECHO_CHEST_BOAT, BoatModel::createChestBoatModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.BLOOM_BOAT, BoatModel::createBoatModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.BLOOM_CHEST_BOAT, BoatModel::createChestBoatModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.SCULK_SPRUCE_BOAT, BoatModel::createBoatModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.SCULK_SPRUCE_CHEST_BOAT, BoatModel::createChestBoatModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.ANGLER_FISH, AnglerFishModel::createBodyModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.SCULK_SNAPPER, SculkSnapperModel::createBodyModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.SHATTERED, ShatteredModel::createBodyModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.SCULK_LEECH, SculkLeechModel::createBodyModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.SHRIEK_WORM, ShriekWormModel::createBodyModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.STALKER, StalkerModel::createBodyModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.SLUDGE, SludgeModel::createInnerBodyModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.SLUDGE_OUTER, SludgeModel::createOuterBodyModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.SCULK_CENTIPEDE, SculkCentipedeModel::createBodyModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.BLOOMING_GOLEM, BloomingGolemModel::createBodyModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.POTTY, PottyModel::createBodyModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.POT, PotModel::createBodyModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.POTTER, PotterModel::createBodyModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.OVERCAST_VESSEL, OvercastVesselModel::createBodyModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.ACID_SPRITE, AcidSpriteModel::createBodyModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.BUBBLOX, BubbloxModel::createBodyModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.OVERSEER, OverseerModel::createBodyModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.OVERSEER_CRYSTAL, OverseerCrystalModel::createBodyModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.FLOATER, FloaterModel::createBodyModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.SHATTERED_HEAD, ShatteredHeadModel::createHeadModel);
        ModelLayerRegistry.registerModelLayer(DDModelLayers.SUNGLASSES, SunglassesModel::createModel);

        EntityRendererRegistry.register(DDEntities.BOAT, (ctx) -> new DDBoatRenderer<>(ctx, false));
        EntityRendererRegistry.register(DDEntities.CHEST_BOAT, (ctx) -> new DDBoatRenderer<>(ctx, true));
        EntityRendererRegistry.register(DDEntities.ICICLE_SHARD, IcicleShardRenderer::new);
        EntityRendererRegistry.register(DDEntities.OVERCAST_VESSEL_ITEM, OvercastVesselItemRenderer::new);
        EntityRendererRegistry.register(DDEntities.ANGLER_FISH, AnglerFishRenderer::new);
        EntityRendererRegistry.register(DDEntities.SCULK_SNAPPER, SculkSnapperRenderer::new);
        EntityRendererRegistry.register(DDEntities.SHATTERED, ShatteredRenderer::new);
        EntityRendererRegistry.register(DDEntities.SCULK_LEECH, SculkLeechRenderer::new);
        EntityRendererRegistry.register(DDEntities.SHRIEK_WORM, ShriekWormRenderer::new);
        EntityRendererRegistry.register(DDEntities.STALKER, StalkerRenderer::new);
        EntityRendererRegistry.register(DDEntities.SLUDGE, SludgeRenderer::new);
        EntityRendererRegistry.register(DDEntities.SCULK_CENTIPEDE, SculkCentipedeRenderer::new);
        EntityRendererRegistry.register(DDEntities.BLOOMING_GOLEM, BloomingGolemRenderer::new);
        EntityRendererRegistry.register(DDEntities.POTTY, PottyRenderer::new);
        EntityRendererRegistry.register(DDEntities.POT, PotRenderer::new);
        EntityRendererRegistry.register(DDEntities.POTTER, PotterRenderer::new);
        EntityRendererRegistry.register(DDEntities.OVERCAST_VESSEL, OvercastVesselRenderer::new);
        EntityRendererRegistry.register(DDEntities.ACID_SPRITE, AcidSpriteRenderer::new);
        EntityRendererRegistry.register(DDEntities.BUBBLOX, BubbloxRenderer::new);
        EntityRendererRegistry.register(DDEntities.OVERSEER, OverseerRenderer::new);
        EntityRendererRegistry.register(DDEntities.OVERSEER_CRYSTAL, OverseerCrystalRenderer::new);
        EntityRendererRegistry.register(DDEntities.OVERSEER_LASER, OverseerLaserRenderer::new);
        EntityRendererRegistry.register(DDEntities.FLOATER, FloaterRenderer::new);

        LivingEntityRenderLayerRegistrationCallback.EVENT.register((entityType, entityRenderer, registrationHelper, context) -> {
            if (entityRenderer.getModel() instanceof HumanoidModel) {
                registrationHelper.register(new HelmetHornRenderer((net.minecraft.client.renderer.entity.RenderLayerParent) entityRenderer, context.getModelSet()));
                // Native WingsLayer uses the Soul Elytra equipment asset and handles animation/glint.
                registrationHelper.register(new SunglassesRenderer((net.minecraft.client.renderer.entity.RenderLayerParent) entityRenderer, context.getModelSet()));
            }
        });

        ClientTickEvents.START_LEVEL_TICK.register(world -> {
            Minecraft client = Minecraft.getInstance();
            if (client.player == null) return;
            ItemStack itemStack = client.player.getItemBySlot(EquipmentSlot.CHEST);
            if (itemStack.is(DDItems.SOUL_ELYTRA) && client.player.getCooldowns().getCooldownPercent(itemStack, 0.0f) == 0 && client.player.isFallFlying() && Keybinds.BOOST.isDown()) {
                ClientPlayNetworking.send(new SoulElytraBoostPacket());
            }
        });

        ClientTickEvents.START_LEVEL_TICK.register(world -> {
            Minecraft client = Minecraft.getInstance();
            if (client.player == null) return;
            if (client.player.getInventory().hasAnyMatching(stack -> stack.getItem() instanceof SculkTransmitterItem) && Keybinds.TRANSMIT.isDown()) {
                ClientPlayNetworking.send(new UseTransmitterPacket());
            }
        });

        net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry.attachElementAfter(
                net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements.HOTBAR,
                Identifier.fromNamespaceAndPath("deeperdarker", "soul_elytra_boost"), (drawContext, tickDelta) -> {
            Minecraft client = Minecraft.getInstance();
            if (client.player == null || DeeperDarker.CONFIG.server.soulElytraCooldown() == -1) return;
            if (client.gameMode == null || client.gameMode.getPlayerMode() == GameType.SPECTATOR) {
                return;
            }

            Identifier texture = Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "textures/gui/soul_elytra_overlay_large.png");

            ItemStack chest = client.player.getItemBySlot(EquipmentSlot.CHEST);
            if (chest.is(DDItems.SOUL_ELYTRA)) {
                float f = client.player.getCooldowns().getCooldownPercent(chest, tickDelta.getGameTimeDeltaPartialTick(false));
                drawContext.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED, texture, 5, client.getWindow().getGuiScaledHeight() - 37, 0, 0, 12, Mth.floor(32 * f), 32, 32);
                drawContext.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED, texture, 5, client.getWindow().getGuiScaledHeight() - 37 + Mth.floor(32 * f), 12, Mth.floor(32 * f), 12, Mth.ceil(32 * (1.0f - f)), 32, 32);
                if (f == 0.0f && client.player.isFallFlying()) {
                    for (BlockPos blockPos : BlockPos.betweenClosed(client.player.getOnPos(), client.player.getOnPos().below(5))) {
                        if (client.player.level().getBlockState(blockPos).isAir()) continue;
                        drawContext.text(client.font, Component.translatable(DDItems.SOUL_ELYTRA.getDescriptionId() + ".boost", Keybinds.BOOST.getTranslatedKeyMessage()).setStyle(Style.EMPTY.withColor(ChatFormatting.YELLOW)), 20, client.getWindow().getGuiScaledHeight() - 37, 0xFF000000);
                    }
                }
            }
        });
        LivingEntityFeatureRenderEvents.ALLOW_CAPE_RENDER.register(state -> !state.chestEquipment.is(DDItems.SOUL_ELYTRA));

        ParticleProviderRegistry.getInstance().register(DDParticleTypes.SCULK_FIRE_FLAME, FlameParticle.Provider::new);
        ParticleProviderRegistry.getInstance().register(DDParticleTypes.PATIENCE_SOUL, EmissiveRisingParticle.EmissiveProvider::new);
        ParticleProviderRegistry.getInstance().register(DDParticleTypes.FORTITUDE_SOUL, EmissiveRisingParticle.EmissiveProvider::new);
        ParticleProviderRegistry.getInstance().register(DDParticleTypes.CORRUPTION_SOUL, EmissiveRisingParticle.EmissiveProvider::new);
        ParticleProviderRegistry.getInstance().register(DDParticleTypes.PURITY_SOUL, EmissiveRisingParticle.EmissiveProvider::new);
        ParticleProviderRegistry.getInstance().register(DDParticleTypes.VIRTUE_SOUL, EmissiveRisingParticle.EmissiveProvider::new);
        ParticleProviderRegistry.getInstance().register(DDParticleTypes.DRIPPING_ACID, sprites -> (particleOptions, clientLevel, x, y, z, g, h, i, random) -> {
            DripParticle.DripHangParticle dripParticle = new DripParticle.DripHangParticle(clientLevel, x, y, z, DDFluids.ACID, DDParticleTypes.FALLING_ACID, sprites.get(random));
            dripParticle.setColor(0.2f, 1.0f, 0.3f);
            return dripParticle;
        });
        ParticleProviderRegistry.getInstance().register(DDParticleTypes.FALLING_ACID, sprites -> (particleOptions, clientLevel, x, y, z, g, h, i, random) -> {
            DripParticle.FallAndLandParticle dripParticle = new DripParticle.FallAndLandParticle(clientLevel, x, y, z, DDFluids.ACID, DDParticleTypes.LANDING_ACID, sprites.get(random));
            dripParticle.setColor(0.2f, 0.3f, 1.0f);
            return dripParticle;
        });
        ParticleProviderRegistry.getInstance().register(DDParticleTypes.LANDING_ACID, sprites -> (particleOptions, clientLevel, x, y, z, g, h, i, random) -> {
            DripParticle dripParticle = new DripParticle.DripLandParticle(clientLevel, x, y, z, DDFluids.ACID, sprites.get(random));
            dripParticle.setColor(0.2f, 0.3f, 1.0f);
            return dripParticle;
        });

        Messages.registerClientReceivers();
    }
}
