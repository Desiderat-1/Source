package com.kyanite.deeperdarker.content.entities.blocks;

import com.kyanite.deeperdarker.content.DDBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.NotNull;

public class ReturnStatueBlockEntity extends BlockEntity {
    public BlockPos teleportPos = null;

    public ReturnStatueBlockEntity(BlockPos blockPos, BlockState blockState) {
        super(DDBlockEntities.RETURN_STATUE, blockPos, blockState);
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    protected void loadAdditional(net.minecraft.world.level.storage.ValueInput tag) {
        super.loadAdditional(tag);
        teleportPos = tag.child("teleport_pos").flatMap(pos -> pos.getInt("x").flatMap(x -> pos.getInt("y").flatMap(y -> pos.getInt("z").map(z -> new BlockPos(x, y, z))))).orElse(null);
    }

    @Override
    protected void saveAdditional(net.minecraft.world.level.storage.ValueOutput tag) {
        super.saveAdditional(tag);
        if (teleportPos != null) {
            var posTag = tag.child("teleport_pos");
            posTag.putInt("x", teleportPos.getX());
            posTag.putInt("y", teleportPos.getY());
            posTag.putInt("z", teleportPos.getZ());

        }
    }
}
