package com.kyanite.deeperdarker.mixin;

import com.kyanite.deeperdarker.world.otherside.*;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.client.*;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.fog.FogData;
import net.minecraft.client.renderer.fog.environment.AtmosphericFogEnvironment;
import org.joml.Vector3fc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AtmosphericFogEnvironment.class)
public abstract class OthersideFogMixin {
    @ModifyReturnValue(method="getBaseColor",at=@At("RETURN"))
    private Vector3fc deeperdarker$othersideColor(Vector3fc original,ClientLevel level,Camera camera,int distance,float partial){
        return level.dimension()==OthersideDimension.OTHERSIDE_LEVEL?OthersideEffects.fogColor():original;
    }
    @Inject(method="setupFog",at=@At("TAIL"))
    private void deeperdarker$othersideDistance(FogData fog,Camera camera,ClientLevel level,float farPlane,DeltaTracker tracker,CallbackInfo ci){
        if(level.dimension()==OthersideDimension.OTHERSIDE_LEVEL)OthersideEffects.applyFogDistances(fog,farPlane);
    }
}
