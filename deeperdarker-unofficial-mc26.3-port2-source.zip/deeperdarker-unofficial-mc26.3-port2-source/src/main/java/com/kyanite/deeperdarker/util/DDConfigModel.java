// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28: configuration no longer requires owo.
package com.kyanite.deeperdarker.util;
public class DDConfigModel {
    public Server server = new Server();

    public static class Server {
        public float spawnSomethingFromAncientVaseChance = 0.16f;
        public double sculkLeechesFromAncientVaseChance = 0.7;

        public boolean geysersApplySlowFalling = false;
        public float geyserLaunchVelocity = 2.5f;
        public float sonorousStaffDamage = 50.0f;
        public double sonorousStaffKnockback = 1.0;
        public int sonorousStaffCooldown = 20;
        public int sonorousStaffRange = 40;
        public int soulElytraCooldown = 600;
        public double soulElytraBoostStrength = 2.0;
        public int snapperDropLimit = 8;
        public boolean createCompatibility = true;
        public boolean showMeYourSkinCompatibility = true;
        public boolean addWardenDrops = true;
        public boolean addAncientCityLoot = true;

        public boolean cancelDummyBlockEntityWarning = true;
    }
    public Client client = new Client();

    public static class Client {
        public boolean renderWardenHelmetHorns = true;

        public boolean wardenHeartPulses = true;

        public boolean changePhantomTextures = true;

        public boolean paintingFix = true;
        public boolean whiteFog = false;
        public int sculkTransmitterLinkCooldownSeconds = 3;

    }
}
