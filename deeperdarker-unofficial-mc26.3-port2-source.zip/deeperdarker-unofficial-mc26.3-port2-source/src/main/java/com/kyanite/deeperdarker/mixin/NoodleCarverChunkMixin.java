package com.kyanite.deeperdarker.mixin;

import com.kyanite.deeperdarker.world.DDChunkCarverOutput;
import com.kyanite.deeperdarker.world.DDNoodleCarver;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.chunk.CarverOutput;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.levelgen.NoiseBasedChunkGenerator;
import net.minecraft.world.level.levelgen.WorldGenerationContext;
import net.minecraft.world.level.levelgen.carver.WorldCarver;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(NoiseBasedChunkGenerator.class)
public abstract class NoodleCarverChunkMixin {
    @WrapOperation(method = "generateCarvers", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/levelgen/carver/WorldCarver;carve(Lnet/minecraft/world/level/levelgen/WorldGenerationContext;Lnet/minecraft/util/RandomSource;Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/world/level/chunk/CarverOutput;)Z"))
    private boolean deeperdarker$provideChunk(WorldCarver carver, WorldGenerationContext context, RandomSource random,
                                             ChunkPos target, ChunkPos origin, CarverOutput output, Operation<Boolean> original,
                                             @Local(argsOnly = true) ChunkAccess chunk) {
        return original.call(carver, context, random, target, origin,
                carver instanceof DDNoodleCarver ? new DDChunkCarverOutput(chunk, output) : output);
    }
}
