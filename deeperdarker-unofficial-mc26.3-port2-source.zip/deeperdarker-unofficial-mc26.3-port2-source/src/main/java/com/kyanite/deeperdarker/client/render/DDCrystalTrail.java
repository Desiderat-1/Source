package com.kyanite.deeperdarker.client.render;

import com.kyanite.deeperdarker.mixin.DDRenderPipelineInvoker;
import com.kyanite.deeperdarker.mixin.DDRenderTypeInvoker;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.renderpearl.api.pipeline.*;
import net.minecraft.client.renderer.BindGroupLayouts;
import net.minecraft.client.renderer.rendertype.*;
import net.minecraft.resources.Identifier;

/** Keeps the original animated 16-pixel grid shader in the modern native rendering pipeline. */
public final class DDCrystalTrail {
    public static final Identifier SHADER=Identifier.fromNamespaceAndPath("deeperdarker","core/overseer_crystal_trail");
    public static final RenderPipeline PIPELINE=DDRenderPipelineInvoker.deeperdarker$register(RenderPipeline.builder()
            .withLocation(Identifier.fromNamespaceAndPath("deeperdarker","pipeline/overseer_crystal_trail"))
            .withVertexShader(SHADER).withFragmentShader(SHADER)
            .withBindGroupLayout(BindGroupLayouts.GLOBALS).withBindGroupLayout(BindGroupLayouts.PROJECTION)
            .withBindGroupLayout(BindGroupLayouts.DYNAMIC_TRANSFORMS)
            .withVertexBinding(0,DefaultVertexFormat.ENTITY).withPrimitiveTopology(PrimitiveTopology.QUADS)
            .withDepthStencilState(DepthStencilState.DEFAULT).withColorTargetState(ColorTargetState.DEFAULT).withCull(false).build());
    public static final RenderType TYPE=DDRenderTypeInvoker.deeperdarker$create("deeperdarker_overseer_crystal_trail",
            RenderSetup.builder(PIPELINE).setLayeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING).sortOnUpload().createRenderSetup());
    private DDCrystalTrail(){}
}
