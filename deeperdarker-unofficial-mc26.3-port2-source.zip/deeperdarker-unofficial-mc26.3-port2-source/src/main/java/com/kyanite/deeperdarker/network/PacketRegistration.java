// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.network;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;

public final class PacketRegistration {
    private PacketRegistration() {}
    public static void register() {
        PayloadTypeRegistry.serverboundPlay().register(SoulElytraBoostPacket.TYPE, SoulElytraBoostPacket.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(UseTransmitterPacket.TYPE, UseTransmitterPacket.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(LinkTransmitterPacket.TYPE, LinkTransmitterPacket.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(UnlinkTransmitterPacket.TYPE, UnlinkTransmitterPacket.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(LinkOwnedEntityPacket.TYPE, LinkOwnedEntityPacket.CODEC);
    }
}
