// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.client.render;

import com.kyanite.deeperdarker.DeeperDarker;
import com.kyanite.deeperdarker.client.DDModelLayers;
import com.kyanite.deeperdarker.client.model.BloomingGolemModel;
import com.kyanite.deeperdarker.content.entities.BloomingGolem;
import com.kyanite.deeperdarker.content.entities.overcastvessel.OvercastVessel;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

@SuppressWarnings("NullableProblems")
public class BloomingGolemRenderer extends DDMobRenderer<BloomingGolem, BloomingGolemModel> {
    private static final Identifier TEXTURE = Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "textures/entity/blooming_golem/blooming_golem.png");
    private static final Identifier TEXTURE_SLEEPING = Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "textures/entity/blooming_golem/blooming_golem_sleeping.png");

    public BloomingGolemRenderer(EntityRendererProvider.Context context) {
        super(context, new BloomingGolemModel(context.bakeLayer(DDModelLayers.BLOOMING_GOLEM)), 1.0f);
    }

    @Override
    public Identifier getTextureLocation(BloomingGolem entity) {
        return entity.isGolemSleeping() ? TEXTURE_SLEEPING : TEXTURE;
    }

    @Override
    protected void setupRotations(BloomingGolem vessel, PoseStack poseStack, float f, float g, float h) {
    }
}
