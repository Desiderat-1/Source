// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.mixin;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import com.kyanite.deeperdarker.content.items.ShieldAugmentItem;
import com.kyanite.deeperdarker.util.DDUtil;
import net.minecraft.core.Holder;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(LivingEntity.class)
public abstract class ShieldAttributeModifierLivingEntityMixin {
    @Unique private ItemStack deeperdarker$lastMain = ItemStack.EMPTY;
    @Unique private ItemStack deeperdarker$lastOff = ItemStack.EMPTY;
    @Unique private boolean deeperdarker$wasBlocking;
    @Inject(method = "detectEquipmentUpdates", at = @At("HEAD"))
    private void deeperdarker$updateAugments(CallbackInfo ci) {
        var entity = (LivingEntity) (Object) this;
        if (!(entity instanceof Player)) return;
        boolean blocking = entity.isBlocking();
        for (var slot : new EquipmentSlot[]{EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND}) {
            var previous = slot == EquipmentSlot.MAINHAND ? deeperdarker$lastMain : deeperdarker$lastOff;
            var current = entity.getItemBySlot(slot);
            if (blocking != deeperdarker$wasBlocking || entity.equipmentHasChanged(previous, current)) {
                entity.getAttributes().removeAttributeModifiers(deeperdarker$modifiers(entity, previous, slot, deeperdarker$wasBlocking));
                entity.getAttributes().addTransientAttributeModifiers(deeperdarker$modifiers(entity, current, slot, blocking));
            }
            if (slot == EquipmentSlot.MAINHAND) deeperdarker$lastMain = current.copy();
            else deeperdarker$lastOff = current.copy();
        }
        deeperdarker$wasBlocking = blocking;
    }
    @Unique private Multimap<Holder<Attribute>, AttributeModifier> deeperdarker$modifiers(LivingEntity entity, ItemStack shield, EquipmentSlot slot, boolean blocking) {
        if (DDUtil.isAugmentedShield(shield)) {
            var stack = DDUtil.getAugmentItem(shield, entity.level().registryAccess());
            if (stack.getItem() instanceof ShieldAugmentItem item) return item.getAugmentAttributeModifiers(slot, blocking).orElseGet(HashMultimap::create);
        }
        return HashMultimap.create();
    }
}
