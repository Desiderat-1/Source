// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.network;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.core.BlockPos;

public record LinkTransmitterPacket(int slot, BlockPos blockPos) implements CustomPacketPayload {
    public static final Type<LinkTransmitterPacket> TYPE = new Type<>(Identifier.fromNamespaceAndPath("deeperdarker", "link_transmitter"));
    public static final StreamCodec<ByteBuf, LinkTransmitterPacket> CODEC = StreamCodec.composite(ByteBufCodecs.INT, LinkTransmitterPacket::slot, BlockPos.STREAM_CODEC, LinkTransmitterPacket::blockPos, LinkTransmitterPacket::new);


    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
