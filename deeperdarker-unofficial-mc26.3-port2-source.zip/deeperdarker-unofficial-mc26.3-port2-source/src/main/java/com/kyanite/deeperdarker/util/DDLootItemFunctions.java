package com.kyanite.deeperdarker.util;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;

public final class DDLootItemFunctions {
    public static final MapCodec<SetPaintingVariantFunction> SET_PAINTING_VARIANT = Registry.register(
            BuiltInRegistries.LOOT_FUNCTION_TYPE, Identifier.fromNamespaceAndPath("deeperdarker","set_painting_variant"),
            SetPaintingVariantFunction.MAP_CODEC);
    public static void init() { }
}
