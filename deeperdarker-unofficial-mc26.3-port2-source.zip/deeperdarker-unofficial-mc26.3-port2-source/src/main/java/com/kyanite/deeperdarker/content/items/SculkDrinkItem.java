// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.content.items;

import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.Consumables;

/** Vanilla consumable components handle food, creative mode and the empty bucket. */
public class SculkDrinkItem extends Item {
    public SculkDrinkItem(Properties properties) {
        super(properties.component(DataComponents.CONSUMABLE, Consumables.DEFAULT_DRINK).usingConvertsTo(Items.BUCKET));
    }
}
