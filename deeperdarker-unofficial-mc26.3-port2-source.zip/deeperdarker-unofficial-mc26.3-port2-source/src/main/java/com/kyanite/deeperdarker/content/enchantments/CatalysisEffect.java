// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.content.enchantments;
import com.mojang.serialization.MapCodec;
import net.minecraft.advancements.triggers.CriteriaTriggers;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.enchantment.EnchantedItemInUse;
import net.minecraft.world.item.enchantment.effects.EnchantmentEntityEffect;
import net.minecraft.world.level.block.SculkSpreader;
import net.minecraft.world.phys.Vec3;
/** Retains the original kill-to-Sculk conversion and catalyst advancement behavior. */
public record CatalysisEffect() implements EnchantmentEntityEffect {
    public static final MapCodec<CatalysisEffect> CODEC = MapCodec.unit(new CatalysisEffect());
    @Override public void apply(ServerLevel server, int level, EnchantedItemInUse item, Entity entity, Vec3 position) {
        if (!(item.owner() instanceof ServerPlayer player) || !(entity instanceof LivingEntity target) || !target.isDeadOrDying()) return;
        var spreader = SculkSpreader.createLevelSpreader();
        var pos = target.blockPosition();
        int reward = target.getExperienceReward(server, player);
        for (int i = 0; i < 3 * level; i++) spreader.addCursors(pos, reward);
        for (int i = 0; i < 8 * level; i++) spreader.updateCursors(server, pos, player.getRandom(), true);
        target.skipDropExperience();
        CriteriaTriggers.KILL_MOB_NEAR_SCULK_CATALYST.trigger(player, target, server.damageSources().playerAttack(player));
    }
    @Override public MapCodec<CatalysisEffect> codec() { return CODEC; }
}
