package com.kyanite.deeperdarker.mixin;

import com.kyanite.deeperdarker.content.DDBlocks;
import net.minecraft.core.Holder;
import net.minecraft.core.component.*;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.component.BlockTransformers;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
import net.minecraft.world.level.levelgen.feature.stateproviders.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import java.util.List;

@Mixin(BlockTransformer.class)
public abstract class StripBloomingStemMixin {
    @Inject(method="transformBlock",at=@At("HEAD"),cancellable=true)
    private void deeperdarker$stripConnectedStem(UseOnContext context,CallbackInfoReturnable<InteractionResult> cir){
        var transformer=context.getItemInHand().get(DataComponents.BLOCK_TRANSFORMER);
        if(transformer==null||transformer.value()!=(Object)this||!transformer.is(BlockTransformers.AXE))return;
        if(!context.getLevel().getBlockState(context.getClickedPos()).is(DDBlocks.BLOOMING_STEM))return;
        var provider=RuleBasedStateProvider.builder().ifTrueThenProvide(BlockPredicate.matchesBlocks(DDBlocks.BLOOMING_STEM),
                new CopyPropertiesProvider(DDBlocks.STRIPPED_BLOOMING_STEM)).build();
        var transform=BlockTransformer.BlockTransformData.builder(provider).sound(SoundEvents.AXE_STRIP).itemDamagePerUse(1).build();
        // Delegate sound, durability, updates and advancement handling to the actual native transformer.
        cir.setReturnValue(new BlockTransformer(List.of(transform)).transformBlock(context));
    }
}
