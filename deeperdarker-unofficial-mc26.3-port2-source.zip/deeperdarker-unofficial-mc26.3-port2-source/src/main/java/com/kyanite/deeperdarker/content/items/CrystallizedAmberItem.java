// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.content.items;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.NbtOps;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentUtils;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.level.block.Block;
import java.util.function.Consumer;
public final class CrystallizedAmberItem extends BlockItem {
    public CrystallizedAmberItem(Block block, Properties properties) { super(block, properties); }
    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, TooltipDisplay display,
            Consumer<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, context, display, tooltip, flag);
        var data = stack.get(DataComponents.BLOCK_ENTITY_DATA);
        if (data == null) return;
        var tag = data.copyTagWithoutId();
        if (tag.getBooleanOr("leech", false)) {
            tooltip.accept(ComponentUtils.wrapInSquareBrackets(Component.translatable("entity.deeperdarker.sculk_leech"))
                    .withStyle(ChatFormatting.GRAY));
        } else if (context.registries() != null && tag.contains("item")) {
            ItemStack.CODEC.parse(context.registries().createSerializationContext(NbtOps.INSTANCE), tag.get("item"))
                    .result().filter(item -> !item.isEmpty()).ifPresent(item ->
                        tooltip.accept(item.getDisplayName().copy().withStyle(ChatFormatting.GRAY)));
        }
    }
}
