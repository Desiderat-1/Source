// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.util;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;

/** Sets IDs before constructors consume names, models and loot-table defaults. */
public final class DDRegistration {
    private DDRegistration() {}
    public static ResourceKey<Item> itemKey(String name) {
        return ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("deeperdarker", name));
    }
    public static ResourceKey<Block> blockKey(String name) {
        return ResourceKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", name));
    }
    public static Item.Properties itemProperties(String name) {
        Item.Properties properties = new Item.Properties().setId(itemKey(name));
        switch (name) {
            case "echo_sapling", "echo_leaves", "glowing_flowers", "glowing_roots", "bloom_berries" ->
                properties.compostable(net.minecraft.world.level.storage.loot.providers.number.ints.ContextIntProviders.COMPOSTABLE_LOW);
            case "sculk_tendrils", "glowing_grass", "sculk_vines" -> properties.compostable(net.minecraft.world.level.storage.loot.providers.number.ints.ContextIntProviders.COMPOSTABLE_LOW_MEDIUM);
            case "sculk_tuber" -> properties.compostable(net.minecraft.world.level.storage.loot.providers.number.ints.ContextIntProviders.COMPOSTABLE_MEDIUM);
        }
        return properties;
    }
    public static BlockBehaviour.Properties blockProperties(String name, BlockBehaviour.Properties properties) {
        return properties.setId(blockKey(name));
    }
}
