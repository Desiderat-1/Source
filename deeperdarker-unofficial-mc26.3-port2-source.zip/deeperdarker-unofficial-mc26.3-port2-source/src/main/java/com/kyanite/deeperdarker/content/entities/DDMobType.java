// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.content.entities;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LivingEntity;

/** Replaces the removed MobType while retaining the Otherside-only phantom rule. */
public final class DDMobType {
    public static final TagKey<EntityType<?>> SCULK = TagKey.create(Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "sculk"));
    private static final Identifier OTHERSIDE = Identifier.fromNamespaceAndPath("deeperdarker", "otherside");
    private DDMobType() {}
    public static boolean isSculk(LivingEntity entity) {
        return entity.getType().builtInRegistryHolder().is(SCULK) || (entity.getType() == EntityTypes.PHANTOM && entity.level().dimension().identifier().equals(OTHERSIDE));
    }
}
