// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.content;

import com.kyanite.deeperdarker.DeeperDarker;
import net.minecraft.advancements.triggers.CriteriaTriggers;
import net.minecraft.advancements.triggers.PlayerTrigger;
import net.minecraft.resources.Identifier;

public class DDCriteriaTriggers {
    public static final PlayerTrigger OPEN_DEAD_MANS_CHEST = net.minecraft.core.Registry.register(net.minecraft.core.registries.BuiltInRegistries.TRIGGER_TYPES, Identifier.fromNamespaceAndPath("deeperdarker", "player_opened_dead_mans_chest"), new PlayerTrigger());

    public static void init() {
        DeeperDarker.LOGGER.debug("Registering criterion triggers");
    }
}
