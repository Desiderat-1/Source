// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.world;

import com.kyanite.deeperdarker.DeeperDarker;
import com.mojang.serialization.MapCodec;
import com.kyanite.deeperdarker.world.features.*;
import com.kyanite.deeperdarker.world.features.config.*;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.levelgen.feature.Feature;

public class DDFeatures {
    public static final MapCodec<VineFeature> VINE = register("vine", VineFeature.CODEC);
    public static final MapCodec<OthersideColumnFeature> OTHERSIDE_COLUMN = register("otherside_column", OthersideColumnFeature.CODEC);
    public static final MapCodec<SculkGleamFeature> SCULK_GLEAM_BLOB = register("sculk_gleam_blob", SculkGleamFeature.CODEC);
    public static final MapCodec<SculkTendrilsFeature> SCULK_TENDRILS = register("sculk_tendrils", SculkTendrilsFeature.CODEC);
    public static final MapCodec<GlowingRootsFeature> GLOWING_ROOTS = register("glowing_roots", GlowingRootsFeature.CODEC);
    public static final MapCodec<OthersidePoolFeature> POOL = register("pool", OthersidePoolFeature.CODEC);
    public static final MapCodec<BloomingStemFeature> BLOOMING_STEM = register("blooming_stem", BloomingStemFeature.CODEC);
    public static final MapCodec<IcicleFeature> ICICLE = register("icicle", IcicleFeature.CODEC);
    public static final MapCodec<ConeFeature> CONE = register("cone", ConeFeature.CODEC);
    public static final MapCodec<BoulderFeature> BOULDER = register("boulder", BoulderFeature.CODEC);
    public static final MapCodec<FloesFeature> FLOES = register("floes", FloesFeature.CODEC);

    private static <F extends Feature> MapCodec<F> register(String id, MapCodec<F> codec) {
        return Registry.register(BuiltInRegistries.FEATURE_TYPE, Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, id), codec);
    }

    public static void init() {
        DeeperDarker.LOGGER.debug("Registering world gen");
    }
}
