package com.kyanite.deeperdarker.mixin;

import com.kyanite.deeperdarker.util.DDUtil;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(ItemEntity.class)
public abstract class AcidImmuneItemMixin extends Entity implements com.kyanite.deeperdarker.content.fluids.EntityInAcid {
    protected AcidImmuneItemMixin(EntityType<?> entityType, Level level) {
        super(entityType, level);
    }

    @Override
    public boolean deeperdarker$acidImmune() {
        return getType().builtInRegistryHolder().is(com.kyanite.deeperdarker.util.DDTags.EntityTypes.ACID_IMMUNE) || DDUtil.isAcidResistant(((ItemEntity) (Object) this).getItem());
    }
}
