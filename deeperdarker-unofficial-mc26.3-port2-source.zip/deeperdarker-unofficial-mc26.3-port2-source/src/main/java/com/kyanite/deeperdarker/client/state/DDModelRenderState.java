// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.client.state;

import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.Identifier;
import org.joml.Matrix4f;
import java.util.List;

/** Immutable model poses extracted before submission; no entity is retained. */
public final class DDModelRenderState extends LivingEntityRenderState {
    public record Part(PartPose pose, boolean visible, boolean skipDraw) {}
    public List<Part> parts = List.of();
    public Identifier texture;
    public List<net.minecraft.core.Direction> crackDirections = List.of();
    public int sludgeSize = 1;
    public net.minecraft.world.phys.Vec3 tetherOffset;
    public net.minecraft.world.phys.Vec3 tetherVector;
    public final Matrix4f rotationCorrection = new Matrix4f();
    public final Matrix4f scaleCorrection = new Matrix4f();
}
