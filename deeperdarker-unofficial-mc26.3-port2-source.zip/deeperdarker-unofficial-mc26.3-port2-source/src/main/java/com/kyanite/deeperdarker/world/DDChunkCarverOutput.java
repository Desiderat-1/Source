package com.kyanite.deeperdarker.world;

import net.minecraft.world.level.chunk.CarverOutput;
import net.minecraft.world.level.chunk.ChunkAccess;

/** Per-call generation context; never retained globally or shared between worker threads. */
public record DDChunkCarverOutput(ChunkAccess chunk, CarverOutput mask) implements CarverOutput {
    public void carve(int x, int y, int z) { mask.carve(x, y, z); }
    public int minY() { return mask.minY(); }
    public int maxY() { return mask.maxY(); }
}
