package com.kyanite.deeperdarker.mixin;

import com.kyanite.deeperdarker.content.items.SoulItem;
import com.kyanite.deeperdarker.util.DDTags;
import net.minecraft.client.renderer.entity.ItemEntityRenderer;
import net.minecraft.client.renderer.entity.state.ItemEntityRenderState;
import net.minecraft.util.LightCoordsUtil;
import net.minecraft.world.entity.item.ItemEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemEntityRenderer.class)
public abstract class SoulItemEntityRendererMixin {
    @Inject(method="extractRenderState(Lnet/minecraft/world/entity/item/ItemEntity;Lnet/minecraft/client/renderer/entity/state/ItemEntityRenderState;F)V",at=@At("TAIL"))
    private void deeperdarker$fullbrightSoul(ItemEntity entity,ItemEntityRenderState state,float partial,CallbackInfo ci){
        if(entity.getItem().getItem() instanceof SoulItem||entity.getItem().is(DDTags.Items.FULLBRIGHT))state.lightCoords=LightCoordsUtil.FULL_BRIGHT;
    }
}
