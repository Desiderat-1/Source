package com.kyanite.deeperdarker.mixin;

import com.kyanite.deeperdarker.client.state.AcidOverlayState;
import com.kyanite.deeperdarker.util.DDTags;
import net.minecraft.client.*;
import net.minecraft.client.renderer.Lightmap;
import net.minecraft.client.renderer.extract.LevelExtractor;
import net.minecraft.client.renderer.state.level.PlayerRenderState;
import net.minecraft.core.BlockPos;
import net.minecraft.util.ARGB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LevelExtractor.class)
public abstract class AcidOverlayExtractionMixin {
    @Inject(method="extractPlayerState",at=@At("TAIL"))
    private void deeperdarker$extractAcid(Camera camera,DeltaTracker tracker,float partial,PlayerRenderState state,CallbackInfo ci){
        var target=(AcidOverlayState)state;target.deeperdarker$setAcidOverlay(null);
        var player=Minecraft.getInstance().player;
        if(player==null||!player.isEyeInFluid(DDTags.Fluids.ACID))return;
        var eye=BlockPos.containing(player.getX(),player.getEyeY(),player.getZ());
        float light=Lightmap.getBrightness(player.level().dimensionType(),player.level().getMaxLocalRawBrightness(eye));
        target.deeperdarker$setAcidOverlay(new PlayerRenderState.WaterOverlay(ARGB.colorFromFloat(1,light,light,light),-player.getYRot()/64,player.getXRot()/64));
    }
}
