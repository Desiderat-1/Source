// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import blue.endless.jankson.Jankson;
import blue.endless.jankson.JsonGrammar;
import blue.endless.jankson.api.SyntaxError;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import net.fabricmc.loader.api.FabricLoader;

/** File-backed configuration preserving the original defaults and getter API. */
public final class DDConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Jankson JSON5 = Jankson.builder().build();
    private final DDConfigModel model;
    private final Path file;
    public final Server server;
    public final Client client;

    private DDConfig(DDConfigModel model, Path file) {
        this.model = model;
        this.file = file;
        this.server = new Server(model.server);
        this.client = new Client(model.client);
    }

    public static DDConfig createAndLoad() {
        try { return load(FabricLoader.getInstance().getConfigDir()); }
        catch (IOException exception) { throw new UncheckedIOException("Could not load Deeper and Darker configuration", exception); }
    }

    public static DDConfig load(Path directory) throws IOException {
        Files.createDirectories(directory);
        Path file = directory.resolve("deeperdarker.json");
        Path legacy = directory.resolve("deeperdarker.json5");
        Path input = Files.isRegularFile(file) ? file : Files.isRegularFile(legacy) ? legacy : null;
        DDConfigModel model = new DDConfigModel();
        if (input != null) {
            try {
                model = GSON.fromJson(JSON5.load(input.toFile()).toJson(JsonGrammar.STRICT), DDConfigModel.class);
                if (model == null) throw new IOException("Empty configuration: " + input);
            } catch (SyntaxError | JsonParseException | IllegalStateException exception) {
                throw new IOException("Invalid configuration: " + input, exception);
            }
        }
        if (model.server == null) model.server = new DDConfigModel.Server();
        if (model.client == null) model.client = new DDConfigModel.Client();
        model.server.spawnSomethingFromAncientVaseChance = clampFloat(model.server.spawnSomethingFromAncientVaseChance, 0F, 1F, 0.16f);
        model.server.sculkLeechesFromAncientVaseChance = clampDouble(model.server.sculkLeechesFromAncientVaseChance, 0, 1, 0.7);
        model.server.geyserLaunchVelocity = clampFloat(model.server.geyserLaunchVelocity, 0F, 20F, 2.5f);
        model.server.sonorousStaffDamage = clampFloat(model.server.sonorousStaffDamage, 1F, 128F, 50.0f);
        model.server.sonorousStaffKnockback = clampDouble(model.server.sonorousStaffKnockback, 1, 128, 1.0);
        model.server.sonorousStaffCooldown = Math.clamp(model.server.sonorousStaffCooldown, 0, 32767);
        model.server.sonorousStaffRange = Math.clamp(model.server.sonorousStaffRange, 1, 512);
        model.server.soulElytraCooldown = Math.clamp(model.server.soulElytraCooldown, -1, 32767);
        model.server.soulElytraBoostStrength = clampDouble(model.server.soulElytraBoostStrength, 1, 128, 2.0);
        model.server.snapperDropLimit = Math.clamp(model.server.snapperDropLimit, -1, 32);
        model.client.sculkTransmitterLinkCooldownSeconds = Math.clamp(model.client.sculkTransmitterLinkCooldownSeconds, 0, 10);
        DDConfig config = new DDConfig(model, file);
        config.save();
        return config;
    }

    public void save() throws IOException {
        Path temporary = file.resolveSibling(file.getFileName().toString() + ".tmp");
        Files.writeString(temporary, GSON.toJson(model) + System.lineSeparator(), StandardCharsets.UTF_8);
        try { Files.move(temporary, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
        catch (AtomicMoveNotSupportedException exception) { Files.move(temporary, file, StandardCopyOption.REPLACE_EXISTING); }
    }

    private static float clampFloat(float value, float min, float max, float fallback) {
        return Float.isFinite(value) ? Math.clamp(value, min, max) : fallback;
    }
    private static double clampDouble(double value, double min, double max, double fallback) {
        return Double.isFinite(value) ? Math.clamp(value, min, max) : fallback;
    }

    public static final class Server {
        private final DDConfigModel.Server data;
        private Server(DDConfigModel.Server data) { this.data = data; }
        public float spawnSomethingFromAncientVaseChance() { return data.spawnSomethingFromAncientVaseChance; }
        public double sculkLeechesFromAncientVaseChance() { return data.sculkLeechesFromAncientVaseChance; }
        public boolean geysersApplySlowFalling() { return data.geysersApplySlowFalling; }
        public float geyserLaunchVelocity() { return data.geyserLaunchVelocity; }
        public float sonorousStaffDamage() { return data.sonorousStaffDamage; }
        public double sonorousStaffKnockback() { return data.sonorousStaffKnockback; }
        public int sonorousStaffCooldown() { return data.sonorousStaffCooldown; }
        public int sonorousStaffRange() { return data.sonorousStaffRange; }
        public int soulElytraCooldown() { return data.soulElytraCooldown; }
        public double soulElytraBoostStrength() { return data.soulElytraBoostStrength; }
        public int snapperDropLimit() { return data.snapperDropLimit; }
        public boolean createCompatibility() { return data.createCompatibility; }
        public boolean showMeYourSkinCompatibility() { return data.showMeYourSkinCompatibility; }
        public boolean addWardenDrops() { return data.addWardenDrops; }
        public boolean addAncientCityLoot() { return data.addAncientCityLoot; }
        public boolean cancelDummyBlockEntityWarning() { return data.cancelDummyBlockEntityWarning; }
    }

    public static final class Client {
        private final DDConfigModel.Client data;
        private Client(DDConfigModel.Client data) { this.data = data; }
        public boolean renderWardenHelmetHorns() { return data.renderWardenHelmetHorns; }
        public boolean wardenHeartPulses() { return data.wardenHeartPulses; }
        public boolean changePhantomTextures() { return data.changePhantomTextures; }
        public boolean paintingFix() { return data.paintingFix; }
        public boolean whiteFog() { return data.whiteFog; }
        public int sculkTransmitterLinkCooldownSeconds() { return data.sculkTransmitterLinkCooldownSeconds; }
    }
}
