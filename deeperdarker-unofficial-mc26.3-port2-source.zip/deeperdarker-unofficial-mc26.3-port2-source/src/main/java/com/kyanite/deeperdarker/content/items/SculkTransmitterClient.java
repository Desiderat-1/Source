// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.content.items;

import com.kyanite.deeperdarker.network.LinkTransmitterPacket;
import com.kyanite.deeperdarker.network.UnlinkTransmitterPacket;
import com.kyanite.deeperdarker.util.DDSettings;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import java.util.Map;
import java.util.WeakHashMap;

@Environment(EnvType.CLIENT)
final class SculkTransmitterClient {
    private record Confirmation(boolean link, long time) {}
    private static final Map<ItemStack, Confirmation> CONFIRMATIONS = new WeakHashMap<>();
    static InteractionResult confirm(Player player, ItemStack stack, BlockPos pos, boolean connect) {
        int slot = SculkTransmitterItem.getSlot(player, stack);
        if (slot < 0) return InteractionResult.FAIL;
        int seconds = DDSettings.CONFIG.client.sculkTransmitterLinkCooldownSeconds();
        if (!SculkTransmitterItem.isLinked(stack) && pos != null && !connect) {
            player.sendOverlayMessage(Component.translatable("block.deeperdarker.not_transmittable"));
            return InteractionResult.FAIL;
        }
        var previous = CONFIRMATIONS.get(stack);
        boolean confirmed = seconds == 0 || (previous != null && previous.link() == connect && System.nanoTime() - previous.time() < seconds * 1_000_000_000L);
        if ((connect && !SculkTransmitterItem.isLinked(stack)) || confirmed) {
            if (connect) ClientPlayNetworking.send(new LinkTransmitterPacket(slot, pos));
            else ClientPlayNetworking.send(new UnlinkTransmitterPacket(slot));
            CONFIRMATIONS.remove(stack);
        } else {
            player.sendOverlayMessage(Component.translatable("item.deeperdarker.sculk_transmitter." + (connect ? "link_confirm" : "unlink_confirm"), Minecraft.getInstance().options.keyUse.getTranslatedKeyMessage()));
            CONFIRMATIONS.put(stack, new Confirmation(connect, System.nanoTime()));
        }
        return connect ? InteractionResult.SUCCESS : InteractionResult.FAIL;
    }
}
