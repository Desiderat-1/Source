package com.kyanite.deeperdarker.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.Model;
import net.minecraft.util.Unit;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.model.HeadedModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.world.entity.LivingEntity;

public class HelmetHornsModel extends Model<Unit> implements HeadedModel {
    private final ModelPart head;
    private final ModelPart leftHorn;
    private final ModelPart rightHorn;

    public HelmetHornsModel(ModelPart head) {
        super(head, RenderTypes::armorCutoutNoCull);
        this.head = head;
        this.leftHorn = head.getChild("left_horn");
        this.rightHorn = head.getChild("right_horn");
    }

    public static MeshDefinition getModelData() {
        MeshDefinition modelData = new MeshDefinition();
        PartDefinition modelPartData = modelData.getRoot();
        modelPartData.addOrReplaceChild("left_horn", CubeListBuilder.create().texOffs(0, 10).addBox(4.0f, 0.0f, 0.0f, 8.0f, 10.0f, 0.0f), PartPose.ZERO);
        modelPartData.addOrReplaceChild("right_horn", CubeListBuilder.create().texOffs(0, 0).addBox(-12.0f, 0.0f, 0.0f, 8.0f, 10.0f, 0.0f), PartPose.ZERO);
        return modelData;
    }

    public static LayerDefinition getTexturedModelData() {
        return LayerDefinition.create(getModelData(), 32, 32);
    }





    @Override
    public ModelPart getHead() {
        return this.head;
    }
}