package com.kyanite.deeperdarker.client.state;

/** Marks our recovery chest while preserving native single/double-chest animation state. */
public final class DDChestRenderState extends net.minecraft.client.renderer.blockentity.state.ChestRenderState {}
