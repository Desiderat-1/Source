// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.network;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import org.jetbrains.annotations.Nullable;

public record LinkOwnedEntityPacket(int ownerId, int ownedEntityId) implements CustomPacketPayload {
    public static final Type<LinkOwnedEntityPacket> TYPE = new Type<>(Identifier.fromNamespaceAndPath("deeperdarker", "link_owned_entity"));
    public static final StreamCodec<ByteBuf, LinkOwnedEntityPacket> CODEC = StreamCodec.composite(ByteBufCodecs.INT, LinkOwnedEntityPacket::ownerId, ByteBufCodecs.INT, LinkOwnedEntityPacket::ownedEntityId, LinkOwnedEntityPacket::new);

    public LinkOwnedEntityPacket(Entity owner, @Nullable Entity ownedEntity) {
        this(owner.getId(), ownedEntity == null ? 0 : ownedEntity.getId());
    }

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
