// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.world.features;

import com.kyanite.deeperdarker.util.SimpleWorleyNoise;
import com.kyanite.deeperdarker.world.features.config.FloesFeatureConfiguration;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.levelgen.feature.Feature;

public class FloesFeature implements Feature {
    public static final MapCodec<FloesFeature> CODEC = FloesFeatureConfiguration.CODEC.xmap(FloesFeature::new, feature -> feature.configuration);
    private final FloesFeatureConfiguration configuration;
    public FloesFeature(FloesFeatureConfiguration configuration) { this.configuration = configuration; }
    @Override public MapCodec<FloesFeature> codec() { return CODEC; }

    @Override
    public boolean place(net.minecraft.world.level.WorldGenLevel level, net.minecraft.world.level.chunk.ChunkGenerator generator, net.minecraft.util.RandomSource random, net.minecraft.core.BlockPos origin) {
        return generate(new DDFeatureContext<>(configuration, level, generator, random, origin));
    }
    private boolean generate(DDFeatureContext<FloesFeatureConfiguration> featurePlaceContext) {
        FloesFeatureConfiguration config = featurePlaceContext.config();
        WorldGenLevel worldGenLevel = featurePlaceContext.level();
        RandomSource random = RandomSource.create(worldGenLevel.getSeed());
        BlockPos blockPos = featurePlaceContext.origin();
        SimpleWorleyNoise noise = SimpleWorleyNoise.create(random);
        // Biome zoom at this feature's outer edge can sample two chunks away.
        // 26.3 only guarantees structure starts there, so use the generation
        // biome resolver instead of asking those chunks for stored biomes.
        var biomeManager = worldGenLevel.getBiomeManager()
                .withDifferentSource(worldGenLevel::getUncachedNoiseBiome);
        BlockPos.MutableBlockPos mutableBlockPos = new BlockPos.MutableBlockPos();
        for (int dz = 0; dz < 48; dz++) {
            for (int dx = 0; dx < 48; dx++) {
                int x = blockPos.getX() - 16 + dx;
                int z = blockPos.getZ() - 16 + dz;

                if (!biomeManager.getBiome(new BlockPos(x, Math.max(config.maxFloeHeight(), config.maxSeamHeight()), z)).is(config.allowedBiomes())) continue;

                float value = noise.get(x, z, SimpleWorleyNoise.ReturnValue.DISTANCE_TO_EDGE);
                boolean floe = value > config.threshold();
                for (int y = worldGenLevel.getMinY(); y < (floe ? config.maxFloeHeight() : config.maxSeamHeight()); y++) {
                    mutableBlockPos.set(x, y, z);
                    if (worldGenLevel.getBlockState(mutableBlockPos).isAir()) {
                        if (floe) {
                            worldGenLevel.setBlock(mutableBlockPos, config.floeBlockState().getState(worldGenLevel, random, mutableBlockPos), Block.UPDATE_ALL);
                        } else if (config.seamBlockState().isPresent()) {
                            worldGenLevel.setBlock(mutableBlockPos, config.seamBlockState().get().getState(worldGenLevel, random, mutableBlockPos), Block.UPDATE_ALL);
                        }
                    }
                }
            }
        }
        return true;
    }
}
