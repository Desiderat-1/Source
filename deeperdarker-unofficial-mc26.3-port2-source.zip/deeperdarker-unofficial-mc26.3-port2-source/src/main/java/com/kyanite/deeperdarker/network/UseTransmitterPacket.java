// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.network;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

public record UseTransmitterPacket() implements CustomPacketPayload {
    public static final Type<UseTransmitterPacket> TYPE = new Type<>(Identifier.fromNamespaceAndPath("deeperdarker", "use_transmitter"));
    public static final StreamCodec<ByteBuf, UseTransmitterPacket> CODEC = StreamCodec.unit(new UseTransmitterPacket());


    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
