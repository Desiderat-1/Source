// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.content.components;

import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;

public final class DDDataComponents {
    public static final DataComponentType<TransmitterLink> TRANSMITTER_LINK = Registry.register(BuiltInRegistries.DATA_COMPONENT_TYPE,
        Identifier.fromNamespaceAndPath("deeperdarker", "transmitter_link"),
        DataComponentType.<TransmitterLink>builder().persistent(TransmitterLink.CODEC).networkSynchronized(TransmitterLink.STREAM_CODEC).build());
    public static final DataComponentType<Boolean> HAS_HORNS = flag("has_horns");
    public static final DataComponentType<Boolean> ACID_RESISTANT = flag("acid_resistant");
    public static final DataComponentType<Boolean> AUGMENTED = flag("augmented");
    public static final DataComponentType<Boolean> REINVOKED = flag("reinvoked");
    public static final DataComponentType<net.minecraft.world.item.ItemStackTemplate> AUGMENT_ITEM = Registry.register(
        BuiltInRegistries.DATA_COMPONENT_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "augment_item"),
        DataComponentType.<net.minecraft.world.item.ItemStackTemplate>builder()
            .persistent(net.minecraft.world.item.ItemStackTemplate.CODEC)
            .networkSynchronized(net.minecraft.world.item.ItemStackTemplate.STREAM_CODEC).build());
    private static DataComponentType<Boolean> flag(String name) {
        return Registry.register(BuiltInRegistries.DATA_COMPONENT_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", name),
            DataComponentType.<Boolean>builder().persistent(com.mojang.serialization.Codec.BOOL)
                .networkSynchronized(net.minecraft.network.codec.ByteBufCodecs.BOOL).build());
    }
    private DDDataComponents() {}
    public static void init() {}
}
