// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.world.features.config;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.util.valueproviders.IntProvider;
import net.minecraft.world.level.levelgen.feature.stateproviders.BlockStateProvider;

public class BoulderFeatureConfiguration {
    public static final MapCodec<BoulderFeatureConfiguration> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            BlockStateProvider.DIRECT_CODEC.fieldOf("state_provider").forGetter(f -> f.stateProvider),
            net.minecraft.util.valueproviders.IntProviders.codec(1, 64).fieldOf("diameter").forGetter(f -> f.diameter)
    ).apply(instance, BoulderFeatureConfiguration::new));
    public final BlockStateProvider stateProvider;
    public final IntProvider diameter;

    public BoulderFeatureConfiguration(BlockStateProvider stateProvider, IntProvider diameter) {
        this.stateProvider = stateProvider;
        this.diameter = diameter;
    }
}
