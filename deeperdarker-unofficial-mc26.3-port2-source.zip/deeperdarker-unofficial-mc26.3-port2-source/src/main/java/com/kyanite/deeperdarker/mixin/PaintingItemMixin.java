package com.kyanite.deeperdarker.mixin;
import com.kyanite.deeperdarker.DeeperDarker;
import com.kyanite.deeperdarker.util.DDTags;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.HangingEntityItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import java.util.Optional;
@Mixin(HangingEntityItem.class)
public abstract class PaintingItemMixin {
    @ModifyExpressionValue(method="appendHoverText", at=@At(value="INVOKE",
        target="Lnet/minecraft/world/entity/decoration/painting/PaintingVariant;title()Ljava/util/Optional;"))
    private Optional<Component> deeperdarker$obfuscateAncientPaintingName(Optional<Component> title,
            @Local(argsOnly=true) ItemStack stack, @Local(argsOnly=true) TooltipFlag flag) {
        var variant=stack.get(DataComponents.PAINTING_VARIANT);
        return variant != null && variant.is(DDTags.Paintings.ANCIENT) && !flag.isCreative()
            ? title.map(text -> text.copy().withStyle(ChatFormatting.OBFUSCATED)) : title;
    }
    @WrapOperation(method="useOn", at=@At(value="INVOKE", target="Lnet/minecraft/world/item/ItemStack;shrink(I)V"))
    private void deeperdarker$decrementStackOnServer(ItemStack stack, int count, Operation<Void> original,
            @Local Level level) {
        if (!level.isClientSide() || !DeeperDarker.CONFIG.client.paintingFix()) original.call(stack,count);
    }
}
