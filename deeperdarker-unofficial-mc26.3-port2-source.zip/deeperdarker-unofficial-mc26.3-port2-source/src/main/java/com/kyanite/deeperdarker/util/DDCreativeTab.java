// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.util;

import com.kyanite.deeperdarker.DeeperDarker;

import com.kyanite.deeperdarker.content.DDBlocks;
import com.kyanite.deeperdarker.content.DDItems;

import net.fabricmc.fabric.api.creativetab.v1.FabricCreativeModeTab;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.decoration.painting.Painting;
import net.minecraft.world.entity.decoration.painting.PaintingVariant;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.alchemy.Potions;

public class DDCreativeTab {
    private static final CreativeModeTab.Builder ITEM_GROUP_BUILDER = FabricCreativeModeTab.builder().title(Component.translatable("itemGroup.deeperdarker")).icon(() -> new ItemStack(DDItems.WARDEN_SWORD)).displayItems(((displayContext, entries) -> {
        entries.accept(DDBlocks.ECHO_LOG);
        entries.accept(DDBlocks.ECHO_WOOD);
        entries.accept(DDBlocks.STRIPPED_ECHO_LOG);
        entries.accept(DDBlocks.STRIPPED_ECHO_WOOD);
        entries.accept(DDBlocks.ECHO_PLANKS);
        entries.accept(DDBlocks.ECHO_STAIRS);
        entries.accept(DDBlocks.ECHO_SLAB);
        entries.accept(DDBlocks.ECHO_FENCE);
        entries.accept(DDBlocks.ECHO_FENCE_GATE);
        entries.accept(DDBlocks.ECHO_DOOR);
        entries.accept(DDBlocks.ECHO_TRAPDOOR);
        entries.accept(DDBlocks.ECHO_PRESSURE_PLATE);
        entries.accept(DDBlocks.ECHO_BUTTON);
        entries.accept(DDBlocks.ECHO_LEAVES);
        entries.accept(DDBlocks.ECHO_SAPLING);

        entries.accept(DDBlocks.BLOOMING_STEM);
        entries.accept(DDBlocks.STRIPPED_BLOOMING_STEM);
        entries.accept(DDBlocks.BLOOM_PLANKS);
        entries.accept(DDBlocks.BLOOM_STAIRS);
        entries.accept(DDBlocks.BLOOM_SLAB);
        entries.accept(DDBlocks.BLOOM_FENCE);
        entries.accept(DDBlocks.BLOOM_FENCE_GATE);
        entries.accept(DDBlocks.BLOOM_DOOR);
        entries.accept(DDBlocks.BLOOM_TRAPDOOR);
        entries.accept(DDBlocks.BLOOM_PRESSURE_PLATE);
        entries.accept(DDBlocks.BLOOM_BUTTON);

        entries.accept(DDBlocks.SCULK_SPRUCE_LOG);
        entries.accept(DDBlocks.SCULK_SPRUCE_WOOD);
        entries.accept(DDBlocks.STRIPPED_SCULK_SPRUCE_LOG);
        entries.accept(DDBlocks.STRIPPED_SCULK_SPRUCE_WOOD);
        entries.accept(DDBlocks.SCULK_SPRUCE_PLANKS);
        entries.accept(DDBlocks.SCULK_SPRUCE_STAIRS);
        entries.accept(DDBlocks.SCULK_SPRUCE_SLAB);
        entries.accept(DDBlocks.SCULK_SPRUCE_FENCE);
        entries.accept(DDBlocks.SCULK_SPRUCE_FENCE_GATE);
        entries.accept(DDBlocks.SCULK_SPRUCE_DOOR);
        entries.accept(DDBlocks.SCULK_SPRUCE_TRAPDOOR);
        entries.accept(DDBlocks.SCULK_SPRUCE_PRESSURE_PLATE);
        entries.accept(DDBlocks.SCULK_SPRUCE_BUTTON);
        entries.accept(DDBlocks.SCULK_SPRUCE_LEAVES);
        entries.accept(DDBlocks.SCULK_SPRUCE_SAPLING);
        entries.accept(DDBlocks.ICICLE);

        entries.accept(DDItems.SCULK_TORCH);
        entries.accept(DDBlocks.SCULK_CAMPFIRE);
        entries.accept(DDBlocks.SCULK_LANTERN);
        entries.accept(DDBlocks.SCULK_STONE);
        entries.accept(DDBlocks.SCULK_STONE_STAIRS);
        entries.accept(DDBlocks.SCULK_STONE_SLAB);
        entries.accept(DDBlocks.SCULK_STONE_WALL);
        entries.accept(DDBlocks.COBBLED_SCULK_STONE);
        entries.accept(DDBlocks.COBBLED_SCULK_STONE_STAIRS);
        entries.accept(DDBlocks.COBBLED_SCULK_STONE_SLAB);
        entries.accept(DDBlocks.COBBLED_SCULK_STONE_WALL);
        entries.accept(DDBlocks.POLISHED_SCULK_STONE);
        entries.accept(DDBlocks.POLISHED_SCULK_STONE_STAIRS);
        entries.accept(DDBlocks.POLISHED_SCULK_STONE_SLAB);
        entries.accept(DDBlocks.POLISHED_SCULK_STONE_WALL);
        entries.accept(DDBlocks.SCULK_STONE_BRICKS);
        entries.accept(DDBlocks.SCULK_STONE_BRICK_STAIRS);
        entries.accept(DDBlocks.SCULK_STONE_BRICK_SLAB);
        entries.accept(DDBlocks.SCULK_STONE_BRICK_WALL);
        entries.accept(DDBlocks.SCULK_STONE_TILES);
        entries.accept(DDBlocks.SCULK_STONE_TILE_STAIRS);
        entries.accept(DDBlocks.SCULK_STONE_TILE_SLAB);
        entries.accept(DDBlocks.SCULK_STONE_TILE_WALL);
        entries.accept(DDBlocks.SMOOTH_SCULK_STONE);
        entries.accept(DDBlocks.SMOOTH_SCULK_STONE_STAIRS);
        entries.accept(DDBlocks.SMOOTH_SCULK_STONE_SLAB);
        entries.accept(DDBlocks.SMOOTH_SCULK_STONE_WALL);
        entries.accept(DDBlocks.CUT_SCULK_STONE);
        entries.accept(DDBlocks.CUT_SCULK_STONE_STAIRS);
        entries.accept(DDBlocks.CUT_SCULK_STONE_SLAB);
        entries.accept(DDBlocks.CUT_SCULK_STONE_WALL);
        entries.accept(DDBlocks.CHISELED_SCULK_STONE);

        entries.accept(DDBlocks.SCULK_FERN);
        entries.accept(DDBlocks.LARGE_SCULK_FERN);

        entries.accept(DDBlocks.SCULK_GRIME);
        entries.accept(DDBlocks.SCULK_GRIME_BRICKS);
        entries.accept(DDBlocks.SCULK_GRIME_BRICK_STAIRS);
        entries.accept(DDBlocks.SCULK_GRIME_BRICK_SLAB);
        entries.accept(DDBlocks.SCULK_GRIME_BRICK_WALL);
        entries.accept(DDBlocks.FRAGILE_SCULK_GRIME_BRICKS);
        entries.accept(DDBlocks.SCULK_GRIME_LOCK);
        entries.accept(DDBlocks.FORTIFIED_SCULK_GRIME_BRICKS);
        entries.accept(DDBlocks.PROTECTED_SCULK_GRIME_GLASS);
        entries.accept(DDBlocks.SCULK_GRIME_GLASS);
        entries.accept(DDBlocks.SCULK_GRIME_GLASS_PANE);
        entries.accept(DDBlocks.SCULK_PERMAFROST);
        entries.accept(DDBlocks.SNOWY_SCULK_PERMAFROST);
        entries.accept(DDBlocks.BLOOMING_SCULK_STONE);
        entries.accept(DDBlocks.BLOOMING_MOSS_BLOCK);
        entries.accept(DDBlocks.ECHO_SOIL);
        entries.accept(DDBlocks.ECHO_FARMLAND);

        entries.accept(DDBlocks.GLOOMSLATE);
        entries.accept(DDBlocks.GLOOMSLATE_STAIRS);
        entries.accept(DDBlocks.GLOOMSLATE_SLAB);
        entries.accept(DDBlocks.GLOOMSLATE_WALL);
        entries.accept(DDBlocks.COBBLED_GLOOMSLATE);
        entries.accept(DDBlocks.COBBLED_GLOOMSLATE_STAIRS);
        entries.accept(DDBlocks.COBBLED_GLOOMSLATE_SLAB);
        entries.accept(DDBlocks.COBBLED_GLOOMSLATE_WALL);
        entries.accept(DDBlocks.POLISHED_GLOOMSLATE);
        entries.accept(DDBlocks.POLISHED_GLOOMSLATE_STAIRS);
        entries.accept(DDBlocks.POLISHED_GLOOMSLATE_SLAB);
        entries.accept(DDBlocks.POLISHED_GLOOMSLATE_WALL);
        entries.accept(DDBlocks.GLOOMSLATE_BRICKS);
        entries.accept(DDBlocks.GLOOMSLATE_BRICK_STAIRS);
        entries.accept(DDBlocks.GLOOMSLATE_BRICK_SLAB);
        entries.accept(DDBlocks.GLOOMSLATE_BRICK_WALL);
        entries.accept(DDBlocks.GLOOMSLATE_TILES);
        entries.accept(DDBlocks.GLOOMSLATE_TILE_STAIRS);
        entries.accept(DDBlocks.GLOOMSLATE_TILE_SLAB);
        entries.accept(DDBlocks.GLOOMSLATE_TILE_WALL);
        entries.accept(DDBlocks.SMOOTH_GLOOMSLATE);
        entries.accept(DDBlocks.SMOOTH_GLOOMSLATE_STAIRS);
        entries.accept(DDBlocks.SMOOTH_GLOOMSLATE_SLAB);
        entries.accept(DDBlocks.SMOOTH_GLOOMSLATE_WALL);
        entries.accept(DDBlocks.CUT_GLOOMSLATE);
        entries.accept(DDBlocks.CUT_GLOOMSLATE_STAIRS);
        entries.accept(DDBlocks.CUT_GLOOMSLATE_SLAB);
        entries.accept(DDBlocks.CUT_GLOOMSLATE_WALL);
        entries.accept(DDBlocks.CHISELED_GLOOMSLATE);
        entries.accept(DDBlocks.GLOOMSLATE_BARRIER);
        entries.accept(DDBlocks.FRAGILE_GLOOMSLATE_BRICKS);
        entries.accept(DDBlocks.GLOOMSLATE_LOCK);
        entries.accept(DDBlocks.FORTIFIED_CUT_GLOOMSLATE);

        entries.accept(DDBlocks.GLOOMY_SCULK);
        entries.accept(DDBlocks.GLOOMY_GEYSER);
        entries.accept(DDBlocks.CRYSTALLIZED_AMBER);
        entries.accept(DDBlocks.SCULK_GLEAM);
        entries.accept(DDBlocks.PROTECTED_SCULK_GLEAM);
        entries.accept(DDBlocks.SCULK_LAMP);
        entries.accept(DDBlocks.SOUNDPROOF_GLASS);

        entries.accept(DDBlocks.SCULK_STONE_COAL_ORE);
        entries.accept(DDBlocks.SCULK_STONE_IRON_ORE);
        entries.accept(DDBlocks.SCULK_STONE_COPPER_ORE);
        entries.accept(DDBlocks.SCULK_STONE_GOLD_ORE);
        entries.accept(DDBlocks.SCULK_STONE_REDSTONE_ORE);
        entries.accept(DDBlocks.SCULK_STONE_EMERALD_ORE);
        entries.accept(DDBlocks.SCULK_STONE_LAPIS_ORE);
        entries.accept(DDBlocks.SCULK_STONE_DIAMOND_ORE);
        entries.accept(DDBlocks.SCULK_STONE_LEAD_ORE);
        entries.accept(DDBlocks.GLOOMSLATE_COAL_ORE);
        entries.accept(DDBlocks.GLOOMSLATE_IRON_ORE);
        entries.accept(DDBlocks.GLOOMSLATE_COPPER_ORE);
        entries.accept(DDBlocks.GLOOMSLATE_GOLD_ORE);
        entries.accept(DDBlocks.GLOOMSLATE_REDSTONE_ORE);
        entries.accept(DDBlocks.GLOOMSLATE_EMERALD_ORE);
        entries.accept(DDBlocks.GLOOMSLATE_LAPIS_ORE);
        entries.accept(DDBlocks.GLOOMSLATE_DIAMOND_ORE);

        entries.accept(DDBlocks.RAW_LEAD_BLOCK);
        entries.accept(DDBlocks.LEAD_BLOCK);
        entries.accept(DDItems.RAW_LEAD);
        entries.accept(DDItems.LEAD_INGOT);

        entries.accept(DDBlocks.GLOWING_FLOWERS);
        entries.accept(DDBlocks.GLOWING_GRASS);
        entries.accept(DDBlocks.GLOOMY_GRASS);
        entries.accept(DDBlocks.GLOOMY_CACTUS);
        entries.accept(DDBlocks.SCULK_TENDRILS);
        entries.accept(DDBlocks.SCULK_VINES);
        entries.accept(DDBlocks.GLOWING_ROOTS);
        entries.accept(DDItems.ICE_LILY);
        entries.accept(DDItems.LILY_FLOWER);

        entries.accept(DDItems.ECHO_SIGN);
        entries.accept(DDItems.ECHO_HANGING_SIGN);
        entries.accept(DDItems.BLOOM_SIGN);
        entries.accept(DDItems.BLOOM_HANGING_SIGN);
        entries.accept(DDItems.SCULK_SPRUCE_SIGN);
        entries.accept(DDItems.SCULK_SPRUCE_HANGING_SIGN);

        entries.accept(DDBlocks.ANCIENT_VASE);
        entries.accept(DDBlocks.INFESTED_SCULK);
        entries.accept(DDBlocks.SCULK_JAW);

        entries.accept(DDBlocks.SCULK_TISSUE);
        entries.accept(DDBlocks.SCULK_TISSUE_BRICKS);
        entries.accept(DDBlocks.SCULK_TISSUE_BRICK_STAIRS);
        entries.accept(DDBlocks.SCULK_TISSUE_BRICK_SLAB);
        entries.accept(DDBlocks.SCULK_TISSUE_BRICK_WALL);
        entries.accept(DDBlocks.DARK_FOUNTAIN);
        entries.accept(DDBlocks.SHADOW_CRYSTAL_BLOCK);

        entries.accept(DDItems.SCULK_TISSUE_BRICK);
        entries.accept(DDItems.SHADOW_CRYSTAL);
        entries.accept(DDItems.SUNGLASSES);

        entries.accept(DDItems.BLOOM_BERRIES);
        entries.accept(DDItems.SCULK_TUBER);
        entries.accept(DDItems.SCULK_BERRY_SPROUT);
        entries.accept(DDItems.SCULK_BERRY);

        entries.accept(DDItems.GRIME_BALL);
        entries.accept(DDItems.GRIME_BRICK);

        entries.accept(DDBlocks.SCULK_BASALT);
        entries.accept(DDItems.ACID_BUCKET);
        entries.accept(DDItems.FIZZ);
        entries.accept(DDBlocks.FIZZ_BLOCK);
        entries.accept(DDItems.SCULK_DRINK);
        entries.accept(DDBlocks.RADIOACTIVE_BLOCK);
        entries.accept(DDItems.RADIOACTIVE_INGOT);
        entries.accept(DDItems.SHIELD_AUGMENT);

        ItemStack shield = new ItemStack(Items.SHIELD);
        DDUtil.setAugmented(shield);
        entries.accept(shield);

        entries.accept(DDBlocks.RED_CRYSTAL_BLOCK);
        entries.accept(DDBlocks.GREEN_CRYSTAL_BLOCK);
        entries.accept(DDBlocks.BLUE_CRYSTAL_BLOCK);

        entries.accept(DDItems.SOUL_ELYTRA);
        entries.accept(DDItems.ECHO_BOAT);
        entries.accept(DDItems.ECHO_CHEST_BOAT);
        entries.accept(DDItems.BLOOM_BOAT);
        entries.accept(DDItems.BLOOM_CHEST_BOAT);
        entries.accept(DDItems.SCULK_SPRUCE_BOAT);
        entries.accept(DDItems.SCULK_SPRUCE_CHEST_BOAT);

        entries.accept(DDItems.RESONARIUM_SHOVEL);
        entries.accept(DDItems.RESONARIUM_PICKAXE);
        entries.accept(DDItems.RESONARIUM_AXE);
        entries.accept(DDItems.RESONARIUM_HOE);
        entries.accept(DDItems.RESONARIUM_SWORD);
        entries.accept(DDItems.RESONARIUM_HELMET);
        entries.accept(DDItems.RESONARIUM_CHESTPLATE);
        entries.accept(DDItems.RESONARIUM_LEGGINGS);
        entries.accept(DDItems.RESONARIUM_BOOTS);

        entries.accept(DDItems.LEAD_SHOVEL);
        entries.accept(DDItems.LEAD_PICKAXE);
        entries.accept(DDItems.LEAD_AXE);
        entries.accept(DDItems.LEAD_HOE);
        entries.accept(DDItems.LEAD_SWORD);
        entries.accept(DDItems.LEAD_HELMET);
        entries.accept(DDItems.LEAD_CHESTPLATE);
        entries.accept(DDItems.LEAD_LEGGINGS);
        entries.accept(DDItems.LEAD_BOOTS);

        entries.accept(DDItems.RADIOACTIVE_SHOVEL);
        entries.accept(DDItems.RADIOACTIVE_PICKAXE);
        entries.accept(DDItems.RADIOACTIVE_AXE);
        entries.accept(DDItems.RADIOACTIVE_HOE);
        entries.accept(DDItems.RADIOACTIVE_SWORD);
        entries.accept(DDItems.RADIOACTIVE_HELMET);
        entries.accept(DDItems.RADIOACTIVE_CHESTPLATE);
        entries.accept(DDItems.RADIOACTIVE_LEGGINGS);
        entries.accept(DDItems.RADIOACTIVE_BOOTS);

        entries.accept(DDItems.WARDEN_SHOVEL);
        entries.accept(DDItems.WARDEN_PICKAXE);
        entries.accept(DDItems.WARDEN_AXE);
        entries.accept(DDItems.WARDEN_HOE);
        entries.accept(DDItems.WARDEN_SWORD);
        entries.accept(DDItems.WARDEN_HELMET);
        entries.accept(DDItems.WARDEN_CHESTPLATE);
        entries.accept(DDItems.WARDEN_LEGGINGS);
        entries.accept(DDItems.WARDEN_BOOTS);

        entries.accept(DDItems.GUARDIAN_SHOVEL);
        entries.accept(DDItems.GUARDIAN_PICKAXE);
        entries.accept(DDItems.GUARDIAN_AXE);
        entries.accept(DDItems.GUARDIAN_HOE);
        entries.accept(DDItems.GUARDIAN_SWORD);
        entries.accept(DDItems.GUARDIAN_HELMET);
        entries.accept(DDItems.GUARDIAN_CHESTPLATE);
        entries.accept(DDItems.GUARDIAN_LEGGINGS);
        entries.accept(DDItems.GUARDIAN_BOOTS);

        entries.accept(DDItems.SCULK_BONE);
        entries.accept(DDItems.SCULK_BONE_SHARD);
        entries.accept(DDItems.OTHERSIDE_FIRE_STRIKER);
        entries.accept(DDItems.SOUL_DUST);
        entries.accept(DDItems.SOUL_CRYSTAL);
        entries.accept(DDItems.RESONARIUM);
        entries.accept(DDItems.RESONARIUM_PLATE);
        entries.accept(DDItems.HEART_OF_THE_DEEP);
        entries.accept(DDItems.WARDEN_CARAPACE);
        entries.accept(DDItems.REINFORCED_ECHO_SHARD);
        entries.accept(DDItems.PATIENCE_SOUL);
        entries.accept(DDItems.FORTITUDE_SOUL);
        entries.accept(DDItems.CORRUPTION_SOUL);
        entries.accept(DDItems.PURITY_SOUL);
        entries.accept(DDItems.VIRTUE_SOUL);
        entries.accept(DDItems.ROYAL_SCEPTER);
        entries.accept(DDItems.DAINTY_KEY);
        entries.accept(DDItems.KEYBRAND);

        entries.accept(DDItems.SCULK_TRANSMITTER);
        entries.accept(DDItems.WHITE_SCULK_TRANSMITTER);
        entries.accept(DDItems.ORANGE_SCULK_TRANSMITTER);
        entries.accept(DDItems.MAGENTA_SCULK_TRANSMITTER);
        entries.accept(DDItems.LIGHT_BLUE_SCULK_TRANSMITTER);
        entries.accept(DDItems.YELLOW_SCULK_TRANSMITTER);
        entries.accept(DDItems.LIME_SCULK_TRANSMITTER);
        entries.accept(DDItems.PINK_SCULK_TRANSMITTER);
        entries.accept(DDItems.GRAY_SCULK_TRANSMITTER);
        entries.accept(DDItems.LIGHT_GRAY_SCULK_TRANSMITTER);
        entries.accept(DDItems.CYAN_SCULK_TRANSMITTER);
        entries.accept(DDItems.PURPLE_SCULK_TRANSMITTER);
        entries.accept(DDItems.BLUE_SCULK_TRANSMITTER);
        entries.accept(DDItems.BROWN_SCULK_TRANSMITTER);
        entries.accept(DDItems.GREEN_SCULK_TRANSMITTER);
        entries.accept(DDItems.RED_SCULK_TRANSMITTER);
        entries.accept(DDItems.BLACK_SCULK_TRANSMITTER);
        entries.accept(DDItems.SONOROUS_STAFF);
        entries.accept(DDItems.WARDEN_UPGRADE_SMITHING_TEMPLATE);
        entries.accept(DDItems.GUARDIAN_UPGRADE_SMITHING_TEMPLATE);

        entries.accept(DDItems.ANGLER_FISH_SPAWN_EGG);
        entries.accept(DDItems.SCULK_CENTIPEDE_SPAWN_EGG);
        entries.accept(DDItems.SCULK_LEECH_SPAWN_EGG);
        entries.accept(DDItems.SCULK_SNAPPER_SPAWN_EGG);
        entries.accept(DDItems.SHATTERED_SPAWN_EGG);
        entries.accept(DDItems.SHRIEK_WORM_SPAWN_EGG);
        entries.accept(DDItems.SLUDGE_SPAWN_EGG);
        entries.accept(DDItems.STALKER_SPAWN_EGG);
        entries.accept(DDItems.POTTY_SPAWN_EGG);
        entries.accept(DDItems.POT_SPAWN_EGG);
        entries.accept(DDItems.POTTER_SPAWN_EGG);
        entries.accept(DDItems.ACID_SPRITE_SPAWN_EGG);
        entries.accept(DDBlocks.DEAD_MANS_CHEST);
        entries.accept(DDItems.SHATTERED_HEAD);
        for (Holder<PaintingVariant> variant : displayContext.holders().lookupOrThrow(Registries.PAINTING_VARIANT).getOrThrow(DDTags.Paintings.ANCIENT)) {
            ItemStack itemStack = new ItemStack(Items.PAINTING);
            itemStack.set(net.minecraft.core.component.DataComponents.PAINTING_VARIANT, variant);
            entries.accept(itemStack);
        }
        generatePotions(displayContext, entries, Items.TIPPED_ARROW);
        generatePotions(displayContext, entries, Items.POTION);
        generatePotions(displayContext, entries, Items.SPLASH_POTION);
        generatePotions(displayContext, entries, Items.LINGERING_POTION);
    }));

    private static void generatePotions(CreativeModeTab.ItemDisplayParameters displayParameters, CreativeModeTab.Output output, Item item) {
        displayParameters.holders().lookup(Registries.POTION).ifPresent(lookup -> {
            lookup.listElements()
                    .filter(reference -> reference.key().identifier().getNamespace().equals(DeeperDarker.MOD_ID))
                    .map(reference -> PotionContents.createItemStack(item, reference))
                    .forEach(output::accept);
        });
    }

    public static CreativeModeTab DEEPER_AND_DARKER;

    public static void init() {
        DEEPER_AND_DARKER = Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "deeper_and_darker"), ITEM_GROUP_BUILDER.build());
        DeeperDarker.LOGGER.debug("Registering creative tab");
    }
}
