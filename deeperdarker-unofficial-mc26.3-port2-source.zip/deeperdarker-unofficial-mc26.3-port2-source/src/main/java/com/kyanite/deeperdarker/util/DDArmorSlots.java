// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.util;
import java.util.List;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
public final class DDArmorSlots {
    private DDArmorSlots() {}
    /** Preserve the original humanoid armor order; other entities have no armor slots. */
    public static List<ItemStack> of(Entity entity) {
        if (!(entity instanceof LivingEntity living)) return List.of();
        return List.of(living.getItemBySlot(EquipmentSlot.FEET), living.getItemBySlot(EquipmentSlot.LEGS),
                living.getItemBySlot(EquipmentSlot.CHEST), living.getItemBySlot(EquipmentSlot.HEAD));
    }
}
