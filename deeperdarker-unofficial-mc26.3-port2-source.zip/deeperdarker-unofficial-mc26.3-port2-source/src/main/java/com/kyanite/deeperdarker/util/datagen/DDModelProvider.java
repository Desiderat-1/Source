// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.util.datagen;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.kyanite.deeperdarker.DeeperDarker;
import com.kyanite.deeperdarker.compat.create.DDCreateCompat;
import com.kyanite.deeperdarker.content.DDBlocks;
import com.kyanite.deeperdarker.content.DDItems;
import com.kyanite.deeperdarker.content.blocks.BloomingStemBlock;
import com.kyanite.deeperdarker.content.blocks.SculkBerryBlock;
import com.kyanite.deeperdarker.content.blocks.SculkJawBlock;
import com.kyanite.deeperdarker.content.blocks.vegetation.GlowingVinesPlantBlock;
import com.kyanite.deeperdarker.content.blocks.vegetation.IceLilyBlock;
import com.kyanite.deeperdarker.content.items.SculkTransmitterItem;
import com.kyanite.deeperdarker.mixin.ItemModelGeneratorsAccessor;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricModelProvider;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.client.data.models.BlockModelGenerators;
import net.minecraft.client.data.models.ItemModelGenerators;
import net.minecraft.data.models.blockstates.*;
import net.minecraft.data.models.model.*;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Tuple;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.properties.*;
import org.apache.commons.lang3.tuple.Triple;

import java.util.*;

public class DDModelProvider extends FabricModelProvider {
    public DDModelProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(BlockModelGenerators blockModelGenerators) {
        createGildedLog(blockModelGenerators, DDBlocks.ENRICHED_ECHO_LOG, DDBlocks.ECHO_LOG);
        blockModelGenerators.woodProvider(DDBlocks.ECHO_LOG).log(DDBlocks.ECHO_LOG).wood(DDBlocks.ECHO_WOOD);
        blockModelGenerators.woodProvider(DDBlocks.STRIPPED_ECHO_LOG).log(DDBlocks.STRIPPED_ECHO_LOG).wood(DDBlocks.STRIPPED_ECHO_WOOD);
        blockModelGenerators.family(DDBlocks.ECHO_LEAVES);
        blockModelGenerators.family(DDBlocks.ECHO_PLANKS);
        registerStairs(blockModelGenerators, DDBlocks.ECHO_STAIRS, DDBlocks.ECHO_PLANKS);
        registerSlabWithCubeAll(blockModelGenerators, DDBlocks.ECHO_SLAB, DDBlocks.ECHO_PLANKS);
        registerFence(blockModelGenerators, DDBlocks.ECHO_FENCE, DDBlocks.ECHO_PLANKS);
        registerFenceGate(blockModelGenerators, DDBlocks.ECHO_FENCE_GATE, DDBlocks.ECHO_PLANKS);
        blockModelGenerators.createDoor(DDBlocks.ECHO_DOOR);
        blockModelGenerators.createOrientableTrapdoor(DDBlocks.ECHO_TRAPDOOR);
        registerPressurePlate(blockModelGenerators, DDBlocks.ECHO_PRESSURE_PLATE, DDBlocks.ECHO_PLANKS);
        registerButton(blockModelGenerators, DDBlocks.ECHO_BUTTON, DDBlocks.ECHO_PLANKS);
        blockModelGenerators.createCrossBlockWithDefaultItem(DDBlocks.ECHO_SAPLING, net.minecraft.client.data.models.BlockModelGenerators.TintState.NOT_TINTED);
        blockModelGenerators.createHangingSign(DDBlocks.ECHO_PLANKS, DDBlocks.ECHO_SIGN, DDBlocks.ECHO_WALL_SIGN);
        blockModelGenerators.createHangingSign(DDBlocks.STRIPPED_ECHO_LOG, DDBlocks.ECHO_HANGING_SIGN, DDBlocks.ECHO_WALL_HANGING_SIGN);

        blockModelGenerators.woodProvider(DDBlocks.SCULK_SPRUCE_LOG).log(DDBlocks.SCULK_SPRUCE_LOG).wood(DDBlocks.SCULK_SPRUCE_WOOD);
        blockModelGenerators.woodProvider(DDBlocks.STRIPPED_SCULK_SPRUCE_LOG).log(DDBlocks.STRIPPED_SCULK_SPRUCE_LOG).wood(DDBlocks.STRIPPED_SCULK_SPRUCE_WOOD);
        blockModelGenerators.family(DDBlocks.SCULK_SPRUCE_LEAVES);
        blockModelGenerators.family(DDBlocks.SCULK_SPRUCE_PLANKS);
        registerStairs(blockModelGenerators, DDBlocks.SCULK_SPRUCE_STAIRS, DDBlocks.SCULK_SPRUCE_PLANKS);
        registerSlabWithCubeAll(blockModelGenerators, DDBlocks.SCULK_SPRUCE_SLAB, DDBlocks.SCULK_SPRUCE_PLANKS);
        registerFence(blockModelGenerators, DDBlocks.SCULK_SPRUCE_FENCE, DDBlocks.SCULK_SPRUCE_PLANKS);
        registerFenceGate(blockModelGenerators, DDBlocks.SCULK_SPRUCE_FENCE_GATE, DDBlocks.SCULK_SPRUCE_PLANKS);
        blockModelGenerators.createDoor(DDBlocks.SCULK_SPRUCE_DOOR);
        blockModelGenerators.createOrientableTrapdoor(DDBlocks.SCULK_SPRUCE_TRAPDOOR);
        registerPressurePlate(blockModelGenerators, DDBlocks.SCULK_SPRUCE_PRESSURE_PLATE, DDBlocks.SCULK_SPRUCE_PLANKS);
        registerButton(blockModelGenerators, DDBlocks.SCULK_SPRUCE_BUTTON, DDBlocks.SCULK_SPRUCE_PLANKS);
        blockModelGenerators.createCrossBlockWithDefaultItem(DDBlocks.SCULK_SPRUCE_SAPLING, net.minecraft.client.data.models.BlockModelGenerators.TintState.NOT_TINTED);
        blockModelGenerators.createHangingSign(DDBlocks.SCULK_SPRUCE_PLANKS, DDBlocks.SCULK_SPRUCE_SIGN, DDBlocks.SCULK_SPRUCE_WALL_SIGN);
        blockModelGenerators.createHangingSign(DDBlocks.STRIPPED_SCULK_SPRUCE_LOG, DDBlocks.SCULK_SPRUCE_HANGING_SIGN, DDBlocks.SCULK_SPRUCE_WALL_HANGING_SIGN);

        blockModelGenerators.family(DDBlocks.SCULK_STONE);
        registerStairs(blockModelGenerators, DDBlocks.SCULK_STONE_STAIRS, DDBlocks.SCULK_STONE);
        registerSlabWithCubeAll(blockModelGenerators, DDBlocks.SCULK_STONE_SLAB, DDBlocks.SCULK_STONE);
        registerWall(blockModelGenerators, DDBlocks.SCULK_STONE_WALL, DDBlocks.SCULK_STONE);
        blockModelGenerators.family(DDBlocks.COBBLED_SCULK_STONE);
        registerStairs(blockModelGenerators, DDBlocks.COBBLED_SCULK_STONE_STAIRS, DDBlocks.COBBLED_SCULK_STONE);
        registerSlabWithCubeAll(blockModelGenerators, DDBlocks.COBBLED_SCULK_STONE_SLAB, DDBlocks.COBBLED_SCULK_STONE);
        registerWall(blockModelGenerators, DDBlocks.COBBLED_SCULK_STONE_WALL, DDBlocks.COBBLED_SCULK_STONE);
        blockModelGenerators.family(DDBlocks.POLISHED_SCULK_STONE);
        registerStairs(blockModelGenerators, DDBlocks.POLISHED_SCULK_STONE_STAIRS, DDBlocks.POLISHED_SCULK_STONE);
        registerSlabWithCubeAll(blockModelGenerators, DDBlocks.POLISHED_SCULK_STONE_SLAB, DDBlocks.POLISHED_SCULK_STONE);
        registerWall(blockModelGenerators, DDBlocks.POLISHED_SCULK_STONE_WALL, DDBlocks.POLISHED_SCULK_STONE);
        blockModelGenerators.family(DDBlocks.SCULK_STONE_BRICKS);
        registerStairs(blockModelGenerators, DDBlocks.SCULK_STONE_BRICK_STAIRS, DDBlocks.SCULK_STONE_BRICKS);
        registerSlabWithCubeAll(blockModelGenerators, DDBlocks.SCULK_STONE_BRICK_SLAB, DDBlocks.SCULK_STONE_BRICKS);
        registerWall(blockModelGenerators, DDBlocks.SCULK_STONE_BRICK_WALL, DDBlocks.SCULK_STONE_BRICKS);
        blockModelGenerators.family(DDBlocks.SCULK_STONE_TILES);
        registerStairs(blockModelGenerators, DDBlocks.SCULK_STONE_TILE_STAIRS, DDBlocks.SCULK_STONE_TILES);
        registerSlabWithCubeAll(blockModelGenerators, DDBlocks.SCULK_STONE_TILE_SLAB, DDBlocks.SCULK_STONE_TILES);
        registerWall(blockModelGenerators, DDBlocks.SCULK_STONE_TILE_WALL, DDBlocks.SCULK_STONE_TILES);
        blockModelGenerators.family(DDBlocks.SMOOTH_SCULK_STONE);
        registerStairs(blockModelGenerators, DDBlocks.SMOOTH_SCULK_STONE_STAIRS, DDBlocks.SMOOTH_SCULK_STONE);
        registerSlabWithCubeAll(blockModelGenerators, DDBlocks.SMOOTH_SCULK_STONE_SLAB, DDBlocks.SMOOTH_SCULK_STONE);
        registerWall(blockModelGenerators, DDBlocks.SMOOTH_SCULK_STONE_WALL, DDBlocks.SMOOTH_SCULK_STONE);
        blockModelGenerators.family(DDBlocks.CUT_SCULK_STONE);
        registerStairs(blockModelGenerators, DDBlocks.CUT_SCULK_STONE_STAIRS, DDBlocks.CUT_SCULK_STONE);
        registerSlabWithCubeAll(blockModelGenerators, DDBlocks.CUT_SCULK_STONE_SLAB, DDBlocks.CUT_SCULK_STONE);
        registerWall(blockModelGenerators, DDBlocks.CUT_SCULK_STONE_WALL, DDBlocks.CUT_SCULK_STONE);
        blockModelGenerators.family(DDBlocks.CHISELED_SCULK_STONE);

        blockModelGenerators.family(DDBlocks.SCULK_GRIME);
        blockModelGenerators.family(DDBlocks.SCULK_GRIME_BRICKS);
        registerStairs(blockModelGenerators, DDBlocks.SCULK_GRIME_BRICK_STAIRS, DDBlocks.SCULK_GRIME_BRICKS);
        registerSlabWithCubeAll(blockModelGenerators, DDBlocks.SCULK_GRIME_BRICK_SLAB, DDBlocks.SCULK_GRIME_BRICKS);
        registerWall(blockModelGenerators, DDBlocks.SCULK_GRIME_BRICK_WALL, DDBlocks.SCULK_GRIME_BRICKS);
        blockModelGenerators.family(DDBlocks.FRAGILE_SCULK_GRIME_BRICKS);
        blockModelGenerators.family(DDBlocks.SCULK_GRIME_LOCK);
        blockModelGenerators.family(DDBlocks.FORTIFIED_SCULK_GRIME_BRICKS);
        blockModelGenerators.family(DDBlocks.PROTECTED_SCULK_GRIME_GLASS);
        blockModelGenerators.createGlassBlocks(DDBlocks.SCULK_GRIME_GLASS, DDBlocks.SCULK_GRIME_GLASS_PANE);
        blockModelGenerators.blockStateOutput.accept(MultiVariantGenerator.multiVariant(DDBlocks.RETURN_STATUE)
                .with(PropertyDispatch.property(BlockStateProperties.DOUBLE_BLOCK_HALF)
                        .select(DoubleBlockHalf.LOWER, Variant.variant().with(VariantProperties.MODEL, ModelLocationUtils.getModelLocation(DDBlocks.RETURN_STATUE, "_lower")))
                        .select(DoubleBlockHalf.UPPER, Variant.variant().with(VariantProperties.MODEL, ModelLocationUtils.getModelLocation(DDBlocks.RETURN_STATUE, "_upper")))));

        blockModelGenerators.family(DDBlocks.GLOOMSLATE);
        registerStairs(blockModelGenerators, DDBlocks.GLOOMSLATE_STAIRS, DDBlocks.GLOOMSLATE);
        registerSlabWithCubeAll(blockModelGenerators, DDBlocks.GLOOMSLATE_SLAB, DDBlocks.GLOOMSLATE);
        registerWall(blockModelGenerators, DDBlocks.GLOOMSLATE_WALL, DDBlocks.GLOOMSLATE);
        blockModelGenerators.family(DDBlocks.COBBLED_GLOOMSLATE);
        registerStairs(blockModelGenerators, DDBlocks.COBBLED_GLOOMSLATE_STAIRS, DDBlocks.COBBLED_GLOOMSLATE);
        registerSlabWithCubeAll(blockModelGenerators, DDBlocks.COBBLED_GLOOMSLATE_SLAB, DDBlocks.COBBLED_GLOOMSLATE);
        registerWall(blockModelGenerators, DDBlocks.COBBLED_GLOOMSLATE_WALL, DDBlocks.COBBLED_GLOOMSLATE);
        blockModelGenerators.family(DDBlocks.POLISHED_GLOOMSLATE);
        registerStairs(blockModelGenerators, DDBlocks.POLISHED_GLOOMSLATE_STAIRS, DDBlocks.POLISHED_GLOOMSLATE);
        registerSlabWithCubeAll(blockModelGenerators, DDBlocks.POLISHED_GLOOMSLATE_SLAB, DDBlocks.POLISHED_GLOOMSLATE);
        registerWall(blockModelGenerators, DDBlocks.POLISHED_GLOOMSLATE_WALL, DDBlocks.POLISHED_GLOOMSLATE);
        blockModelGenerators.family(DDBlocks.GLOOMSLATE_BRICKS);
        registerStairs(blockModelGenerators, DDBlocks.GLOOMSLATE_BRICK_STAIRS, DDBlocks.GLOOMSLATE_BRICKS);
        registerSlabWithCubeAll(blockModelGenerators, DDBlocks.GLOOMSLATE_BRICK_SLAB, DDBlocks.GLOOMSLATE_BRICKS);
        registerWall(blockModelGenerators, DDBlocks.GLOOMSLATE_BRICK_WALL, DDBlocks.GLOOMSLATE_BRICKS);
        blockModelGenerators.family(DDBlocks.GLOOMSLATE_TILES);
        registerStairs(blockModelGenerators, DDBlocks.GLOOMSLATE_TILE_STAIRS, DDBlocks.GLOOMSLATE_TILES);
        registerSlabWithCubeAll(blockModelGenerators, DDBlocks.GLOOMSLATE_TILE_SLAB, DDBlocks.GLOOMSLATE_TILES);
        registerWall(blockModelGenerators, DDBlocks.GLOOMSLATE_TILE_WALL, DDBlocks.GLOOMSLATE_TILES);
        blockModelGenerators.family(DDBlocks.SMOOTH_GLOOMSLATE);
        registerStairs(blockModelGenerators, DDBlocks.SMOOTH_GLOOMSLATE_STAIRS, DDBlocks.SMOOTH_GLOOMSLATE);
        registerSlabWithCubeAll(blockModelGenerators, DDBlocks.SMOOTH_GLOOMSLATE_SLAB, DDBlocks.SMOOTH_GLOOMSLATE);
        registerWall(blockModelGenerators, DDBlocks.SMOOTH_GLOOMSLATE_WALL, DDBlocks.SMOOTH_GLOOMSLATE);
        blockModelGenerators.family(DDBlocks.CUT_GLOOMSLATE);
        registerStairs(blockModelGenerators, DDBlocks.CUT_GLOOMSLATE_STAIRS, DDBlocks.CUT_GLOOMSLATE);
        registerSlabWithCubeAll(blockModelGenerators, DDBlocks.CUT_GLOOMSLATE_SLAB, DDBlocks.CUT_GLOOMSLATE);
        registerWall(blockModelGenerators, DDBlocks.CUT_GLOOMSLATE_WALL, DDBlocks.CUT_GLOOMSLATE);
        blockModelGenerators.family(DDBlocks.CHISELED_GLOOMSLATE);
        blockModelGenerators.family(DDBlocks.GLOOMSLATE_BARRIER);
        blockModelGenerators.family(DDBlocks.FRAGILE_GLOOMSLATE_BRICKS);
        blockModelGenerators.family(DDBlocks.GLOOMSLATE_LOCK);
        blockModelGenerators.family(DDBlocks.FORTIFIED_CUT_GLOOMSLATE);

        blockModelGenerators.family(DDBlocks.ECHO_SOIL);
        blockModelGenerators.createNonTemplateModelBlock(DDBlocks.ECHO_FARMLAND);
        registerParented(blockModelGenerators, Blocks.FARMLAND, DDBlocks.ECHO_FARMLAND,
                new Tuple<>(TextureSlot.DIRT, ModelLocationUtils.getModelLocation(DDBlocks.ECHO_SOIL)),
                new Tuple<>(TextureSlot.TOP, ModelLocationUtils.getModelLocation(DDBlocks.ECHO_FARMLAND)));
        blockModelGenerators.family(DDBlocks.SCULK_GLEAM);

        blockModelGenerators.family(DDBlocks.SCULK_STONE_COAL_ORE);
        blockModelGenerators.family(DDBlocks.SCULK_STONE_IRON_ORE);
        blockModelGenerators.family(DDBlocks.SCULK_STONE_COPPER_ORE);
        blockModelGenerators.family(DDBlocks.SCULK_STONE_GOLD_ORE);
        blockModelGenerators.family(DDBlocks.SCULK_STONE_REDSTONE_ORE);
        blockModelGenerators.family(DDBlocks.SCULK_STONE_EMERALD_ORE);
        blockModelGenerators.family(DDBlocks.SCULK_STONE_LAPIS_ORE);
        blockModelGenerators.family(DDBlocks.SCULK_STONE_DIAMOND_ORE);
        blockModelGenerators.family(DDBlocks.SCULK_STONE_LEAD_ORE);
        blockModelGenerators.family(DDBlocks.GLOOMSLATE_COAL_ORE);
        blockModelGenerators.family(DDBlocks.GLOOMSLATE_IRON_ORE);
        blockModelGenerators.family(DDBlocks.GLOOMSLATE_COPPER_ORE);
        blockModelGenerators.family(DDBlocks.GLOOMSLATE_GOLD_ORE);
        blockModelGenerators.family(DDBlocks.GLOOMSLATE_REDSTONE_ORE);
        blockModelGenerators.family(DDBlocks.GLOOMSLATE_EMERALD_ORE);
        blockModelGenerators.family(DDBlocks.GLOOMSLATE_LAPIS_ORE);
        blockModelGenerators.family(DDBlocks.GLOOMSLATE_DIAMOND_ORE);
        blockModelGenerators.family(DDBlocks.RAW_LEAD_BLOCK);
        blockModelGenerators.family(DDBlocks.LEAD_BLOCK);
        blockModelGenerators.createCrossBlock(DDBlocks.SCULK_TENDRILS_PLANT, BlockModelGenerators.TintState.NOT_TINTED);
        blockModelGenerators.createCrossBlock(DDBlocks.SCULK_TENDRILS, BlockModelGenerators.TintState.NOT_TINTED);
        blockModelGenerators.createCrossBlock(DDBlocks.SCULK_VINES_PLANT, BlockModelGenerators.TintState.NOT_TINTED);
        blockModelGenerators.createCrossBlock(DDBlocks.SCULK_VINES, BlockModelGenerators.TintState.NOT_TINTED);

        blockModelGenerators.createCrossBlockWithDefaultItem(DDBlocks.SCULK_FERN, BlockModelGenerators.TintState.NOT_TINTED);
        blockModelGenerators.createDoublePlant(DDBlocks.LARGE_SCULK_FERN, BlockModelGenerators.TintState.NOT_TINTED);

        blockModelGenerators.createCrossBlock(DDBlocks.GLOWING_ROOTS_PLANT, BlockModelGenerators.TintState.NOT_TINTED);
        blockModelGenerators.createCrossBlock(DDBlocks.GLOWING_ROOTS, BlockModelGenerators.TintState.NOT_TINTED);
        blockModelGenerators.createCrossBlock(DDBlocks.GLOWING_VINES, BlockModelGenerators.TintState.NOT_TINTED);

        ModelTemplates.CROSS.create(ModelLocationUtils.getModelLocation(DDBlocks.GLOWING_VINES_PLANT), TextureMapping.cross(TextureMapping.getBlockTexture(DDBlocks.GLOWING_VINES_PLANT)), blockModelGenerators.modelOutput);
        ModelTemplates.CROSS.create(ModelLocationUtils.getModelLocation(DDBlocks.GLOWING_VINES_PLANT, "_berries"), TextureMapping.cross(TextureMapping.getBlockTexture(DDBlocks.GLOWING_VINES_PLANT).withSuffix("_berries")), blockModelGenerators.modelOutput);
        blockModelGenerators.blockStateOutput.accept(
                MultiVariantGenerator.multiVariant(DDBlocks.GLOWING_VINES_PLANT)
                        .with(PropertyDispatch.property(GlowingVinesPlantBlock.BERRIES)
                                .select(false, Variant.variant().with(VariantProperties.MODEL, ModelLocationUtils.getModelLocation(DDBlocks.GLOWING_VINES_PLANT)))
                                .select(true, Variant.variant().with(VariantProperties.MODEL, ModelLocationUtils.getModelLocation(DDBlocks.GLOWING_VINES_PLANT, "_berries")))
                        )
        );

        blockModelGenerators.createNonTemplateModelBlock(DDBlocks.GLOOMY_CACTUS);
        blockModelGenerators.delegateItemModel(DDBlocks.GLOOMY_CACTUS, ModelLocationUtils.getModelLocation(DDBlocks.GLOOMY_CACTUS));
        blockModelGenerators.createCrossBlockWithDefaultItem(DDBlocks.GLOOMY_GRASS, net.minecraft.client.data.models.BlockModelGenerators.TintState.NOT_TINTED);
        blockModelGenerators.family(DDBlocks.GLOOMY_SCULK);
        registerCubeBottomTop(blockModelGenerators, DDBlocks.GLOOMY_GEYSER, DDBlocks.GLOOMY_SCULK);

        blockModelGenerators.createNonTemplateModelBlock(DDBlocks.ANCIENT_VASE);
        blockModelGenerators.delegateItemModel(DDBlocks.ANCIENT_VASE, ModelLocationUtils.getModelLocation(DDBlocks.ANCIENT_VASE));

        blockModelGenerators.createNonTemplateModelBlock(DDBlocks.CRYSTALLIZED_AMBER);
        registerParented(blockModelGenerators, Blocks.HONEY_BLOCK, DDBlocks.CRYSTALLIZED_AMBER,
                new Tuple<>(TextureSlot.UP, ModelLocationUtils.getModelLocation(DDBlocks.CRYSTALLIZED_AMBER, "_inner")),
                new Tuple<>(TextureSlot.SIDE, ModelLocationUtils.getModelLocation(DDBlocks.CRYSTALLIZED_AMBER, "_inner")),
                new Tuple<>(TextureSlot.PARTICLE, ModelLocationUtils.getModelLocation(DDBlocks.CRYSTALLIZED_AMBER, "_inner")),
                new Tuple<>(TextureSlot.DOWN, ModelLocationUtils.getModelLocation(DDBlocks.CRYSTALLIZED_AMBER, "_outer")));

        blockModelGenerators.delegateItemModel(DDBlocks.CRYSTALLIZED_AMBER, ModelLocationUtils.getModelLocation(DDBlocks.CRYSTALLIZED_AMBER));

        blockModelGenerators.copyModel(Blocks.SCULK, DDBlocks.INFESTED_SCULK);
        registerSculkJaw(blockModelGenerators, DDBlocks.SCULK_JAW);
        blockModelGenerators.delegateItemModel(DDBlocks.SCULK_JAW, ModelLocationUtils.getModelLocation(DDBlocks.SCULK_JAW));
        ModelTemplates.FLOWER_POT_CROSS.create(DDBlocks.POTTED_ECHO_SAPLING, TextureMapping.plant(DDBlocks.ECHO_SAPLING), blockModelGenerators.modelOutput);
        blockModelGenerators.createNonTemplateModelBlock(DDBlocks.POTTED_ECHO_SAPLING);
        blockModelGenerators.createNonTemplateModelBlock(DDBlocks.POTTED_BLOOMING_STEM);
        ModelTemplates.FLOWER_POT_CROSS.create(DDBlocks.POTTED_SCULK_SPRUCE_SAPLING, TextureMapping.plant(DDBlocks.SCULK_SPRUCE_SAPLING), blockModelGenerators.modelOutput);
        blockModelGenerators.createNonTemplateModelBlock(DDBlocks.POTTED_SCULK_SPRUCE_SAPLING);

        registerParented(blockModelGenerators, Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "block/flowers"), ModelLocationUtils.getModelLocation(DDBlocks.GLOWING_FLOWERS),
                new Tuple<>(TextureSlot.create("flowers"), TextureMapping.getBlockTexture(DDBlocks.GLOWING_FLOWERS)),
                new Tuple<>(TextureSlot.STEM, TextureMapping.getBlockTexture(DDBlocks.GLOWING_FLOWERS).withSuffix("_stem")));
        blockModelGenerators.blockStateOutput.accept(MultiVariantGenerator.multiVariant(DDBlocks.GLOWING_FLOWERS, Variant.variant().with(VariantProperties.MODEL, ModelLocationUtils.getModelLocation(DDBlocks.GLOWING_FLOWERS))).with(BlockModelGenerators.createHorizontalFacingDispatch()));
        blockModelGenerators.createCrossBlockWithDefaultItem(DDBlocks.GLOWING_GRASS, BlockModelGenerators.TintState.NOT_TINTED);

        registerSculkTubers(DDBlocks.SCULK_TUBERS, blockModelGenerators);
        blockModelGenerators.family(DDBlocks.SCULK_PERMAFROST);
        registerGrassLikeSculkPermafrost(DDBlocks.SNOWY_SCULK_PERMAFROST, blockModelGenerators);
        registerIcicle(DDBlocks.ICICLE, blockModelGenerators);

        registerGrassLikeSculkStone(DDBlocks.BLOOMING_SCULK_STONE, blockModelGenerators);
        blockModelGenerators.family(DDBlocks.BLOOMING_MOSS_BLOCK);
        registerBloomingStem(blockModelGenerators, (BloomingStemBlock) DDBlocks.BLOOMING_STEM);
        registerBloomingStem(blockModelGenerators, (BloomingStemBlock) DDBlocks.STRIPPED_BLOOMING_STEM);

        registerParented(blockModelGenerators, Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "stem_inventory").withPrefix("block/"), ModelLocationUtils.getModelLocation(DDBlocks.BLOOMING_STEM).withSuffix("_inventory"),
                new Tuple<>(TextureSlot.STEM, TextureMapping.getBlockTexture(DDBlocks.BLOOMING_STEM)));
        registerParented(blockModelGenerators, Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "stem_inventory").withPrefix("block/"), ModelLocationUtils.getModelLocation(DDBlocks.STRIPPED_BLOOMING_STEM).withSuffix("_inventory"),
                new Tuple<>(TextureSlot.STEM, TextureMapping.getBlockTexture(DDBlocks.STRIPPED_BLOOMING_STEM)));
        blockModelGenerators.family(DDBlocks.BLOOM_PLANKS);
        registerStairs(blockModelGenerators, DDBlocks.BLOOM_STAIRS, DDBlocks.BLOOM_PLANKS);
        registerSlabWithCubeAll(blockModelGenerators, DDBlocks.BLOOM_SLAB, DDBlocks.BLOOM_PLANKS);
        registerFence(blockModelGenerators, DDBlocks.BLOOM_FENCE, DDBlocks.BLOOM_PLANKS);
        registerFenceGate(blockModelGenerators, DDBlocks.BLOOM_FENCE_GATE, DDBlocks.BLOOM_PLANKS);
        blockModelGenerators.createDoor(DDBlocks.BLOOM_DOOR);
        blockModelGenerators.createOrientableTrapdoor(DDBlocks.BLOOM_TRAPDOOR);
        registerPressurePlate(blockModelGenerators, DDBlocks.BLOOM_PRESSURE_PLATE, DDBlocks.BLOOM_PLANKS);
        registerButton(blockModelGenerators, DDBlocks.BLOOM_BUTTON, DDBlocks.BLOOM_PLANKS);
        blockModelGenerators.createHangingSign(DDBlocks.BLOOM_PLANKS, DDBlocks.BLOOM_SIGN, DDBlocks.BLOOM_WALL_SIGN);
        blockModelGenerators.createHangingSign(DDBlocks.STRIPPED_BLOOMING_STEM, DDBlocks.BLOOM_HANGING_SIGN, DDBlocks.BLOOM_WALL_HANGING_SIGN);
        blockModelGenerators.blockStateOutput.accept(MultiVariantGenerator.multiVariant(DDBlocks.ICE_LILY)
                .with(PropertyDispatch.property(IceLilyBlock.HAS_FLOWER)
                        .select(true, Variant.variant().with(VariantProperties.MODEL, ModelLocationUtils.getModelLocation(DDBlocks.ICE_LILY)))
                        .select(false, Variant.variant().with(VariantProperties.MODEL, ModelLocationUtils.getModelLocation(DDBlocks.ICE_LILY, "_flowerless")))));
        blockModelGenerators.createCrossBlockWithDefaultItem(DDBlocks.LILY_FLOWER, BlockModelGenerators.TintState.NOT_TINTED);
        registerParented(blockModelGenerators, Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "block/ice_waterlily"), ModelLocationUtils.getModelLocation(DDBlocks.ICE_LILY),
                new Tuple<>(TextureSlot.create("flower"), Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "block/lily_flower")),
                new Tuple<>(TextureSlot.TEXTURE, TextureMapping.getBlockTexture(DDBlocks.ICE_LILY)));

        blockModelGenerators.family(DDBlocks.SOUNDPROOF_GLASS);
        blockModelGenerators.family(DDBlocks.PROTECTED_SCULK_GLEAM);
        registerSculkLamp(blockModelGenerators, DDBlocks.SCULK_LAMP);
        blockModelGenerators.blockEntityModels(ModelLocationUtils.decorateBlockModelLocation("skull"), Blocks.SOUL_SAND).createWithCustomBlockItemModel(ModelTemplates.SKULL_INVENTORY, DDBlocks.SHATTERED_HEAD).createWithoutBlockItem(DDBlocks.SHATTERED_WALL_HEAD);

        createRandomRotationBlock(blockModelGenerators, DDBlocks.SCULK_TISSUE);
        createRandomCubeAll(blockModelGenerators, DDBlocks.SCULK_TISSUE_BRICKS, 5);
        createRandomStairs(blockModelGenerators, DDBlocks.SCULK_TISSUE_BRICK_STAIRS, DDBlocks.SCULK_TISSUE_BRICKS, 5);
        createRandomSlabWithCubeAll(blockModelGenerators, DDBlocks.SCULK_TISSUE_BRICK_SLAB, DDBlocks.SCULK_TISSUE_BRICKS, 5);
        createRandomWall(blockModelGenerators, DDBlocks.SCULK_TISSUE_BRICK_WALL, DDBlocks.SCULK_TISSUE_BRICKS, 5);
        registerCubeBottomTop(blockModelGenerators, DDBlocks.DARK_FOUNTAIN, DDBlocks.SCULK_TISSUE);
        blockModelGenerators.family(DDBlocks.SHADOW_CRYSTAL_BLOCK);
        blockModelGenerators.createNonTemplateModelBlock(DDBlocks.TOXIC_AIR, Blocks.AIR);

        blockModelGenerators.family(DDBlocks.SCULK_BASALT);
        blockModelGenerators.createNonTemplateModelBlock(DDBlocks.ACID);
        blockModelGenerators.family(DDBlocks.FIZZ_BLOCK);
        blockModelGenerators.family(DDBlocks.RADIOACTIVE_BLOCK);

        blockModelGenerators.family(DDBlocks.RED_CRYSTAL_BLOCK);
        blockModelGenerators.family(DDBlocks.GREEN_CRYSTAL_BLOCK);
        blockModelGenerators.family(DDBlocks.BLUE_CRYSTAL_BLOCK);

        registerFire(blockModelGenerators, DDBlocks.SCULK_FIRE);
        registerFire(blockModelGenerators, DDBlocks.PATIENCE_SOUL_FIRE);
        registerFire(blockModelGenerators, DDBlocks.FORTITUDE_SOUL_FIRE);
        registerFire(blockModelGenerators, DDBlocks.CORRUPTION_SOUL_FIRE);
        registerFire(blockModelGenerators, DDBlocks.PURITY_SOUL_FIRE);
        registerFire(blockModelGenerators, DDBlocks.VIRTUE_SOUL_FIRE);

        blockModelGenerators.createNormalTorch(DDBlocks.SCULK_TORCH, DDBlocks.SCULK_WALL_TORCH);
        blockModelGenerators.createCampfires(DDBlocks.SCULK_CAMPFIRE);
        blockModelGenerators.createLantern(DDBlocks.SCULK_LANTERN);

        createNonTemplateCropBlock(blockModelGenerators, DDBlocks.SCULK_BERRY, SculkBerryBlock.AGE, 0, 1, 2);

        ModelTemplates.PARTICLE_ONLY.create(DDBlocks.ACID, TextureMapping.particle(Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "block/acid_still")), blockModelGenerators.modelOutput);

        blockModelGenerators.blockEntityModels(ModelLocationUtils.getModelLocation(DDBlocks.DEAD_MANS_CHEST), Blocks.POLISHED_DEEPSLATE).createWithoutBlockItem(DDBlocks.DEAD_MANS_CHEST);

        blockModelGenerators.blockStateOutput.accept(MultiVariantGenerator.multiVariant(DDCreateCompat.Blocks.WARDEN_BACKTANK, Variant.variant().with(VariantProperties.MODEL, ModelLocationUtils.getModelLocation(DDCreateCompat.Blocks.WARDEN_BACKTANK).withSuffix("/block"))).with(BlockModelGenerators.createHorizontalFacingDispatch()));
    }

    @Override
    public void generateItemModels(ItemModelGenerators itemModelGenerator) {
        registerHornedHelmet(itemModelGenerator, (ArmorItem) DDItems.WARDEN_HELMET);
        itemModelGenerator.generateArmorTrims((ArmorItem) DDItems.WARDEN_CHESTPLATE);
        itemModelGenerator.generateArmorTrims((ArmorItem) DDItems.WARDEN_LEGGINGS);
        itemModelGenerator.generateArmorTrims((ArmorItem) DDItems.WARDEN_BOOTS);
        itemModelGenerator.generateFlatItem(DDItems.WARDEN_SWORD, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.WARDEN_PICKAXE, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.WARDEN_AXE, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.WARDEN_SHOVEL, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.WARDEN_HOE, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateArmorTrims((ArmorItem) DDItems.RESONARIUM_HELMET);
        itemModelGenerator.generateArmorTrims((ArmorItem) DDItems.RESONARIUM_CHESTPLATE);
        itemModelGenerator.generateArmorTrims((ArmorItem) DDItems.RESONARIUM_LEGGINGS);
        itemModelGenerator.generateArmorTrims((ArmorItem) DDItems.RESONARIUM_BOOTS);
        itemModelGenerator.generateFlatItem(DDItems.RESONARIUM_SWORD, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.RESONARIUM_PICKAXE, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.RESONARIUM_AXE, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.RESONARIUM_SHOVEL, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.RESONARIUM_HOE, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateArmorTrims((ArmorItem) DDItems.LEAD_HELMET);
        itemModelGenerator.generateArmorTrims((ArmorItem) DDItems.LEAD_CHESTPLATE);
        itemModelGenerator.generateArmorTrims((ArmorItem) DDItems.LEAD_LEGGINGS);
        itemModelGenerator.generateArmorTrims((ArmorItem) DDItems.LEAD_BOOTS);
        itemModelGenerator.generateFlatItem(DDItems.LEAD_SWORD, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.LEAD_PICKAXE, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.LEAD_AXE, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.LEAD_SHOVEL, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.LEAD_HOE, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateArmorTrims((ArmorItem) DDItems.RADIOACTIVE_HELMET);
        itemModelGenerator.generateArmorTrims((ArmorItem) DDItems.RADIOACTIVE_CHESTPLATE);
        itemModelGenerator.generateArmorTrims((ArmorItem) DDItems.RADIOACTIVE_LEGGINGS);
        itemModelGenerator.generateArmorTrims((ArmorItem) DDItems.RADIOACTIVE_BOOTS);
        itemModelGenerator.generateFlatItem(DDItems.RADIOACTIVE_SWORD, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.RADIOACTIVE_PICKAXE, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.RADIOACTIVE_AXE, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.RADIOACTIVE_SHOVEL, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.RADIOACTIVE_HOE, ModelTemplates.FLAT_HANDHELD_ITEM);
        registerHornedHelmet(itemModelGenerator, (ArmorItem) DDItems.GUARDIAN_HELMET);
        itemModelGenerator.generateArmorTrims((ArmorItem) DDItems.GUARDIAN_CHESTPLATE);
        itemModelGenerator.generateArmorTrims((ArmorItem) DDItems.GUARDIAN_LEGGINGS);
        itemModelGenerator.generateArmorTrims((ArmorItem) DDItems.GUARDIAN_BOOTS);
        itemModelGenerator.generateFlatItem(DDItems.GUARDIAN_SWORD, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.GUARDIAN_PICKAXE, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.GUARDIAN_AXE, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.GUARDIAN_SHOVEL, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.GUARDIAN_HOE, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.RESONARIUM, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.RESONARIUM_PLATE, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.RAW_LEAD, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.LEAD_INGOT, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.WARDEN_UPGRADE_SMITHING_TEMPLATE, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.GUARDIAN_UPGRADE_SMITHING_TEMPLATE, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.REINFORCED_ECHO_SHARD, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.PATIENCE_SOUL, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.FORTITUDE_SOUL, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.CORRUPTION_SOUL, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.PURITY_SOUL, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.VIRTUE_SOUL, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.WARDEN_CARAPACE, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.HEART_OF_THE_DEEP, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.SOUL_CRYSTAL, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.SOUL_DUST, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.SCULK_BONE, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.SCULK_BONE_SHARD, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.OTHERSIDE_FIRE_STRIKER, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.GRIME_BALL, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.GRIME_BRICK, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.BLOOM_BERRIES, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.SCULK_TUBER, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.SCULK_BERRY, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.SCULK_TISSUE_BRICK, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.SHADOW_CRYSTAL, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.SUNGLASSES, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.DAINTY_KEY, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.KEYBRAND, ModelTemplates.FLAT_HANDHELD_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.ROYAL_SCEPTER, ModelTemplates.FLAT_HANDHELD_ITEM);
        ModelTemplates.FLAT_ITEM.create(ModelLocationUtils.getModelLocation(DDBlocks.SCULK_TENDRILS.asItem()), TextureMapping.layer0(DDBlocks.SCULK_TENDRILS_PLANT), itemModelGenerator.output);
        ModelTemplates.FLAT_ITEM.create(ModelLocationUtils.getModelLocation(DDBlocks.SCULK_VINES.asItem()), TextureMapping.layer0(DDBlocks.SCULK_VINES_PLANT), itemModelGenerator.output);
        ModelTemplates.FLAT_ITEM.create(ModelLocationUtils.getModelLocation(DDBlocks.GLOWING_ROOTS.asItem()), TextureMapping.layer0(DDBlocks.GLOWING_ROOTS_PLANT), itemModelGenerator.output);
        ModelTemplates.BUTTON_INVENTORY.create(ModelLocationUtils.getModelLocation(DDBlocks.ECHO_BUTTON.asItem()), TextureMapping.cube(DDBlocks.ECHO_PLANKS), itemModelGenerator.output);
        ModelTemplates.FENCE_INVENTORY.create(ModelLocationUtils.getModelLocation(DDBlocks.ECHO_FENCE.asItem()), TextureMapping.cube(DDBlocks.ECHO_PLANKS), itemModelGenerator.output);
        ModelTemplates.BUTTON_INVENTORY.create(ModelLocationUtils.getModelLocation(DDBlocks.SCULK_SPRUCE_BUTTON.asItem()), TextureMapping.cube(DDBlocks.SCULK_SPRUCE_PLANKS), itemModelGenerator.output);
        ModelTemplates.FENCE_INVENTORY.create(ModelLocationUtils.getModelLocation(DDBlocks.SCULK_SPRUCE_FENCE.asItem()), TextureMapping.cube(DDBlocks.SCULK_SPRUCE_PLANKS), itemModelGenerator.output);
        ModelTemplates.WALL_INVENTORY.create(ModelLocationUtils.getModelLocation(DDBlocks.SCULK_STONE_WALL.asItem()), TextureMapping.cube(DDBlocks.SCULK_STONE), itemModelGenerator.output);
        ModelTemplates.WALL_INVENTORY.create(ModelLocationUtils.getModelLocation(DDBlocks.COBBLED_SCULK_STONE_WALL.asItem()), TextureMapping.cube(DDBlocks.COBBLED_SCULK_STONE), itemModelGenerator.output);
        ModelTemplates.WALL_INVENTORY.create(ModelLocationUtils.getModelLocation(DDBlocks.POLISHED_SCULK_STONE_WALL.asItem()), TextureMapping.cube(DDBlocks.POLISHED_SCULK_STONE), itemModelGenerator.output);
        ModelTemplates.WALL_INVENTORY.create(ModelLocationUtils.getModelLocation(DDBlocks.SCULK_STONE_BRICK_WALL.asItem()), TextureMapping.cube(DDBlocks.SCULK_STONE_BRICKS), itemModelGenerator.output);
        ModelTemplates.WALL_INVENTORY.create(ModelLocationUtils.getModelLocation(DDBlocks.SCULK_STONE_TILE_WALL.asItem()), TextureMapping.cube(DDBlocks.SCULK_STONE_TILES), itemModelGenerator.output);
        ModelTemplates.WALL_INVENTORY.create(ModelLocationUtils.getModelLocation(DDBlocks.SMOOTH_SCULK_STONE_WALL.asItem()), TextureMapping.cube(DDBlocks.SMOOTH_SCULK_STONE), itemModelGenerator.output);
        ModelTemplates.WALL_INVENTORY.create(ModelLocationUtils.getModelLocation(DDBlocks.CUT_SCULK_STONE_WALL.asItem()), TextureMapping.cube(DDBlocks.CUT_SCULK_STONE), itemModelGenerator.output);
        ModelTemplates.WALL_INVENTORY.create(ModelLocationUtils.getModelLocation(DDBlocks.SCULK_GRIME_BRICK_WALL.asItem()), TextureMapping.cube(DDBlocks.SCULK_GRIME_BRICKS), itemModelGenerator.output);
        ModelTemplates.WALL_INVENTORY.create(ModelLocationUtils.getModelLocation(DDBlocks.GLOOMSLATE_WALL.asItem()), TextureMapping.cube(DDBlocks.GLOOMSLATE), itemModelGenerator.output);
        ModelTemplates.WALL_INVENTORY.create(ModelLocationUtils.getModelLocation(DDBlocks.COBBLED_GLOOMSLATE_WALL.asItem()), TextureMapping.cube(DDBlocks.COBBLED_GLOOMSLATE), itemModelGenerator.output);
        ModelTemplates.WALL_INVENTORY.create(ModelLocationUtils.getModelLocation(DDBlocks.POLISHED_GLOOMSLATE_WALL.asItem()), TextureMapping.cube(DDBlocks.POLISHED_GLOOMSLATE), itemModelGenerator.output);
        ModelTemplates.WALL_INVENTORY.create(ModelLocationUtils.getModelLocation(DDBlocks.GLOOMSLATE_BRICK_WALL.asItem()), TextureMapping.cube(DDBlocks.GLOOMSLATE_BRICKS), itemModelGenerator.output);
        ModelTemplates.WALL_INVENTORY.create(ModelLocationUtils.getModelLocation(DDBlocks.GLOOMSLATE_TILE_WALL.asItem()), TextureMapping.cube(DDBlocks.GLOOMSLATE_TILES), itemModelGenerator.output);
        ModelTemplates.WALL_INVENTORY.create(ModelLocationUtils.getModelLocation(DDBlocks.SMOOTH_GLOOMSLATE_WALL.asItem()), TextureMapping.cube(DDBlocks.SMOOTH_GLOOMSLATE), itemModelGenerator.output);
        ModelTemplates.WALL_INVENTORY.create(ModelLocationUtils.getModelLocation(DDBlocks.CUT_GLOOMSLATE_WALL.asItem()), TextureMapping.cube(DDBlocks.CUT_GLOOMSLATE), itemModelGenerator.output);
        ModelTemplates.WALL_INVENTORY.create(ModelLocationUtils.getModelLocation(DDBlocks.SCULK_TISSUE_BRICK_WALL.asItem()), TextureMapping.cube(DDBlocks.SCULK_TISSUE_BRICKS), itemModelGenerator.output);
        itemModelGenerator.generateFlatItem(DDItems.ECHO_BOAT, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.ECHO_CHEST_BOAT, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.SCULK_SPRUCE_BOAT, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.SCULK_SPRUCE_CHEST_BOAT, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDBlocks.GLOWING_FLOWERS.asItem(), ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDBlocks.RETURN_STATUE.asItem(), ModelTemplates.FLAT_ITEM);
        registerSculkTransmitter(itemModelGenerator, (SculkTransmitterItem)DDItems.SCULK_TRANSMITTER);
        registerSculkTransmitter(itemModelGenerator, (SculkTransmitterItem)DDItems.WHITE_SCULK_TRANSMITTER);
        registerSculkTransmitter(itemModelGenerator, (SculkTransmitterItem)DDItems.ORANGE_SCULK_TRANSMITTER);
        registerSculkTransmitter(itemModelGenerator, (SculkTransmitterItem)DDItems.MAGENTA_SCULK_TRANSMITTER);
        registerSculkTransmitter(itemModelGenerator, (SculkTransmitterItem)DDItems.LIGHT_BLUE_SCULK_TRANSMITTER);
        registerSculkTransmitter(itemModelGenerator, (SculkTransmitterItem)DDItems.YELLOW_SCULK_TRANSMITTER);
        registerSculkTransmitter(itemModelGenerator, (SculkTransmitterItem)DDItems.LIME_SCULK_TRANSMITTER);
        registerSculkTransmitter(itemModelGenerator, (SculkTransmitterItem)DDItems.PINK_SCULK_TRANSMITTER);
        registerSculkTransmitter(itemModelGenerator, (SculkTransmitterItem)DDItems.GRAY_SCULK_TRANSMITTER);
        registerSculkTransmitter(itemModelGenerator, (SculkTransmitterItem)DDItems.LIGHT_GRAY_SCULK_TRANSMITTER);
        registerSculkTransmitter(itemModelGenerator, (SculkTransmitterItem)DDItems.CYAN_SCULK_TRANSMITTER);
        registerSculkTransmitter(itemModelGenerator, (SculkTransmitterItem)DDItems.PURPLE_SCULK_TRANSMITTER);
        registerSculkTransmitter(itemModelGenerator, (SculkTransmitterItem)DDItems.BLUE_SCULK_TRANSMITTER);
        registerSculkTransmitter(itemModelGenerator, (SculkTransmitterItem)DDItems.BROWN_SCULK_TRANSMITTER);
        registerSculkTransmitter(itemModelGenerator, (SculkTransmitterItem)DDItems.GREEN_SCULK_TRANSMITTER);
        registerSculkTransmitter(itemModelGenerator, (SculkTransmitterItem)DDItems.RED_SCULK_TRANSMITTER);
        registerSculkTransmitter(itemModelGenerator, (SculkTransmitterItem)DDItems.BLACK_SCULK_TRANSMITTER);
        registerSculkTransmitter(itemModelGenerator, (SculkTransmitterItem)DDItems.SUPER_SCULK_TRANSMITTER);
        registerGeneratedWithPredicate(itemModelGenerator, DDItems.SOUL_ELYTRA, List.of(Triple.of(Identifier.DEFAULT_NAMESPACE + ":broken", 1, BuiltInRegistries.ITEM.getKey(DDItems.SOUL_ELYTRA).withSuffix("_broken").withPrefix("item/"))));
        registerGeneratedWithPredicate(itemModelGenerator, DDItems.SONOROUS_STAFF, List.of(
                Triple.of(DeeperDarker.MOD_ID + ":charge", 0.001, BuiltInRegistries.ITEM.getKey(DDItems.SONOROUS_STAFF).withSuffix("_charging").withPrefix("item/")),
                Triple.of(DeeperDarker.MOD_ID + ":charge", 1, BuiltInRegistries.ITEM.getKey(DDItems.SONOROUS_STAFF).withSuffix("_charged").withPrefix("item/"))));
        registerParented(itemModelGenerator, ModelLocationUtils.getModelLocation(DDBlocks.BLOOMING_STEM).withSuffix("_inventory"), ModelLocationUtils.getModelLocation(DDBlocks.BLOOMING_STEM.asItem()));
        registerParented(itemModelGenerator, ModelLocationUtils.getModelLocation(DDBlocks.STRIPPED_BLOOMING_STEM).withSuffix("_inventory"), ModelLocationUtils.getModelLocation(DDBlocks.STRIPPED_BLOOMING_STEM.asItem()));
        ModelTemplates.BUTTON_INVENTORY.create(ModelLocationUtils.getModelLocation(DDBlocks.BLOOM_BUTTON.asItem()), TextureMapping.cube(DDBlocks.BLOOM_PLANKS), itemModelGenerator.output);
        ModelTemplates.FENCE_INVENTORY.create(ModelLocationUtils.getModelLocation(DDBlocks.BLOOM_FENCE.asItem()), TextureMapping.cube(DDBlocks.BLOOM_PLANKS), itemModelGenerator.output);
        itemModelGenerator.generateFlatItem(DDItems.BLOOM_BOAT, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.BLOOM_CHEST_BOAT, ModelTemplates.FLAT_ITEM);
        ModelTemplates.FLAT_ITEM.create(ModelLocationUtils.getModelLocation(DDItems.ICE_LILY), TextureMapping.layer0(DDBlocks.ICE_LILY), itemModelGenerator.output);

        itemModelGenerator.generateFlatItem(DDItems.ACID_BUCKET, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.FIZZ, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.SCULK_DRINK, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.RADIOACTIVE_INGOT, ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDItems.SHIELD_AUGMENT, ModelTemplates.FLAT_ITEM);

        registerSpawnEgg(itemModelGenerator, DDItems.ANGLER_FISH_SPAWN_EGG);
        registerSpawnEgg(itemModelGenerator, DDItems.SCULK_SNAPPER_SPAWN_EGG);
        registerSpawnEgg(itemModelGenerator, DDItems.SHATTERED_SPAWN_EGG);
        registerSpawnEgg(itemModelGenerator, DDItems.SCULK_LEECH_SPAWN_EGG);
        registerSpawnEgg(itemModelGenerator, DDItems.SHRIEK_WORM_SPAWN_EGG);
        registerSpawnEgg(itemModelGenerator, DDItems.STALKER_SPAWN_EGG);
        registerSpawnEgg(itemModelGenerator, DDItems.SLUDGE_SPAWN_EGG);
        registerSpawnEgg(itemModelGenerator, DDItems.SCULK_CENTIPEDE_SPAWN_EGG);
        registerSpawnEgg(itemModelGenerator, DDItems.POTTY_SPAWN_EGG);
        registerSpawnEgg(itemModelGenerator, DDItems.POT_SPAWN_EGG);
        registerSpawnEgg(itemModelGenerator, DDItems.POTTER_SPAWN_EGG);
        registerSpawnEgg(itemModelGenerator, DDItems.ACID_SPRITE_SPAWN_EGG);

        registerParented(itemModelGenerator, ModelLocationUtils.getModelLocation(Items.CHEST), ModelLocationUtils.getModelLocation(DDBlocks.DEAD_MANS_CHEST.asItem()), new Tuple<>(
                TextureSlot.PARTICLE, TextureMapping.getBlockTexture(Blocks.POLISHED_DEEPSLATE)
        ));

        // Create
        itemModelGenerator.generateFlatItem(DDCreateCompat.Items.WARDEN_DIVING_HELMET.get(), ModelTemplates.FLAT_ITEM);
        itemModelGenerator.generateFlatItem(DDCreateCompat.Items.WARDEN_DIVING_BOOTS.get(), ModelTemplates.FLAT_ITEM);
        registerParented(itemModelGenerator, Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "block/warden_backtank/item"), ModelLocationUtils.getModelLocation(DDCreateCompat.Items.WARDEN_BACKTANK.get()));
        registerParented(itemModelGenerator, ModelLocationUtils.getModelLocation(Items.BARRIER), ModelLocationUtils.getModelLocation(DDCreateCompat.Items.WARDEN_BACKTANK_PLACEABLE.get()));
    }

    private static void createGildedLog(BlockModelGenerators blockModelGenerators, Block gildedLog, Block normalLog) {
        Identifier resourceLocation = ModelTemplates.CUBE_COLUMN.create(gildedLog, TextureMapping.column(TextureMapping.getBlockTexture(gildedLog), TextureMapping.getBlockTexture(normalLog).withSuffix("_top")), blockModelGenerators.modelOutput);
        blockModelGenerators.blockStateOutput.accept(BlockModelGenerators.createAxisAlignedPillarBlock(gildedLog, resourceLocation));
    }

    private static void registerButton(BlockModelGenerators blockModelGenerators, Block block, Block planks) {
        Identifier buttonModel = ModelTemplates.BUTTON.create(block, TexturedModel.CUBE.get(planks).getMapping(),
                blockModelGenerators.modelOutput);
        Identifier buttonPressedModel = ModelTemplates.BUTTON_PRESSED.create(block, TexturedModel.CUBE.get(planks).getMapping(),
                blockModelGenerators.modelOutput);

        blockModelGenerators.blockStateOutput.accept(BlockModelGenerators.createButton(block, buttonModel, buttonPressedModel));
    }

    private static void registerFenceGate(BlockModelGenerators blockModelGenerators, Block block, Block textureSource) {
        TextureMapping textureMap = TextureMapping.defaultTexture(textureSource);
        Identifier fenceGateOpenModel = ModelTemplates.FENCE_GATE_OPEN.create(block, textureMap,
                blockModelGenerators.modelOutput);
        Identifier fenceGateModel = ModelTemplates.FENCE_GATE_CLOSED.create(block, textureMap,
                blockModelGenerators.modelOutput);
        Identifier wallFenceGateOpenModel = ModelTemplates.FENCE_GATE_WALL_OPEN.create(block, textureMap,
                blockModelGenerators.modelOutput);
        Identifier wallFenceGateModel = ModelTemplates.FENCE_GATE_WALL_CLOSED.create(block, textureMap,
                blockModelGenerators.modelOutput);
        blockModelGenerators.blockStateOutput.accept(BlockModelGenerators.createFenceGate(block, fenceGateOpenModel, fenceGateModel, wallFenceGateOpenModel, wallFenceGateModel, true));
    }

    private static void registerFence(BlockModelGenerators blockModelGenerators, Block block, Block textureSource) {
        TextureMapping textureMap = TextureMapping.defaultTexture(textureSource);
        Identifier fencePost = ModelTemplates.FENCE_POST.create(block, textureMap, blockModelGenerators.modelOutput);
        Identifier fenceSide = ModelTemplates.FENCE_SIDE.create(block, textureMap, blockModelGenerators.modelOutput);
        blockModelGenerators.blockStateOutput.accept(BlockModelGenerators.createFence(block, fencePost, fenceSide));
    }

    private static void registerPressurePlate(BlockModelGenerators blockModelGenerators, Block pressurePlate, Block textureSource) {
        TextureMapping textureMap = TextureMapping.defaultTexture(textureSource);
        Identifier upModel = ModelTemplates.PRESSURE_PLATE_UP.create(pressurePlate, textureMap, blockModelGenerators.modelOutput);
        Identifier downModel = ModelTemplates.PRESSURE_PLATE_DOWN.create(pressurePlate, textureMap, blockModelGenerators.modelOutput);
        blockModelGenerators.blockStateOutput.accept(BlockModelGenerators.createPressurePlate(pressurePlate, upModel, downModel));
    }

    private static void registerSlabWithCubeAll(BlockModelGenerators blockModelGenerators, Block slab, Block textureSource) {
        Identifier Identifier = ModelLocationUtils.getModelLocation(textureSource);
        TexturedModel texturedModel = TexturedModel.CUBE.get(textureSource);
        Identifier ResourceLocation2 = ModelTemplates.SLAB_BOTTOM.create(slab, texturedModel.getMapping(), blockModelGenerators.modelOutput);
        Identifier ResourceLocation3 = ModelTemplates.SLAB_TOP.create(slab, texturedModel.getMapping(), blockModelGenerators.modelOutput);
        blockModelGenerators.blockStateOutput.accept(BlockModelGenerators.createSlab(slab, ResourceLocation2, ResourceLocation3, Identifier));
    }

    private static void registerStairs(BlockModelGenerators blockModelGenerators, Block stairs, Block textureSource) {
        TexturedModel texturedModel = TexturedModel.CUBE.get(textureSource);
        TextureMapping textureMap = texturedModel.getMapping();
        Identifier innerModel = ModelTemplates.STAIRS_INNER.create(stairs, textureMap, blockModelGenerators.modelOutput);
        Identifier regularModel = ModelTemplates.STAIRS_STRAIGHT.create(stairs, textureMap, blockModelGenerators.modelOutput);
        Identifier outerModel = ModelTemplates.STAIRS_OUTER.create(stairs, textureMap, blockModelGenerators.modelOutput);
        blockModelGenerators.blockStateOutput.accept(BlockModelGenerators.createStairs(stairs, innerModel, regularModel, outerModel));
    }

    private static void registerWall(BlockModelGenerators blockModelGenerators, Block wall, Block textureSource) {
        TexturedModel texturedModel = TexturedModel.CUBE.get(textureSource);
        TextureMapping textureMap = texturedModel.getMapping();
        Identifier postModel = ModelTemplates.WALL_POST.create(wall, textureMap, blockModelGenerators.modelOutput);
        Identifier sideModel = ModelTemplates.WALL_LOW_SIDE.create(wall, textureMap, blockModelGenerators.modelOutput);
        Identifier sideTallModel = ModelTemplates.WALL_TALL_SIDE.create(wall, textureMap, blockModelGenerators.modelOutput);
        blockModelGenerators.blockStateOutput.accept(BlockModelGenerators.createWall(wall, postModel, sideModel, sideTallModel));
    }

    private static void registerSculkJaw(BlockModelGenerators blockModelGenerators, Block sculkJaw) {
        Identifier sculkJawModel = ModelTemplates.CUBE_TOP.create(sculkJaw, TextureMapping.singleSlot(TextureSlot.TOP, TextureMapping.getBlockTexture(sculkJaw)).put(TextureSlot.SIDE, TextureMapping.getBlockTexture(sculkJaw, "_side")), blockModelGenerators.modelOutput);
        Identifier sculkJawBitingModel = ModelTemplates.CUBE_TOP.create(ModelLocationUtils.getModelLocation(sculkJaw, "_biting"), TextureMapping.singleSlot(TextureSlot.TOP, TextureMapping.getBlockTexture(sculkJaw, "_biting")).put(TextureSlot.SIDE, TextureMapping.getBlockTexture(sculkJaw, "_side")), blockModelGenerators.modelOutput);

        blockModelGenerators.blockStateOutput.accept(MultiVariantGenerator.multiVariant(DDBlocks.SCULK_JAW).with(BlockModelGenerators.createBooleanModelDispatch(
                SculkJawBlock.BITING, sculkJawBitingModel, sculkJawModel)));
    }

    private static void registerSculkLamp(BlockModelGenerators blockModelGenerators, Block lamp) {
        blockModelGenerators.blockStateOutput.accept(MultiVariantGenerator.multiVariant(lamp)
                .with(PropertyDispatch.property(BlockStateProperties.LIT)
                        .select(true, Variant.variant().with(VariantProperties.MODEL, ModelLocationUtils.getModelLocation(lamp)))
                        .select(false, Variant.variant().with(VariantProperties.MODEL, ModelLocationUtils.getModelLocation(lamp, "_off")))));
        ModelTemplates.CUBE_ALL.create(lamp, TextureMapping.cube(lamp), blockModelGenerators.modelOutput);
        ModelTemplates.CUBE_ALL.createWithSuffix(lamp, "_off", TextureMapping.cube(TextureMapping.getBlockTexture(lamp, "_off")), blockModelGenerators.modelOutput);
    }

    private void registerFire(BlockModelGenerators blockModelGenerators, Block block) {
        List<Identifier> list = blockModelGenerators.createFloorFireModels(block);
        List<Identifier> list2 = blockModelGenerators.createSideFireModels(block);
        blockModelGenerators.blockStateOutput.accept(MultiPartGenerator.multiPart(block).with(BlockModelGenerators.wrapModels(list, variant -> variant)).with(BlockModelGenerators.wrapModels(list2, variant -> variant)).with(BlockModelGenerators.wrapModels(list2, variant -> variant.with(VariantProperties.Y_ROT, VariantProperties.Rotation.R90))).with(BlockModelGenerators.wrapModels(list2, variant -> variant.with(VariantProperties.Y_ROT, VariantProperties.Rotation.R180))).with(BlockModelGenerators.wrapModels(list2, variant -> variant.with(VariantProperties.Y_ROT, VariantProperties.Rotation.R270))));
    }

    private static void registerGeneratedWithPredicate(ItemModelGenerators itemModelGenerator, Item item, List<Triple<String, Number, Identifier>> predicates) {
        JsonObject withoutPredicateJsonObject = ModelTemplates.FLAT_ITEM.createBaseTemplate(BuiltInRegistries.ITEM.getKey(item).withPrefix("item/"),
                Map.of(TextureSlot.LAYER0, BuiltInRegistries.ITEM.getKey(item).withPrefix("item/")));
        JsonArray overrides = new JsonArray();
        for (Triple<String, Number, Identifier> predicateTriple : predicates) {
            ModelTemplates.FLAT_ITEM.create(predicateTriple.getRight(), TextureMapping.layer0(predicateTriple.getRight()), itemModelGenerator.output);
            JsonObject predicateJson = new JsonObject();
            JsonObject override = new JsonObject();
            predicateJson.addProperty(predicateTriple.getLeft(), predicateTriple.getMiddle());
            override.add("predicate", predicateJson);
            override.addProperty("model", predicateTriple.getRight().toString());
            overrides.add(override);
        }
        withoutPredicateJsonObject.add("overrides", overrides);
        itemModelGenerator.output.accept(BuiltInRegistries.ITEM.getKey(item).withPrefix("item/"), () -> withoutPredicateJsonObject);
    }

    private static void registerSculkTransmitter(ItemModelGenerators itemModelGenerator, SculkTransmitterItem item) {
        registerGeneratedWithPredicate(itemModelGenerator, item, List.of(Triple.of(DeeperDarker.MOD_ID + ":linked", 1, BuiltInRegistries.ITEM.getKey(item).withSuffix("_linked").withPrefix("item/"))));
    }

    private static void registerSpawnEgg(ItemModelGenerators itemModelGenerator, Item item) {
        JsonObject model = new JsonObject();
        model.addProperty("parent", Identifier.parse("template_spawn_egg").withPrefix("item/").toString());
        itemModelGenerator.output.accept(BuiltInRegistries.ITEM.getKey(item).withPrefix("item/"), () -> model);
    }

    private static void registerHornedHelmet(ItemModelGenerators itemModelGenerators, ArmorItem armor) {
        Identifier armorModelIdentifier = ModelLocationUtils.getModelLocation(armor);
        Identifier armorTextureIdentifier = TextureMapping.getItemTexture(armor);
        ModelTemplates.FLAT_ITEM.create(armorModelIdentifier, TextureMapping.layer0(armorTextureIdentifier), itemModelGenerators.output, (id, textures) -> generateBaseHornedHelmetTrimTemplate(id, textures, armor.getMaterial()));
        for (int hasHorns = 0; hasHorns <= 1; hasHorns++) {
            String suffix = hasHorns == 1 ? "" : "_no_horns";
            for (ItemModelGenerators.TrimModelData trimMaterial : ItemModelGeneratorsAccessor.deeperdarker$getGENERATED_TRIM_MODELS()) {
                String string = trimMaterial.name(armor.getMaterial());
                Identifier identifier4 = getItemModelForTrimMaterial(armorModelIdentifier, string, suffix);
                String string2 = hasHorns == 1 ? BuiltInRegistries.ITEM.getKey(armor).getPath() + suffix + "_trim_" + string : armor.getType().getName() + "_trim_" + string;
                Identifier trimOverlayIdentifier = hasHorns == 1 ? Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, string2).withPrefix("trims/items/") : Identifier.parse(string2).withPrefix("trims/items/");
                itemModelGenerators.generateLayeredItem(identifier4, armorTextureIdentifier.withSuffix(suffix), trimOverlayIdentifier);
            }
        }
    }

    private static JsonObject generateBaseHornedHelmetTrimTemplate(Identifier model, Map<TextureSlot, Identifier> map, ArmorMaterial armorMaterial) {
        JsonObject jsonObject = ModelTemplates.TWO_LAYERED_ITEM.createBaseTemplate(model, map);
        JsonArray jsonArray = new JsonArray();
        for (ItemModelGenerators.TrimModelData trimModelData : ItemModelGeneratorsAccessor.deeperdarker$getGENERATED_TRIM_MODELS()) {
            for (int hasHorns = 0; hasHorns <= 1; hasHorns++) {
                JsonObject jsonObject2 = new JsonObject();
                JsonObject jsonObject3 = new JsonObject();
                jsonObject3.addProperty(ItemModelGenerators.TRIM_TYPE_PREDICATE_ID.getPath(), Float.valueOf(trimModelData.itemModelIndex()));
                jsonObject3.addProperty(Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "has_horns").toString(), hasHorns);
                jsonObject2.add("predicate", jsonObject3);
                jsonObject2.addProperty("model", getItemModelForTrimMaterial(model, trimModelData.name(armorMaterial), (hasHorns == 1 ? "" : "_no_horns")).toString());
                jsonArray.add(jsonObject2);
            }
        }
        jsonObject.add("overrides", jsonArray);
        return jsonObject;
    }

    private static Identifier getItemModelForTrimMaterial(Identifier id, String material, String suffix) {
        return id.withSuffix(suffix + "_" + material + "_trim");
    }

    @SafeVarargs
    private static void registerParented(BlockModelGenerators blockModelGenerators, Block parent, Block child, Tuple<TextureSlot, Identifier> ... textures) {
        List<TextureSlot> textureKeys = new ArrayList<>();
        TextureMapping textureMap = new TextureMapping();
        for (Tuple<TextureSlot, Identifier> pair : textures) {
            textureKeys.add(pair.getA());
            textureMap.put(pair.getA(), pair.getB());
        }
        ModelTemplate parentModel = new ModelTemplate(Optional.of(ModelLocationUtils.getModelLocation(parent)), Optional.empty(), textureKeys.toArray(new TextureSlot[0]));

        parentModel.create(child, textureMap, blockModelGenerators.modelOutput);
    }

    @SafeVarargs
    private static void registerParented(BlockModelGenerators blockModelGenerators, Identifier parent, Identifier child, Tuple<TextureSlot, Identifier> ... textures) {
        List<TextureSlot> textureKeys = new ArrayList<>();
        TextureMapping textureMap = new TextureMapping();
        for (Tuple<TextureSlot, Identifier> pair : textures) {
            textureKeys.add(pair.getA());
            textureMap.put(pair.getA(), pair.getB());
        }
        ModelTemplate parentModel = new ModelTemplate(Optional.of(parent), Optional.empty(), textureKeys.toArray(new TextureSlot[0]));

        parentModel.create(child, textureMap, blockModelGenerators.modelOutput);
    }

    @SafeVarargs
    private static void registerParented(ItemModelGenerators itemModelGenerators, Identifier parent, Identifier child, Tuple<TextureSlot, Identifier> ... textures) {
        List<TextureSlot> textureKeys = new ArrayList<>();
        TextureMapping textureMap = new TextureMapping();
        for (Tuple<TextureSlot, Identifier> pair : textures) {
            textureKeys.add(pair.getA());
            textureMap.put(pair.getA(), pair.getB());
        }
        ModelTemplate parentModel = new ModelTemplate(Optional.of(parent), Optional.empty(), textureKeys.toArray(new TextureSlot[0]));

        parentModel.create(child, textureMap, itemModelGenerators.output);
    }

    private void registerGrassLikeSculkStone(Block block, BlockModelGenerators blockModelGenerators) {
        TextureMapping textureMapping = new TextureMapping().put(TextureSlot.BOTTOM, TextureMapping.getBlockTexture(DDBlocks.SCULK_STONE)).put(TextureSlot.TOP, TextureMapping.getBlockTexture(block, "_top")).put(TextureSlot.SIDE, TextureMapping.getBlockTexture(block));
        blockModelGenerators.blockStateOutput.accept(BlockModelGenerators.createSimpleBlock(block, ModelTemplates.CUBE_BOTTOM_TOP.create(block, textureMapping, blockModelGenerators.modelOutput)));
    }

    private void registerGrassLikeSculkPermafrost(Block block, BlockModelGenerators blockModelGenerators) {
        TextureMapping textureMapping = new TextureMapping().put(TextureSlot.BOTTOM, TextureMapping.getBlockTexture(DDBlocks.SCULK_PERMAFROST)).put(TextureSlot.TOP, TextureMapping.getBlockTexture(block, "_top")).put(TextureSlot.SIDE, TextureMapping.getBlockTexture(block));
        blockModelGenerators.blockStateOutput.accept(BlockModelGenerators.createSimpleBlock(block, ModelTemplates.CUBE_BOTTOM_TOP.create(block, textureMapping, blockModelGenerators.modelOutput)));
    }

    private void registerSculkTubers(Block block, BlockModelGenerators blockModelGenerators) {
        PropertyDispatch propertyDispatch = PropertyDispatch.property(BlockStateProperties.SNOWY).generate(isSnowy -> {
            String suffix = isSnowy ? "_snowy" : "";
            TextureMapping textureMapping = TextureMapping.cross(TextureMapping.getBlockTexture(block, suffix));
            Identifier resourceLocation = BlockModelGenerators.TintState.NOT_TINTED.getCross().createWithSuffix(block, suffix, textureMapping, blockModelGenerators.modelOutput);
            return Variant.variant().with(VariantProperties.MODEL, resourceLocation);
        });
        blockModelGenerators.blockStateOutput.accept(MultiVariantGenerator.multiVariant(block).with(propertyDispatch));
    }

    private void registerIcicle(Block block, BlockModelGenerators blockModelGenerators) {
        blockModelGenerators.skipAutoItemBlock(block);
        PropertyDispatch.C2<Direction, SpeleothemThickness> c2 = PropertyDispatch.properties(BlockStateProperties.VERTICAL_DIRECTION, BlockStateProperties.DRIPSTONE_THICKNESS);
        for (SpeleothemThickness dripstoneThickness : SpeleothemThickness.values()) {
            c2.select(Direction.UP, dripstoneThickness, createPointedDripstoneVariant(block, blockModelGenerators, Direction.UP, dripstoneThickness));
        }
        for (SpeleothemThickness dripstoneThickness : SpeleothemThickness.values()) {
            c2.select(Direction.DOWN, dripstoneThickness, createPointedDripstoneVariant(block, blockModelGenerators, Direction.DOWN, dripstoneThickness));
        }
        blockModelGenerators.blockStateOutput.accept(MultiVariantGenerator.multiVariant(block).with(c2));
    }

    public final Variant createPointedDripstoneVariant(Block block, BlockModelGenerators blockModelGenerators, Direction direction, SpeleothemThickness dripstoneThickness) {
        String string = "_" + direction.getSerializedName() + "_" + dripstoneThickness.getSerializedName();
        TextureMapping textureMapping = TextureMapping.cross(TextureMapping.getBlockTexture(block, string));
        return Variant.variant().with(VariantProperties.MODEL, ModelTemplates.POINTED_DRIPSTONE.createWithSuffix(block, string, textureMapping, blockModelGenerators.modelOutput));
    }

    private void registerBloomingStem(BlockModelGenerators blockModelGenerators, BloomingStemBlock block) {
        Identifier stemModel = Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "block/stem");
        Identifier stemHorizontalModel = Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "block/stem_horizontal");
        Identifier stemVerticalModel = Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "block/stem_vertical");

        Identifier bloomingStemModel = ModelLocationUtils.getModelLocation(block);
        Identifier bloomingStemHorizontalModel = ModelLocationUtils.getModelLocation(block).withSuffix("_horizontal");
        Identifier bloomingStemVerticalModel = ModelLocationUtils.getModelLocation(block).withSuffix("_vertical");

        registerParented(blockModelGenerators, stemModel, bloomingStemModel,
                new Tuple<>(TextureSlot.STEM, TextureMapping.getBlockTexture(block)));
        registerParented(blockModelGenerators, stemHorizontalModel, bloomingStemHorizontalModel,
                new Tuple<>(TextureSlot.STEM, TextureMapping.getBlockTexture(block)));
        registerParented(blockModelGenerators, stemVerticalModel, bloomingStemVerticalModel,
                new Tuple<>(TextureSlot.STEM, TextureMapping.getBlockTexture(block)));
        MultiPartGenerator builder = MultiPartGenerator.multiPart(block)
                .with(Variant.variant().with(VariantProperties.MODEL, bloomingStemModel))
                .with(Condition.condition().term(BloomingStemBlock.DOWN, true), Variant.variant().with(VariantProperties.MODEL, bloomingStemVerticalModel)
                        .with(VariantProperties.UV_LOCK, true)
                        .with(VariantProperties.X_ROT, VariantProperties.Rotation.R180))
                .with(Condition.condition().term(BloomingStemBlock.UP, true), Variant.variant().with(VariantProperties.MODEL, bloomingStemVerticalModel)
                        .with(VariantProperties.UV_LOCK, true))
                .with(Condition.condition().term(BloomingStemBlock.NORTH, true), Variant.variant().with(VariantProperties.MODEL, bloomingStemHorizontalModel)
                        .with(VariantProperties.UV_LOCK, true)
                        .with(VariantProperties.Y_ROT, VariantProperties.Rotation.R90))
                .with(Condition.condition().term(BloomingStemBlock.SOUTH, true), Variant.variant().with(VariantProperties.MODEL, bloomingStemHorizontalModel)
                        .with(VariantProperties.UV_LOCK, true)
                        .with(VariantProperties.Y_ROT, VariantProperties.Rotation.R270))
                .with(Condition.condition().term(BloomingStemBlock.WEST, true), Variant.variant().with(VariantProperties.MODEL, bloomingStemHorizontalModel)
                        .with(VariantProperties.UV_LOCK, true))
                .with(Condition.condition().term(BloomingStemBlock.EAST, true), Variant.variant().with(VariantProperties.MODEL, bloomingStemHorizontalModel)
                        .with(VariantProperties.UV_LOCK, true)
                        .with(VariantProperties.Y_ROT, VariantProperties.Rotation.R180));
        blockModelGenerators.blockStateOutput.accept(builder);
    }

    private void createRandomRotationBlock(BlockModelGenerators blockModelGenerators, Block block) {
        Identifier resourceLocation = TexturedModel.CUBE.create(block, blockModelGenerators.modelOutput);
        blockModelGenerators.blockStateOutput.accept(MultiVariantGenerator.multiVariant(block, Variant.variant().with(VariantProperties.MODEL, resourceLocation), Variant.variant().with(VariantProperties.MODEL, resourceLocation).with(VariantProperties.X_ROT, VariantProperties.Rotation.R90), Variant.variant().with(VariantProperties.MODEL, resourceLocation).with(VariantProperties.X_ROT, VariantProperties.Rotation.R180), Variant.variant().with(VariantProperties.MODEL, resourceLocation).with(VariantProperties.X_ROT, VariantProperties.Rotation.R270), Variant.variant().with(VariantProperties.MODEL, resourceLocation).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R90), Variant.variant().with(VariantProperties.MODEL, resourceLocation).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R90).with(VariantProperties.X_ROT, VariantProperties.Rotation.R90), Variant.variant().with(VariantProperties.MODEL, resourceLocation).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R90).with(VariantProperties.X_ROT, VariantProperties.Rotation.R180), Variant.variant().with(VariantProperties.MODEL, resourceLocation).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R90).with(VariantProperties.X_ROT, VariantProperties.Rotation.R270), Variant.variant().with(VariantProperties.MODEL, resourceLocation).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R180), Variant.variant().with(VariantProperties.MODEL, resourceLocation).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R180).with(VariantProperties.X_ROT, VariantProperties.Rotation.R90), Variant.variant().with(VariantProperties.MODEL, resourceLocation).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R180).with(VariantProperties.X_ROT, VariantProperties.Rotation.R180), Variant.variant().with(VariantProperties.MODEL, resourceLocation).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R180).with(VariantProperties.X_ROT, VariantProperties.Rotation.R270), Variant.variant().with(VariantProperties.MODEL, resourceLocation).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R270), Variant.variant().with(VariantProperties.MODEL, resourceLocation).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R270).with(VariantProperties.X_ROT, VariantProperties.Rotation.R90), Variant.variant().with(VariantProperties.MODEL, resourceLocation).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R270).with(VariantProperties.X_ROT, VariantProperties.Rotation.R180), Variant.variant().with(VariantProperties.MODEL, resourceLocation).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R270).with(VariantProperties.X_ROT, VariantProperties.Rotation.R270)));
    }

    private void registerCubeBottomTop(BlockModelGenerators blockModelGenerators, Block block, Block side) {
        registerCubeBottomTop(blockModelGenerators, block, TextureMapping.getBlockTexture(side), TextureMapping.getBlockTexture(block));
    }

    private void registerCubeBottomTop(BlockModelGenerators blockModelGenerators, Block block, Identifier side, Identifier top) {
        blockModelGenerators.createNonTemplateModelBlock(block);
        ModelTemplates.CUBE_BOTTOM_TOP.create(block, TextureMapping.singleSlot(TextureSlot.TOP, top).put(TextureSlot.SIDE, side).put(TextureSlot.BOTTOM, top),
                blockModelGenerators.modelOutput);
    }

    private void createNonTemplateCropBlock(BlockModelGenerators blockModelGenerators, Block block, Property<Integer> property, int ... is) {
        if (property.getPossibleValues().size() != is.length) {
            throw new IllegalArgumentException();
        }
        PropertyDispatch propertyDispatch = PropertyDispatch.property(property).generate(integer -> {
            int i = is[integer];
            Identifier resourceLocation = ModelLocationUtils.getModelLocation(block, "_stage" + i);
            return Variant.variant().with(VariantProperties.MODEL, resourceLocation);
        });
        blockModelGenerators.createSimpleFlatItemModel(block.asItem());
        blockModelGenerators.blockStateOutput.accept(MultiVariantGenerator.multiVariant(block).with(propertyDispatch));
    }

    private void createRandomCubeAll(BlockModelGenerators blockModelGenerators, Block block, int amount) {
        Variant[] variants = new Variant[amount];
        for (int i = 0; i < amount; i++) {
            Identifier model = ModelLocationUtils.getModelLocation(block, i == 0 ? "" : "_" + (i + 1));
            variants[i] = Variant.variant().with(VariantProperties.MODEL, model);
            Identifier texture = TextureMapping.getBlockTexture(block, i == 0 ? "" : "_" + (i + 1));
            ModelTemplates.CUBE_ALL.create(model, TextureMapping.cube(texture), blockModelGenerators.modelOutput);
        }
        blockModelGenerators.blockStateOutput.accept(MultiVariantGenerator.multiVariant(block, variants));
    }

    private void createRandomStairs(BlockModelGenerators blockModelGenerators, Block block, Block base, int amount) {
        List<Identifier> variantsInner = new ArrayList<>();
        List<Identifier> variantsStraight = new ArrayList<>();
        List<Identifier> variantsOuter = new ArrayList<>();
        for (int i = 0; i < amount; i++) {
            Identifier model = ModelLocationUtils.getModelLocation(block, i == 0 ? "" : "_" + (i + 1));
            Identifier texture = TextureMapping.getBlockTexture(base, i == 0 ? "" : "_" + (i + 1));

            Identifier innerModel = ModelTemplates.STAIRS_INNER.create(model.withSuffix("_inner"), TextureMapping.cube(texture), blockModelGenerators.modelOutput);
            Identifier straightModel = ModelTemplates.STAIRS_STRAIGHT.create(model, TextureMapping.cube(texture), blockModelGenerators.modelOutput);
            Identifier outerModel = ModelTemplates.STAIRS_OUTER.create(model.withSuffix("_outer"), TextureMapping.cube(texture), blockModelGenerators.modelOutput);
            variantsInner.add(innerModel);
            variantsStraight.add(straightModel);
            variantsOuter.add(outerModel);
        }

        blockModelGenerators.blockStateOutput.accept(MultiVariantGenerator.multiVariant(block).with(PropertyDispatch.properties(BlockStateProperties.HORIZONTAL_FACING, BlockStateProperties.HALF, BlockStateProperties.STAIRS_SHAPE)
                .select(Direction.EAST, Half.BOTTOM, StairsShape.STRAIGHT, variantsStraight.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model)).toList())
                .select(Direction.WEST, Half.BOTTOM, StairsShape.STRAIGHT, variantsStraight.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R180).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.SOUTH, Half.BOTTOM, StairsShape.STRAIGHT, variantsStraight.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R90).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.NORTH, Half.BOTTOM, StairsShape.STRAIGHT, variantsStraight.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R270).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.EAST, Half.BOTTOM, StairsShape.OUTER_RIGHT, variantsOuter.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model)).toList())
                .select(Direction.WEST, Half.BOTTOM, StairsShape.OUTER_RIGHT, variantsOuter.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R180).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.SOUTH, Half.BOTTOM, StairsShape.OUTER_RIGHT, variantsOuter.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R90).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.NORTH, Half.BOTTOM, StairsShape.OUTER_RIGHT, variantsOuter.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R270).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.EAST, Half.BOTTOM, StairsShape.OUTER_LEFT, variantsOuter.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R270).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.WEST, Half.BOTTOM, StairsShape.OUTER_LEFT, variantsOuter.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R90).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.SOUTH, Half.BOTTOM, StairsShape.OUTER_LEFT, variantsOuter.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model)).toList())
                .select(Direction.NORTH, Half.BOTTOM, StairsShape.OUTER_LEFT, variantsOuter.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R180).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.EAST, Half.BOTTOM, StairsShape.INNER_RIGHT, variantsInner.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model)).toList())
                .select(Direction.WEST, Half.BOTTOM, StairsShape.INNER_RIGHT, variantsInner.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R180).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.SOUTH, Half.BOTTOM, StairsShape.INNER_RIGHT, variantsInner.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R90).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.NORTH, Half.BOTTOM, StairsShape.INNER_RIGHT, variantsInner.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R270).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.EAST, Half.BOTTOM, StairsShape.INNER_LEFT, variantsInner.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R270).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.WEST, Half.BOTTOM, StairsShape.INNER_LEFT, variantsInner.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R90).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.SOUTH, Half.BOTTOM, StairsShape.INNER_LEFT, variantsInner.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model)).toList())
                .select(Direction.NORTH, Half.BOTTOM, StairsShape.INNER_LEFT, variantsInner.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R180).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.EAST, Half.TOP, StairsShape.STRAIGHT, variantsStraight.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.X_ROT, VariantProperties.Rotation.R180).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.WEST, Half.TOP, StairsShape.STRAIGHT, variantsStraight.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.X_ROT, VariantProperties.Rotation.R180).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R180).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.SOUTH, Half.TOP, StairsShape.STRAIGHT, variantsStraight.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.X_ROT, VariantProperties.Rotation.R180).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R90).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.NORTH, Half.TOP, StairsShape.STRAIGHT, variantsStraight.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.X_ROT, VariantProperties.Rotation.R180).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R270).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.EAST, Half.TOP, StairsShape.OUTER_RIGHT, variantsOuter.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.X_ROT, VariantProperties.Rotation.R180).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R90).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.WEST, Half.TOP, StairsShape.OUTER_RIGHT, variantsOuter.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.X_ROT, VariantProperties.Rotation.R180).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R270).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.SOUTH, Half.TOP, StairsShape.OUTER_RIGHT, variantsOuter.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.X_ROT, VariantProperties.Rotation.R180).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R180).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.NORTH, Half.TOP, StairsShape.OUTER_RIGHT, variantsOuter.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.X_ROT, VariantProperties.Rotation.R180).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.EAST, Half.TOP, StairsShape.OUTER_LEFT, variantsOuter.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.X_ROT, VariantProperties.Rotation.R180).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.WEST, Half.TOP, StairsShape.OUTER_LEFT, variantsOuter.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.X_ROT, VariantProperties.Rotation.R180).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R180).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.SOUTH, Half.TOP, StairsShape.OUTER_LEFT, variantsOuter.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.X_ROT, VariantProperties.Rotation.R180).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R90).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.NORTH, Half.TOP, StairsShape.OUTER_LEFT, variantsOuter.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.X_ROT, VariantProperties.Rotation.R180).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R270).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.EAST, Half.TOP, StairsShape.INNER_RIGHT, variantsInner.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.X_ROT, VariantProperties.Rotation.R180).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R90).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.WEST, Half.TOP, StairsShape.INNER_RIGHT, variantsInner.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.X_ROT, VariantProperties.Rotation.R180).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R270).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.SOUTH, Half.TOP, StairsShape.INNER_RIGHT, variantsInner.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.X_ROT, VariantProperties.Rotation.R180).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R180).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.NORTH, Half.TOP, StairsShape.INNER_RIGHT, variantsInner.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.X_ROT, VariantProperties.Rotation.R180).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.EAST, Half.TOP, StairsShape.INNER_LEFT, variantsInner.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.X_ROT, VariantProperties.Rotation.R180).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.WEST, Half.TOP, StairsShape.INNER_LEFT, variantsInner.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.X_ROT, VariantProperties.Rotation.R180).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R180).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.SOUTH, Half.TOP, StairsShape.INNER_LEFT, variantsInner.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.X_ROT, VariantProperties.Rotation.R180).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R90).with(VariantProperties.UV_LOCK, true)).toList())
                .select(Direction.NORTH, Half.TOP, StairsShape.INNER_LEFT, variantsInner.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.X_ROT, VariantProperties.Rotation.R180).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R270).with(VariantProperties.UV_LOCK, true)).toList())));
    }

    private void createRandomSlabWithCubeAll(BlockModelGenerators blockModelGenerators, Block block, Block base, int amount) {
        List<Variant> variantsBottom = new ArrayList<>();
        List<Variant> variantsTop = new ArrayList<>();
        List<Variant> variantsDouble = new ArrayList<>();
        for (int i = 0; i < amount; i++) {
            Identifier model = ModelLocationUtils.getModelLocation(block, i == 0 ? "" : "_" + (i + 1));
            Identifier texture = TextureMapping.getBlockTexture(base, i == 0 ? "" : "_" + (i + 1));

            Identifier bottomModel = ModelTemplates.SLAB_BOTTOM.create(model, TextureMapping.cube(texture), blockModelGenerators.modelOutput);
            Identifier topModel = ModelTemplates.SLAB_TOP.create(model.withSuffix("_top"), TextureMapping.cube(texture), blockModelGenerators.modelOutput);
            Identifier doubleModel = ModelLocationUtils.getModelLocation(base, i == 0 ? "" : "_" + (i + 1));
            variantsBottom.add(Variant.variant().with(VariantProperties.MODEL, bottomModel));
            variantsTop.add(Variant.variant().with(VariantProperties.MODEL, topModel));
            variantsDouble.add(Variant.variant().with(VariantProperties.MODEL, doubleModel));
        }

        blockModelGenerators.blockStateOutput.accept(MultiVariantGenerator.multiVariant(block).with(PropertyDispatch.property(BlockStateProperties.SLAB_TYPE)
                .select(SlabType.BOTTOM, variantsBottom)
                .select(SlabType.TOP, variantsTop)
                .select(SlabType.DOUBLE, variantsDouble)));
    }

    private void createRandomWall(BlockModelGenerators blockModelGenerators, Block block, Block base, int amount) {
        List<Identifier> variantsPost = new ArrayList<>();
        List<Identifier> variantsSide = new ArrayList<>();
        List<Identifier> variantsSideTall = new ArrayList<>();
        for (int i = 0; i < amount; i++) {
            Identifier model = ModelLocationUtils.getModelLocation(block, i == 0 ? "" : "_" + (i + 1));
            Identifier texture = TextureMapping.getBlockTexture(base, i == 0 ? "" : "_" + (i + 1));

            Identifier postModel = ModelTemplates.WALL_POST.create(model.withSuffix("_post"), TextureMapping.cube(texture), blockModelGenerators.modelOutput);
            Identifier sideModel = ModelTemplates.WALL_LOW_SIDE.create(model.withSuffix("_side"), TextureMapping.cube(texture), blockModelGenerators.modelOutput);
            Identifier sideTallModel = ModelTemplates.WALL_TALL_SIDE.create(model.withSuffix("_side_tall"), TextureMapping.cube(texture), blockModelGenerators.modelOutput);
            variantsPost.add(postModel);
            variantsSide.add(sideModel);
            variantsSideTall.add(sideTallModel);
        }

        blockModelGenerators.blockStateOutput.accept(MultiPartGenerator.multiPart(block)
                .with(Condition.condition().term(BlockStateProperties.UP, true), variantsPost.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model)).toList())
                .with(Condition.condition().term(BlockStateProperties.NORTH_WALL, WallSide.LOW), variantsSide.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.UV_LOCK, true)).toList())
                .with(Condition.condition().term(BlockStateProperties.EAST_WALL, WallSide.LOW), variantsSide.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R90).with(VariantProperties.UV_LOCK, true)).toList())
                .with(Condition.condition().term(BlockStateProperties.SOUTH_WALL, WallSide.LOW), variantsSide.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R180).with(VariantProperties.UV_LOCK, true)).toList())
                .with(Condition.condition().term(BlockStateProperties.WEST_WALL, WallSide.LOW), variantsSide.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R270).with(VariantProperties.UV_LOCK, true)).toList())
                .with(Condition.condition().term(BlockStateProperties.NORTH_WALL, WallSide.TALL), variantsSideTall.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.UV_LOCK, true)).toList())
                .with(Condition.condition().term(BlockStateProperties.EAST_WALL, WallSide.TALL), variantsSideTall.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R90).with(VariantProperties.UV_LOCK, true)).toList())
                .with(Condition.condition().term(BlockStateProperties.SOUTH_WALL, WallSide.TALL), variantsSideTall.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R180).with(VariantProperties.UV_LOCK, true)).toList())
                .with(Condition.condition().term(BlockStateProperties.WEST_WALL, WallSide.TALL), variantsSideTall.stream().map(model -> Variant.variant().with(VariantProperties.MODEL, model).with(VariantProperties.Y_ROT, VariantProperties.Rotation.R270).with(VariantProperties.UV_LOCK, true)).toList()));
    }
}