// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.content.entities.acidsprite;

import com.google.common.collect.Sets;
import com.kyanite.deeperdarker.content.DDItems;
import com.kyanite.deeperdarker.content.entities.Bubblox;
import com.kyanite.deeperdarker.util.DDTags;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.trading.VillagerTrades;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.trading.Merchant;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.item.trading.MerchantOffers;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import java.util.HashSet;

public class AcidSprite extends Monster implements Merchant {
    @Nullable
    private Player tradingPlayer = null;
    @Nullable
    protected MerchantOffers offers;

    public final AnimationState idleAnimationState = new AnimationState();

    public AcidSprite(EntityType<? extends Monster> entityType, Level level) {
        super(entityType, level);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new AcidSpriteTradeWithPlayerGoal(this));
        this.goalSelector.addGoal(2, new AcidSpriteLookAtTradingPlayerGoal(this));
        this.goalSelector.addGoal(2, new LeapAtTargetGoal(this, 0.5f));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.2, true));
        this.goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.9));
        this.goalSelector.addGoal(2, new RandomStrollGoal(this, 0.7));
        this.goalSelector.addGoal(2, new LookAtPlayerGoal(this, Player.class, 5));
        this.goalSelector.addGoal(2, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true, (entity, server) -> !isFriendlyPlayer(entity)));
        this.targetSelector.addGoal(2, new HurtByTargetGoal(this));
    }

    public static AttributeSupplier createAttributes() {
        return Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH, 5).add(Attributes.ATTACK_DAMAGE, 1).add(Attributes.KNOCKBACK_RESISTANCE, -1.0).add(Attributes.MOVEMENT_SPEED, 0.5).build();
    }

    @Override
    public @Nullable SpawnGroupData finalizeSpawn(ServerLevelAccessor serverLevelAccessor, DifficultyInstance difficultyInstance, EntitySpawnReason mobSpawnType, @Nullable SpawnGroupData spawnGroupData) {
        spawnGroupData = super.finalizeSpawn(serverLevelAccessor, difficultyInstance, mobSpawnType, spawnGroupData);
        float f = difficultyInstance.getSpecialMultiplier();
        if (this.random.nextFloat() < f * 0.2f) {
            this.getAttribute(Attributes.ATTACK_DAMAGE).addPermanentModifier(new AttributeModifier(net.minecraft.resources.Identifier.fromNamespaceAndPath("deeperdarker", "acid_sprite/acid_sprite_bonus"), this.random.nextDouble() + 1.0, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
            this.getAttribute(Attributes.MOVEMENT_SPEED).addPermanentModifier(new AttributeModifier(net.minecraft.resources.Identifier.fromNamespaceAndPath("deeperdarker", "acid_sprite/acid_sprite_debuff"), -this.random.nextDouble() * 0.1, AttributeModifier.Operation.ADD_VALUE));
        } else if (this.random.nextFloat() < 0.5f - f * 0.25) {
            this.getAttribute(Attributes.ATTACK_DAMAGE).addPermanentModifier(new AttributeModifier(net.minecraft.resources.Identifier.fromNamespaceAndPath("deeperdarker", "acid_sprite/acid_sprite_debuff"), 0.0, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        }
        return spawnGroupData;
    }

    @Override
    public void tick() {
        if (this.level().isClientSide()) {
            this.idleAnimationState.animateWhen(!walkAnimation.isMoving(), this.tickCount);
        }
        if (((com.kyanite.deeperdarker.content.fluids.EntityInAcid) this).deeperdarker$isInAcid() && !isDeadOrDying() && !hasCustomName()) {
            discard();
            Bubblox bubblox = new Bubblox(level(), getX(), getY(), getZ());
            bubblox.setSize((byte) getRandom().nextIntBetweenInclusive(0, 2));
            level().addFreshEntity(bubblox);
        }
        super.tick();
    }

    @Override
    public void addAdditionalSaveData(net.minecraft.world.level.storage.ValueOutput compoundTag) {
        super.addAdditionalSaveData(compoundTag);
        MerchantOffers merchantOffers = this.getOffers();
        if (!merchantOffers.isEmpty()) {
            compoundTag.store("offers", MerchantOffers.CODEC, merchantOffers);
        }
    }

    @Override
    public void readAdditionalSaveData(net.minecraft.world.level.storage.ValueInput compoundTag) {
        super.readAdditionalSaveData(compoundTag);
        offers = compoundTag.read("offers", MerchantOffers.CODEC).orElse(null);
    }

    @Override
    public boolean isSensitiveToWater() {
        return true;
    }

    @Override
    @Nullable
    public Entity teleport(net.minecraft.world.level.portal.TeleportTransition transition) {
        stopTrading();
        return super.teleport(transition);
    }

    protected void stopTrading() {
        this.setTradingPlayer(null);
    }

    @Override
    public void die(DamageSource damageSource) {
        super.die(damageSource);
        stopTrading();
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand interactionHand) {
        ItemStack itemStack = player.getItemInHand(interactionHand);
        if (!itemStack.is(DDItems.ACID_SPRITE_SPAWN_EGG) && isAlive() && !isTrading() && isFriendlyPlayer(player)) {
            if (getOffers().isEmpty()) {
                return InteractionResult.SUCCESS;
            }
            if (!level().isClientSide()) {
                setTradingPlayer(player);
                openTradingScreen(player, getDisplayName(), 1);
            }
            return InteractionResult.SUCCESS;
        }
        return super.mobInteract(player, interactionHand);
    }

    public boolean isFriendlyPlayer(LivingEntity entity) {
        if (!(entity instanceof Player)) return false;
        for (ItemStack stack : com.kyanite.deeperdarker.util.DDArmorSlots.of(entity)) {
            if (!stack.is(DDTags.Items.ALLOWS_ACID_SPRITE_TRADES)) return false;
        }
        return true;
    }

    @Override
    public void setTradingPlayer(@Nullable Player player) {
        if (player == null) {
            tradingPlayer = null;
            return;
        }
        if (!isFriendlyPlayer(player)) return;
        tradingPlayer = player;
    }

    @Override
    public @Nullable Player getTradingPlayer() {
        return tradingPlayer;
    }

    @Override
    public boolean stillValid(Player player) {
        return isAlive() && player == tradingPlayer && distanceToSqr(player) <= 16 && isFriendlyPlayer(player);
    }

    public boolean isTrading() {
        return tradingPlayer != null;
    }

    @Override
    public MerchantOffers getOffers() {
        if (offers == null) {
            offers = new MerchantOffers();
            updateTrades();
        }
        return offers;
    }

    protected void updateTrades() {
        AcidSpriteTrades.TradeListing[] itemListings = AcidSpriteTrades.TRADES.get(1);
        AcidSpriteTrades.TradeListing[] itemListings2 = AcidSpriteTrades.TRADES.get(2);
        if (itemListings == null || itemListings2 == null) {
            return;
        }
        MerchantOffers merchantOffers = getOffers();
        addOffersFromItemListings(merchantOffers, itemListings, 2);
        for (AcidSpriteTrades.TradeListing itemListing : itemListings2) {
            MerchantOffer merchantOffer = itemListing.getOffer(this, random);
            if (merchantOffer != null) {
                merchantOffers.add(merchantOffer);
            }
        }
    }

    protected void addOffersFromItemListings(MerchantOffers merchantOffers, AcidSpriteTrades.TradeListing[] itemListings, int i) {
        HashSet<Integer> set = Sets.newHashSet();
        if (itemListings.length > i) {
            while (set.size() < i) {
                set.add(getRandom().nextInt(itemListings.length));
            }
        } else {
            for (int j = 0; j < itemListings.length; ++j) {
                set.add(j);
            }
        }
        for (Integer integer : set) {
            AcidSpriteTrades.TradeListing itemListing = itemListings[integer];
            MerchantOffer merchantOffer = itemListing.getOffer(this, getRandom());
            if (merchantOffer == null) continue;
            merchantOffers.add(merchantOffer);
        }
    }

    @Override
    public void overrideOffers(MerchantOffers merchantOffers) {
    }

    @Override
    public void notifyTrade(MerchantOffer merchantOffer) {
        merchantOffer.increaseUses();
    }

    @Override
    public void notifyTradeUpdated(ItemStack itemStack) {
    }

    @Override
    public int getVillagerXp() {
        return 0;
    }

    @Override
    public void overrideXp(int i) {
    }

    @Override
    public boolean showProgressBar() {
        return false;
    }

    @Override
    public SoundEvent getNotifyTradeSound() {
        return SoundEvents.VILLAGER_YES; // todo: custom sound effect
    }

    @Override
    public boolean isClientSide() {
        return level().isClientSide();
    }

    public static class AcidSpriteTradeWithPlayerGoal extends Goal {
        private final AcidSprite mob;

        public AcidSpriteTradeWithPlayerGoal(AcidSprite acidSprite) {
            this.mob = acidSprite;
            this.setFlags(EnumSet.of(Goal.Flag.JUMP, Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (!this.mob.isAlive()) {
                return false;
            }
            if (this.mob.isInWater()) {
                return false;
            }
            if (!this.mob.onGround()) {
                return false;
            }
            if (this.mob.syncVelocity) {
                return false;
            }
            Player player = this.mob.getTradingPlayer();
            if (player == null) {
                return false;
            }
            if (this.mob.distanceToSqr(player) > 16.0) {
                return false;
            }
            return player.containerMenu != null;
        }

        @Override
        public void start() {
            this.mob.getNavigation().stop();
        }

        @Override
        public void stop() {
            this.mob.setTradingPlayer(null);
        }
    }

    public static class AcidSpriteLookAtTradingPlayerGoal extends LookAtPlayerGoal {
        private final AcidSprite acidSprite;

        public AcidSpriteLookAtTradingPlayerGoal(AcidSprite acidSprite) {
            super(acidSprite, Player.class, 8.0f);
            this.acidSprite = acidSprite;
        }

        @Override
        public boolean canUse() {
            if (this.acidSprite.isTrading()) {
                this.lookAt = this.acidSprite.getTradingPlayer();
                return true;
            }
            return false;
        }
    }
}
