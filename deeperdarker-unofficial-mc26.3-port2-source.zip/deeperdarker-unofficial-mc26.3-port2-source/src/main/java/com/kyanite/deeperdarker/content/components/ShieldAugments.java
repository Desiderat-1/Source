// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.content.components;
import com.kyanite.deeperdarker.util.DDTags;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.NbtOps;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemStackTemplate;
import net.minecraft.world.item.component.CustomData;
import java.util.Optional;
public final class ShieldAugments {
    private static final String OLD_ITEM = "deeperdarker:item";
    private ShieldAugments() {}
    public static ItemStack read(ItemStack shield) {
        var saved = shield.get(DDDataComponents.AUGMENT_ITEM);
        return saved == null ? ItemStack.EMPTY : saved.create();
    }
    public static ItemStack read(ItemStack shield, HolderLookup.Provider registries) {
        var saved = shield.get(DDDataComponents.AUGMENT_ITEM);
        if (saved != null) return saved.create();
        var old = shield.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getCompound(OLD_ITEM);
        if (old.isEmpty()) return ItemStack.EMPTY;
        var tag = old.get();
        if (tag.contains("Count")) {
            tag = (net.minecraft.nbt.CompoundTag) net.minecraft.util.datafix.DataFixers.getDataFixer().update(
                net.minecraft.util.datafix.fixes.References.ITEM_STACK,
                new com.mojang.serialization.Dynamic<>(NbtOps.INSTANCE, tag), 3465,
                net.minecraft.SharedConstants.getCurrentVersion().dataVersion().version()).getValue();
        }
        return ItemStack.CODEC.parse(registries.createSerializationContext(NbtOps.INSTANCE), tag)
                .result().map(stack -> stack.copyWithCount(1)).orElse(ItemStack.EMPTY);
    }
    public static boolean add(ItemStack shield, ItemStack augment, HolderLookup.Provider registries) {
        if (augment.isEmpty() || !augment.getItem().canFitInsideContainerItems()
                || !augment.is(DDTags.Items.SHIELD_AUGMENT_ITEMS) || !read(shield, registries).isEmpty()) return false;
        write(shield, augment);
        return true;
    }
    public static Optional<ItemStack> remove(ItemStack shield, HolderLookup.Provider registries) {
        var item = read(shield, registries);
        if (item.isEmpty()) return Optional.empty();
        shield.remove(DDDataComponents.AUGMENT_ITEM);
        clearLegacy(shield);
        return Optional.of(item);
    }
    public static void migrate(ItemStack shield, HolderLookup.Provider registries) {
        if (shield.has(DDDataComponents.AUGMENT_ITEM)) return;
        var item = read(shield, registries);
        if (!item.isEmpty()) write(shield, item);
    }
    private static void write(ItemStack shield, ItemStack augment) {
        shield.set(DDDataComponents.AUGMENT_ITEM, ItemStackTemplate.fromNonEmptyStack(augment, 1));
        clearLegacy(shield);
    }
    private static void clearLegacy(ItemStack shield) {
        var data = shield.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        data.remove(OLD_ITEM);
        if (data.isEmpty()) shield.remove(DataComponents.CUSTOM_DATA);
        else shield.set(DataComponents.CUSTOM_DATA, CustomData.of(data));
    }
}
