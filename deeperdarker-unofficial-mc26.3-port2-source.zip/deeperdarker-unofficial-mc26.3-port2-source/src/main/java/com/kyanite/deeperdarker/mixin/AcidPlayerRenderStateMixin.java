package com.kyanite.deeperdarker.mixin;

import com.kyanite.deeperdarker.client.state.AcidOverlayState;
import net.minecraft.client.renderer.state.level.PlayerRenderState;
import org.spongepowered.asm.mixin.*;
import org.jetbrains.annotations.Nullable;

@Mixin(PlayerRenderState.class)
public abstract class AcidPlayerRenderStateMixin implements AcidOverlayState {
    @Unique private PlayerRenderState.WaterOverlay deeperdarker$acid;
    @Override public @Nullable PlayerRenderState.WaterOverlay deeperdarker$acidOverlay(){return deeperdarker$acid;}
    @Override public void deeperdarker$setAcidOverlay(@Nullable PlayerRenderState.WaterOverlay overlay){deeperdarker$acid=overlay;}
}
