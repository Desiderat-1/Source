// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.client.render;

import com.kyanite.deeperdarker.DeeperDarker;
import com.kyanite.deeperdarker.client.model.ShriekWormModel;
import com.kyanite.deeperdarker.content.entities.ShriekWorm;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

@SuppressWarnings("NullableProblems")
public class ShriekWormRenderer extends DDMobRenderer<ShriekWorm, ShriekWormModel> {
    public static final ModelLayerLocation MODEL = new ModelLayerLocation(Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "shriek_worm"), "main");
    private static final Identifier TEXTURE = Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "textures/entity/shriek_worm.png");

    public ShriekWormRenderer(EntityRendererProvider.Context pContext) {
        super(pContext, new ShriekWormModel(pContext.bakeLayer(MODEL)), 1.2f);
    }

    @Override
    public Identifier getTextureLocation(ShriekWorm pEntity) {
        return TEXTURE;
    }
}
