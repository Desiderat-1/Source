// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.client.render;

import com.kyanite.deeperdarker.client.model.DDHierarchicalModel;
import com.kyanite.deeperdarker.client.state.DDModelRenderState;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Mob;

/** Standard vanilla rendering plus snapshots of the original model animation and corrections. */
public abstract class DDMobRenderer<T extends Mob, M extends DDHierarchicalModel<? super T>> extends MobRenderer<T, DDModelRenderState, M> {
    protected DDMobRenderer(EntityRendererProvider.Context context, M model, float shadow) { super(context, model, shadow); }
    public abstract Identifier getTextureLocation(T entity);
    @Override public final Identifier getTextureLocation(DDModelRenderState state) { return state.texture; }
    @Override public DDModelRenderState createRenderState() { return new DDModelRenderState(); }
    @Override public void extractRenderState(T entity, DDModelRenderState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);
        state.texture = getTextureLocation(entity);
        state.parts = model.capturePose(entity, state);
        PoseStack correction = new PoseStack();
        setupRotations(entity, correction, state.ageInTicks, state.bodyRot, partialTick);
        state.rotationCorrection.set(correction.last().pose());
        correction = new PoseStack();
        scale(entity, correction, partialTick);
        state.scaleCorrection.set(correction.last().pose());
    }
    @Override protected void setupRotations(DDModelRenderState state, PoseStack poses, float bodyRotation, float scale) {
        super.setupRotations(state, poses, bodyRotation, scale);
        poses.mulPose(state.rotationCorrection);
    }
    @Override protected void scale(DDModelRenderState state, PoseStack poses) {
        super.scale(state, poses);
        poses.mulPose(state.scaleCorrection);
    }
    // Extension callbacks add corrections; vanilla rotations/scaling are applied above.
    protected void setupRotations(T entity, PoseStack poses, float age, float bodyRotation, float partialTick) {}
    protected void scale(T entity, PoseStack poses, float partialTick) {}
}
