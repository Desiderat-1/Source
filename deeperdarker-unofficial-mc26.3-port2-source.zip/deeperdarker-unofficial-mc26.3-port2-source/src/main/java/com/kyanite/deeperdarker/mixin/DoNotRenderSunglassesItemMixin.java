package com.kyanite.deeperdarker.mixin;

import com.kyanite.deeperdarker.content.items.SunglassesItem;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** The head layer receives our 3D glasses separately; suppress the flat inventory item. */
@Mixin(LivingEntityRenderer.class)
public abstract class DoNotRenderSunglassesItemMixin {
    @Inject(method="extractRenderState(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;F)V",at=@At("TAIL"))
    private void deeperdarker$clearFlatGlasses(LivingEntity entity,LivingEntityRenderState state,float partial,CallbackInfo ci){
        if(entity.getItemBySlot(EquipmentSlot.HEAD).getItem() instanceof SunglassesItem)state.headItem.clear();
    }
}
