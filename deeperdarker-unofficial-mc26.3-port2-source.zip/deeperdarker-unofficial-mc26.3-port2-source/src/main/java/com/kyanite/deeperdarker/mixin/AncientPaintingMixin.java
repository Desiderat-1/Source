// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.mixin;

import com.kyanite.deeperdarker.util.DDTags;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.decoration.painting.Painting;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(Painting.class)
public abstract class AncientPaintingMixin {
    @WrapOperation(method = "dropItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/decoration/painting/Painting;spawnAtLocation(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/item/ItemStack;)Lnet/minecraft/world/entity/item/ItemEntity;"))
    private ItemEntity deeperdarker$dropIfAncientPainting(Painting instance, net.minecraft.server.level.ServerLevel level, ItemStack stack, Operation<ItemEntity> original) {
        ItemEntity itemEntity = original.call(instance, level, stack);
        if (instance.getVariant().is(DDTags.Paintings.ANCIENT)) {
            if (itemEntity != null) itemEntity.getItem().set(net.minecraft.core.component.DataComponents.PAINTING_VARIANT, instance.getVariant());
        }
        return itemEntity;
    }

    @ModifyReturnValue(method = "getPickResult", at = @At("RETURN"))
    private ItemStack deeperdarker$pickAncientPainting(ItemStack original) {
        if (((Painting)(Object)this).getVariant().is(DDTags.Paintings.ANCIENT)) {
            original.set(net.minecraft.core.component.DataComponents.PAINTING_VARIANT, ((Painting)(Object)this).getVariant());
        }
        return original;
    }
}
