package com.kyanite.deeperdarker.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.ContainerOpenersCounter;
import net.minecraft.world.level.entity.EntityTypeTest;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.List;
import java.util.function.Predicate;

@Mixin(ContainerOpenersCounter.class)
public abstract class ViewerCounterMixin {
    @WrapOperation(method = "getEntitiesWithContainerOpen", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/Level;getEntities(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;Ljava/util/function/Predicate;)Ljava/util/List;"))
    private List deeperdarker$containerIncludeAllPlayers(Level instance, Entity excluded, AABB aABB, Predicate predicate, Operation<List> original) {
        var result = new java.util.ArrayList<Entity>(original.call(instance, excluded, aABB, predicate));
        for (var player : instance.players()) {
            if (player != excluded && predicate.test(player) && !result.contains(player)) result.add(player);
        }
        return result;
    }
}
