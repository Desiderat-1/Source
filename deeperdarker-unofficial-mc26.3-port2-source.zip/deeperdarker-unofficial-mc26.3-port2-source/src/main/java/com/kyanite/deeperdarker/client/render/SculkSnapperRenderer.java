// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.client.render;

import com.kyanite.deeperdarker.DeeperDarker;
import com.kyanite.deeperdarker.client.model.SculkSnapperModel;
import com.kyanite.deeperdarker.content.entities.SculkSnapper;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

@SuppressWarnings("NullableProblems")
public class SculkSnapperRenderer extends DDMobRenderer<SculkSnapper, SculkSnapperModel> {
    public static final ModelLayerLocation MODEL = new ModelLayerLocation(Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "sculk_snapper"), "main");
    private static final Identifier TEXTURE = Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "textures/entity/sculk_snapper.png");

    public SculkSnapperRenderer(EntityRendererProvider.Context pContext) {
        super(pContext, new SculkSnapperModel(pContext.bakeLayer(MODEL)), 0.5f);
    }

    @Override
    public Identifier getTextureLocation(SculkSnapper pEntity) {
        return TEXTURE;
    }
}
