// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.content.items;

import com.kyanite.deeperdarker.content.DDSounds;
import com.kyanite.deeperdarker.content.components.TransmitterLink;
import com.kyanite.deeperdarker.util.DDTags;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.TicketType;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.Nullable;
import java.util.Optional;
import java.util.function.Consumer;

public class SculkTransmitterItem extends Item {
    public SculkTransmitterItem(Properties properties) { super(properties); }
    @Override public InteractionResult useOn(UseOnContext context) {
        return transmit(context.getLevel(), context.getPlayer(), context.getItemInHand(), context.getClickedPos(), context.getHand());
    }
    @Override public InteractionResult use(Level level, Player player, InteractionHand hand) {
        return isLinked(player.getItemInHand(hand)) ? transmit(level, player, player.getItemInHand(hand), null, hand) : InteractionResult.PASS;
    }
    public static InteractionResult transmit(Level level, @Nullable Player player, ItemStack stack, @Nullable BlockPos clickedPos, @Nullable InteractionHand hand) {
        if (player == null) return InteractionResult.PASS;
        if (player.isCrouching()) {
            boolean connect = clickedPos != null && canConnect(level, clickedPos);
            if (level.isClientSide()) return SculkTransmitterClient.confirm(player, stack, clickedPos, connect);
            return connect ? InteractionResult.SUCCESS : InteractionResult.FAIL;
        }
        if (level.isClientSide()) return InteractionResult.SUCCESS;
        Optional<TransmitterLink> link = TransmitterLink.read(stack);
        if (link.isEmpty()) return InteractionResult.FAIL;
        GlobalPos target = link.get().target();
        ServerLevel destination = level.getServer().getLevel(target.dimension());
        if (destination == null) { actionBarMessage(level, player, "not_found", DDSounds.TRANSMITTER_ERROR); return InteractionResult.FAIL; }
        BlockPos pos = target.pos();
        keepLoaded(destination, pos);
        if (!canConnect(destination, pos)) {
            actionBarMessage(level, player, "not_found", DDSounds.TRANSMITTER_ERROR);
            TransmitterLink.write(stack, null);
            return InteractionResult.FAIL;
        }
        destination.gameEvent(GameEvent.ENTITY_INTERACT, player.blockPosition(), GameEvent.Context.of(player));
        destination.getBlockState(pos).useWithoutItem(destination, player, new BlockHitResult(net.minecraft.world.phys.Vec3.atCenterOf(pos), Direction.SOUTH, pos, false));
        playSound(level, player, DDSounds.TRANSMITTER_OPEN);
        return InteractionResult.SUCCESS;
    }
    private static void keepLoaded(ServerLevel level, BlockPos pos) {
        level.getChunkSource().addTicketWithRadius(TicketType.UNKNOWN, ChunkPos.containing(pos), 1);
        level.getChunkAt(pos);
    }
    static int getSlot(Player player, ItemStack stack) {
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) if (player.getInventory().getItem(i) == stack) return i;
        return -1;
    }
    public static boolean isLinked(ItemStack stack) { return TransmitterLink.read(stack).isPresent(); }
    private static boolean canConnect(Level level, BlockPos pos) { return level.getBlockState(pos).is(DDTags.Blocks.TRANSMITTABLE); }
    public static void formConnection(Level level, ItemStack stack, @Nullable BlockPos pos) {
        TransmitterLink.write(stack, pos == null ? null : new TransmitterLink(new GlobalPos(level.dimension(), pos.immutable()), level.getBlockState(pos).getBlock().getDescriptionId()));
    }
    public static Optional<GlobalPos> readGlobalPosition(CompoundTag tag) { return TransmitterLink.readLegacy(tag); }
    public static void actionBarMessage(Level level, Player player, String key, @Nullable SoundEvent sound) {
        if (level.isClientSide()) return;
        player.sendOverlayMessage(Component.translatable("block.deeperdarker." + key));
        if (sound != null) playSound(level, player, sound);
    }
    private static void playSound(Level level, Player player, SoundEvent sound) {
        if (player instanceof ServerPlayer serverPlayer) serverPlayer.connection.send(new ClientboundSoundPacket(
            Holder.direct(sound), SoundSource.PLAYERS, player.getX(), player.getY(), player.getZ(), 1, 1, level.getRandom().nextLong()));
    }
    @Override public void appendHoverText(ItemStack stack, TooltipContext context, TooltipDisplay display, Consumer<Component> tooltip, TooltipFlag flag) {
        var link = TransmitterLink.read(stack);
        if (link.isPresent()) {
            GlobalPos pos = link.get().target();
            tooltip.accept(Component.translatable("tooltips.deeperdarker.sculk_transmitter.linked", Component.translatable(link.get().blockDescription())).withStyle(ChatFormatting.GRAY));
            tooltip.accept(Component.translatable("tooltips.deeperdarker.sculk_transmitter.location", pos.pos().getX(), pos.pos().getY(), pos.pos().getZ()).withStyle(ChatFormatting.GRAY));
            if (flag.isAdvanced()) tooltip.accept(Component.translatable("tooltips.deeperdarker.sculk_transmitter.location_advanced", pos.dimension().identifier().toString()).withStyle(ChatFormatting.DARK_GRAY));
        } else tooltip.accept(Component.translatable("tooltips.deeperdarker.sculk_transmitter.not_linked").withStyle(ChatFormatting.GRAY));
        super.appendHoverText(stack, context, display, tooltip, flag);
    }
    public static boolean stillValid(Player player, ServerLevel level, @Nullable BlockPos pos) {
        return player.getInventory().hasAnyMatching(stack -> {
            if (!(stack.getItem() instanceof SculkTransmitterItem)) return false;
            var link = TransmitterLink.read(stack);
            if (link.isEmpty()) return false;
            var target = link.get().target();
            if (level.dimension().equals(target.dimension()) && (pos == null || target.pos().distSqr(pos) < 64)
                && level.getBlockState(target.pos()).getBlock().getDescriptionId().equals(link.get().blockDescription())) {
                keepLoaded(level, target.pos()); return true;
            }
            return false;
        });
    }
    public static boolean stillValid(Player player, ContainerLevelAccess access) {
        return access.evaluate((level, pos) -> level instanceof ServerLevel serverLevel && stillValid(player, serverLevel, pos), true);
    }
    public static Item fromColor(DyeColor color) { return BuiltInRegistries.ITEM.getValue(Identifier.fromNamespaceAndPath("deeperdarker", color.getName() + "_sculk_transmitter")); }
}
