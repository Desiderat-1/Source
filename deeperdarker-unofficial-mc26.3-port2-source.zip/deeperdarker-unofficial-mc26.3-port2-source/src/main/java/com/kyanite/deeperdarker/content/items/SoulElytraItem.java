// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.content.items;

import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.TagKey;
import net.minecraft.util.Unit;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.equipment.EquipmentAssets;
import net.minecraft.world.item.equipment.Equippable;

public class SoulElytraItem extends Item {
    public SoulElytraItem(Properties properties) {
        super(properties.component(DataComponents.GLIDER, Unit.INSTANCE)
            .component(DataComponents.EQUIPPABLE, Equippable.builder(EquipmentSlot.CHEST)
                .setEquipSound(SoundEvents.ARMOR_EQUIP_ELYTRA).setDamageOnHurt(false)
                .setAsset(ResourceKey.create(EquipmentAssets.ROOT_ID, Identifier.fromNamespaceAndPath("deeperdarker", "soul_elytra"))).build())
            .repairable(TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("deeperdarker", "repairs_soul_elytra")))
            .attributes(ItemAttributeModifiers.builder().add(Attributes.ARMOR,
                new AttributeModifier(Identifier.fromNamespaceAndPath("deeperdarker", "soul_elytra_armor"), 3,
                    AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.CHEST).build()));
    }
}
