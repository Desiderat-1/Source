// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.util.recipes;

import net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingBookCategory;
import net.minecraft.world.item.crafting.RecipeSerializer;

import java.util.function.Predicate;

public class RemoveHornsRecipe extends ItemCombinerCustomRecipe {
    public RemoveHornsRecipe() { super(); }

    @Override
    public Predicate<ItemStack> getFirst() {
        return stack -> stack.is(net.minecraft.core.registries.BuiltInRegistries.ITEM.getValue(Identifier.fromNamespaceAndPath("deeperdarker", "warden_helmet"))) || stack.is(net.minecraft.core.registries.BuiltInRegistries.ITEM.getValue(Identifier.fromNamespaceAndPath("deeperdarker", "guardian_helmet")));
    }

    @Override
    public Predicate<ItemStack> getSecond() {
        return stack -> stack.is(ConventionalItemTags.SHEAR_TOOLS);
    }

    @Override
    public ItemStack assemble(ItemStack first, ItemStack second) {
        ItemStack result = first.copyWithCount(1);
        com.kyanite.deeperdarker.content.components.DDItemProperties.setHasHorns(result, false);
        return result;
    }

    @Override
    public RecipeSerializer<? extends net.minecraft.world.item.crafting.CustomRecipe> getSerializer() {
        return DDRecipeSerializers.REMOVE_HORNS;
    }
}
