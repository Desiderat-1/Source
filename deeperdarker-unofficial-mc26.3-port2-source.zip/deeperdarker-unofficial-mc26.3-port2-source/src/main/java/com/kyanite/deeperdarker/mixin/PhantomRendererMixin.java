package com.kyanite.deeperdarker.mixin;
import com.kyanite.deeperdarker.DeeperDarker;
import com.kyanite.deeperdarker.client.state.DDPhantomRenderState;
import com.kyanite.deeperdarker.util.DDTags;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.client.renderer.entity.PhantomRenderer;
import net.minecraft.client.renderer.entity.state.PhantomRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.monster.Phantom;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(PhantomRenderer.class)
public abstract class PhantomRendererMixin {
    @Inject(method="createRenderState()Lnet/minecraft/client/renderer/entity/state/PhantomRenderState;",at=@At("HEAD"),cancellable=true)
    private void deeperdarker$createState(CallbackInfoReturnable<PhantomRenderState> cir){cir.setReturnValue(new DDPhantomRenderState());}
    @Inject(method="extractRenderState(Lnet/minecraft/world/entity/monster/Phantom;Lnet/minecraft/client/renderer/entity/state/PhantomRenderState;F)V",at=@At("TAIL"))
    private void deeperdarker$extractTexture(Phantom entity,PhantomRenderState state,float partialTick,CallbackInfo ci){
        ((DDPhantomRenderState)state).sculkTexture=DeeperDarker.CONFIG.client.changePhantomTextures()
            && entity.level().getBiome(entity.blockPosition()).is(DDTags.Biomes.SCULK_PHANTOM_BIOMES);
    }
    @ModifyReturnValue(method="getTextureLocation(Lnet/minecraft/client/renderer/entity/state/PhantomRenderState;)Lnet/minecraft/resources/Identifier;",at=@At("RETURN"))
    private Identifier deeperdarker$texture(Identifier original,PhantomRenderState state){
        return ((DDPhantomRenderState)state).sculkTexture?Identifier.fromNamespaceAndPath("deeperdarker","textures/entity/sculk_phantom.png"):original;
    }
}
