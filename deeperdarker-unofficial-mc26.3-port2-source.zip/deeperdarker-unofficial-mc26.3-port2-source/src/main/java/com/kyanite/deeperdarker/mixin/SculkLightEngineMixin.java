package com.kyanite.deeperdarker.mixin;
import com.kyanite.deeperdarker.util.DDTags;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.lighting.LightEngine;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
@Mixin(LightEngine.class)
public abstract class SculkLightEngineMixin {
    @ModifyReturnValue(method="hasDifferentLightProperties", at=@At("RETURN"))
    private static boolean deeperdarker$sculkLightEngineEmission(boolean original, BlockState before, BlockState after) {
        // The native comparison no longer receives a level. Ensure equal native
        // emitters are still relit when crossing the Otherside exemption tag.
        // BlockLightEngine supplies the dimension-aware emission during relighting.
        return original || (before != after && before.getLightEmission()>0 &&
            before.is(DDTags.Blocks.SCULK_LIGHT_SOURCES) != after.is(DDTags.Blocks.SCULK_LIGHT_SOURCES));
    }
}
