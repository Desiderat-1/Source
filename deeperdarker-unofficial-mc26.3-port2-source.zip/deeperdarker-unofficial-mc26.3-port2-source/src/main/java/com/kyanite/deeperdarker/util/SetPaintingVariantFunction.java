package com.kyanite.deeperdarker.util;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.decoration.painting.PaintingVariant;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.functions.LootItemConditionalFunction;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import java.util.Optional;

public final class SetPaintingVariantFunction extends LootItemConditionalFunction {
    public static final MapCodec<SetPaintingVariantFunction> MAP_CODEC = RecordCodecBuilder.mapCodec(instance ->
            commonFields(instance).and(TagKey.codec(Registries.PAINTING_VARIANT).optionalFieldOf("tag")
                    .forGetter(function -> function.validPaintings)).apply(instance, SetPaintingVariantFunction::new));
    private final Optional<TagKey<PaintingVariant>> validPaintings;
    private SetPaintingVariantFunction(Optional<Holder<LootItemCondition>> condition, Optional<TagKey<PaintingVariant>> paintings) {
        super(condition); this.validPaintings=paintings;
    }
    @Override
    protected ItemStack run(ItemStack stack, LootContext context) {
        if (!stack.is(DDTags.Items.PAINTINGS)) return stack;
        var variants=context.getLevel().registryAccess().lookupOrThrow(Registries.PAINTING_VARIANT).listElements()
                .filter(holder -> validPaintings.isEmpty() || holder.is(validPaintings.get())).toList();
        if (!variants.isEmpty()) stack.set(DataComponents.PAINTING_VARIANT, variants.get(context.getRandom().nextInt(variants.size())));
        return stack;
    }
    public static Builder<?> withTag(TagKey<PaintingVariant> tag) {
        java.util.Objects.requireNonNull(tag,"tag");
        return simpleBuilder(condition -> new SetPaintingVariantFunction(condition,Optional.of(tag)));
    }
    public static Builder<?> random() { return simpleBuilder(condition -> new SetPaintingVariantFunction(condition,Optional.empty())); }
    public MapCodec<SetPaintingVariantFunction> codec() { return MAP_CODEC; }
}
