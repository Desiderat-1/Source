// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.client.render;

import com.kyanite.deeperdarker.DeeperDarker;
import com.kyanite.deeperdarker.client.DDModelLayers;
import com.kyanite.deeperdarker.client.model.PotModel;
import com.kyanite.deeperdarker.content.entities.OvercastPot;
import com.kyanite.deeperdarker.client.model.DDHierarchicalModel;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

@SuppressWarnings("NullableProblems")
public class PotRenderer extends DDMobRenderer<OvercastPot, DDHierarchicalModel<OvercastPot>> {
    private static final Identifier TEXTURE = Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "textures/entity/overcast_pot/pot.png");

    public PotRenderer(EntityRendererProvider.Context pContext) {
        super(pContext, new PotModel(pContext.bakeLayer(DDModelLayers.POT)), 0.5f);
    }

    @Override
    public Identifier getTextureLocation(OvercastPot entity) {
        return TEXTURE;
    }
}
