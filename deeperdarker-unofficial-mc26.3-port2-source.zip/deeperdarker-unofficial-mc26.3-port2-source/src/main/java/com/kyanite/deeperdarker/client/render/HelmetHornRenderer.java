package com.kyanite.deeperdarker.client.render;

import com.kyanite.deeperdarker.client.DDModelLayers;
import com.kyanite.deeperdarker.client.model.HelmetHornsModel;
import com.kyanite.deeperdarker.content.components.DDItemProperties;
import com.kyanite.deeperdarker.util.DDSettings;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.state.*;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Unit;

public final class HelmetHornRenderer<S extends HumanoidRenderState,M extends HumanoidModel<S>> extends RenderLayer<S,M> {
    private static final Identifier WARDEN_TEXTURE=Identifier.fromNamespaceAndPath("deeperdarker","textures/models/armor/warden_horns.png");
    private static final Identifier GUARDIAN_TEXTURE=Identifier.fromNamespaceAndPath("deeperdarker","textures/models/armor/guardian_horns.png");
    private final HelmetHornsModel model;
    public HelmetHornRenderer(RenderLayerParent<S,M> parent,EntityModelSet models){super(parent);model=new HelmetHornsModel(models.bakeLayer(DDModelLayers.HELMET_HORNS));}
    @Override
    public void submit(PoseStack poses,SubmitNodeCollector nodes,int light,S state,float yaw,float pitch){
        if(!DDSettings.CONFIG.client.renderWardenHelmetHorns())return;
        var helmet=state.headEquipment;if(helmet.isEmpty()||!DDItemProperties.hasHorns(helmet))return;
        Identifier item=BuiltInRegistries.ITEM.getKey(helmet.getItem());
        boolean guardian=item.equals(Identifier.fromNamespaceAndPath("deeperdarker","guardian_helmet"));
        if(!guardian&&!item.equals(Identifier.fromNamespaceAndPath("deeperdarker","warden_helmet")))return;
        poses.pushPose();
        if(state.isBaby){poses.translate(0,0.03125,0);poses.scale(0.7F,0.7F,0.7F);poses.translate(0,1,0);}
        getParentModel().getHead().translateAndRotate(poses);
        if(state.isBaby){poses.scale(1.3425F,1.3425F,1.3425F);poses.translate(0,-0.803125,0);}
        else {poses.scale(1.25F,1.25F,1.25F);poses.translate(0,-0.825,0);}
        if(state instanceof ZombieVillagerRenderState)poses.translate(0,-0.1,0);
        Identifier texture=guardian?GUARDIAN_TEXTURE:WARDEN_TEXTURE;
        nodes.submitModel(model,Unit.INSTANCE,poses,helmet.hasFoil()?RenderTypes.armorCutoutNoCullGlint(texture):RenderTypes.armorCutoutNoCull(texture),light,OverlayTexture.NO_OVERLAY,0xFFFFFFFF);
        poses.popPose();
    }
}
