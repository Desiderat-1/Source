// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.util.recipes;

import com.kyanite.deeperdarker.content.items.SculkTransmitterItem;
import com.kyanite.deeperdarker.util.DDTags;
import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.Identifier;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.DyeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingBookCategory;
import net.minecraft.world.item.crafting.CustomRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;

public class SculkTransmitterDyeRecipe extends CustomRecipe {
    public SculkTransmitterDyeRecipe() { super(); }

    @Override
    public boolean matches(net.minecraft.world.item.crafting.CraftingInput container, Level level) {
        ItemStack transmitterStack = null;
        ItemStack dyeStack = null;
        for (int i = 0; i < container.size(); ++i) {
            ItemStack stack = container.getItem(i);
            if (stack.is(DDTags.Items.SCULK_TRANSMITTERS)) {
                if (transmitterStack != null) return false;
                transmitterStack = stack;
            } else if (stack.has(net.minecraft.core.component.DataComponents.DYE)) {
                if (dyeStack != null) return false;
                dyeStack = stack;
            } else if (!stack.isEmpty()) return false;
        }
        return transmitterStack != null && dyeStack != null && SculkTransmitterItem.fromColor(dyeStack.get(net.minecraft.core.component.DataComponents.DYE)) != transmitterStack.getItem();
    }

    @Override
    public @NotNull ItemStack assemble(net.minecraft.world.item.crafting.CraftingInput container) {
        ItemStack transmitterStack = null;
        ItemStack result = null;
        for (int i = 0; i < container.size(); ++i) {
            ItemStack stack = container.getItem(i);
            if (stack.is(DDTags.Items.SCULK_TRANSMITTERS)) {
                transmitterStack = stack;
            } else if (stack.has(net.minecraft.core.component.DataComponents.DYE)) {
                result = new ItemStack(SculkTransmitterItem.fromColor(stack.get(net.minecraft.core.component.DataComponents.DYE)));
            }
        }
        return transmitterStack == null || result == null ? ItemStack.EMPTY : transmitterStack.transmuteCopy(result.getItem(), 1);
    }



    @Override
    public RecipeSerializer<? extends net.minecraft.world.item.crafting.CustomRecipe> getSerializer() {
        return DDRecipeSerializers.SCULK_TRANSMITTER_DYE;
    }
}
