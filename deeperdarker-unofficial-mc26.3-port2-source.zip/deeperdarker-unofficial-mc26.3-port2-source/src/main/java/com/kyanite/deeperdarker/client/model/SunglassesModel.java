// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.util.Mth;

public class SunglassesModel extends Model<net.minecraft.util.Unit> {
    private final ModelPart sunglasses;

    public SunglassesModel(ModelPart modelPart) {
        super(modelPart, net.minecraft.client.renderer.rendertype.RenderTypes::entityTranslucent);
        this.sunglasses = modelPart.getChild("sunglasses");
    }

    public static LayerDefinition createModel() {
        MeshDefinition meshDefinition = new MeshDefinition();
        PartDefinition partDefinition = meshDefinition.getRoot();
        partDefinition.addOrReplaceChild("sunglasses", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0f, -8.0f, -4.0f, 8.0f, 8.0f, 8.0f), PartPose.ZERO);
        return LayerDefinition.create(meshDefinition, 32, 32);
    }

    public void setupAnim(float yRot, float xRot) {
        sunglasses.yRot = yRot * Mth.DEG_TO_RAD;
        sunglasses.xRot = xRot * Mth.DEG_TO_RAD;
    }


}
