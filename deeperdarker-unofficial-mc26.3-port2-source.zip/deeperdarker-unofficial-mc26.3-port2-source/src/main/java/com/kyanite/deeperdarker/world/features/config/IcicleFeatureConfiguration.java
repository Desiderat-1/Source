// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.world.features.config;

import com.kyanite.deeperdarker.content.DDBlocks;
import com.kyanite.deeperdarker.util.DDTags;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.registries.Registries;
import net.minecraft.tags.TagKey;
import net.minecraft.util.random.WeightedList;
import net.minecraft.util.valueproviders.IntProvider;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.stateproviders.BlockStateProvider;
import net.minecraft.world.level.levelgen.feature.stateproviders.WeightedStateProvider;

public class IcicleFeatureConfiguration {
    public static final MapCodec<IcicleFeatureConfiguration> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            TagKey.codec(Registries.BLOCK).fieldOf("replaceable").orElse(DDTags.Blocks.ICE_REPLACEABLE).forGetter(config -> config.replaceable),
            TagKey.codec(Registries.BLOCK).fieldOf("base").orElse(DDTags.Blocks.ICE_BASE).forGetter(config -> config.base),
            BlockStateProvider.DIRECT_CODEC.fieldOf("ice_state_provider").orElse(new WeightedStateProvider(
                    WeightedList.<BlockState>builder()
                            .add(Blocks.PACKED_ICE.defaultBlockState(), 1)
                            .add(Blocks.BLUE_ICE.defaultBlockState(), 1).build()
            )).forGetter(config -> config.iceProvider),
            BlockStateProvider.DIRECT_CODEC.fieldOf("icicle_state_provider").orElse(BlockStateProvider.of(DDBlocks.ICICLE)).forGetter(config -> config.icicleProvider),
            net.minecraft.util.valueproviders.IntProviders.POSITIVE_CODEC.fieldOf("height_provider").orElse(UniformInt.of(3, 6)).forGetter(config -> config.heightProvider),
            Codec.floatRange(0.0f, 1.0f).fieldOf("chance_of_directional_spread").orElse(0.7f).forGetter(config -> config.chanceOfDirectionalSpread),
            Codec.floatRange(0.0f, 1.0f).fieldOf("chance_of_spread_radius2").orElse(0.6f).forGetter(config -> config.chanceOfSpreadRadius2),
            Codec.floatRange(0.0f, 1.0f).fieldOf("chance_of_spread_radius3").orElse(0.6f).forGetter(config -> config.chanceOfSpreadRadius3)
    ).apply(instance, IcicleFeatureConfiguration::new));
    public final TagKey<Block> replaceable;
    public final TagKey<Block> base;
    public final BlockStateProvider iceProvider;
    public final BlockStateProvider icicleProvider;
    public final IntProvider heightProvider;
    public final float chanceOfDirectionalSpread;
    public final float chanceOfSpreadRadius2;
    public final float chanceOfSpreadRadius3;

    public IcicleFeatureConfiguration(TagKey<Block> replaceable, TagKey<Block> base, BlockStateProvider iceProvider, BlockStateProvider icicleProvider, IntProvider heightProvider, float chanceOfDirectionalSpread, float chanceOfSpreadRadius2, float chanceOfSpreadRadius3) {
        this.replaceable = replaceable;
        this.base = base;
        this.iceProvider = iceProvider;
        this.icicleProvider = icicleProvider;
        this.heightProvider = heightProvider;
        this.chanceOfDirectionalSpread = chanceOfDirectionalSpread;
        this.chanceOfSpreadRadius2 = chanceOfSpreadRadius2;
        this.chanceOfSpreadRadius3 = chanceOfSpreadRadius3;
    }
}
