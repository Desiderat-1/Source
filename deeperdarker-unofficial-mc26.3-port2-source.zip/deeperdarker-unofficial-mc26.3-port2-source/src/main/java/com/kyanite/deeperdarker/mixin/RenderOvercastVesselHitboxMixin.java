package com.kyanite.deeperdarker.mixin;

import com.kyanite.deeperdarker.content.entities.overcastvessel.OvercastVessel;
import net.minecraft.client.renderer.debug.EntityHitboxDebugRenderer;
import net.minecraft.gizmos.*;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityHitboxDebugRenderer.class)
public abstract class RenderOvercastVesselHitboxMixin {
    @Inject(method="showHitboxes",at=@At("TAIL"))
    private void deeperdarker$showVesselParts(Entity entity,float partial,boolean server,CallbackInfo ci){
        if(entity instanceof OvercastVessel vessel)for(var part:vessel.getSubEntities())
            Gizmos.cuboid(part.getBoundingBox().move(part.getPosition(partial).subtract(part.position())),GizmoStyle.stroke(0xFF40FF00));
    }
}
