// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.mixin;
import com.kyanite.deeperdarker.content.items.ShieldAugmentItem;
import com.kyanite.deeperdarker.util.DDUtil;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.component.BlocksAttacks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
@Mixin(LivingEntity.class)
public abstract class LivingEntityShieldMixin {
    @WrapOperation(method = "applyItemBlocking", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/world/item/component/BlocksAttacks;resolveBlockedDamage(Lnet/minecraft/world/damagesource/DamageSource;FD)F"))
    private float deeperdarker$onBlock(BlocksAttacks blocking, DamageSource source, float amount, double angle, Operation<Float> original) {
        float blocked = original.call(blocking, source, amount, angle);
        var entity = (LivingEntity) (Object) this;
        var shield = entity.getItemBlockingWith();
        if (blocked > 0 && shield != null && DDUtil.isAugmentedShield(shield)) {
            var augment = DDUtil.getAugmentItem(shield, entity.level().registryAccess());
            if (augment.getItem() instanceof ShieldAugmentItem item) item.onShieldDefended(entity, source, amount);
        }
        return blocked;
    }
}
