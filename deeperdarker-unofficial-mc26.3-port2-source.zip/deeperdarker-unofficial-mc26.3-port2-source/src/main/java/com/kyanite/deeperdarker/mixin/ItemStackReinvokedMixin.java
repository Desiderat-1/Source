package com.kyanite.deeperdarker.mixin;

import com.kyanite.deeperdarker.content.blocks.Reinvokable;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.List;

@Mixin(ItemStack.class)
public abstract class ItemStackReinvokedMixin implements Reinvokable {
    @Override
    public boolean deeperdarker$isReinvoked() {
        ItemStack stack = (ItemStack) (Object) this;
        return com.kyanite.deeperdarker.content.components.DDItemProperties.isReinvoked(stack);
    }

    @Override
    public void deeperdarker$setReinvoked(boolean value) {
        ItemStack stack = (ItemStack) (Object) this;
        com.kyanite.deeperdarker.content.components.DDItemProperties.setReinvoked(stack, value);
    }

    @Inject(method = "getTooltipLines", at = @At("RETURN"))
    private void deeperdarker$addReinvokedLine(net.minecraft.world.item.Item.TooltipContext context, @Nullable Player player, TooltipFlag tooltipFlag, CallbackInfoReturnable<List<Component>> cir) {
        if (deeperdarker$isReinvoked()) {
            cir.getReturnValue().add(Component.translatable("tooltips.deeperdarker.reinvoked").withStyle(ChatFormatting.AQUA));
        }
    }
}
