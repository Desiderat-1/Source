// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.util.recipes;

import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.Identifier;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingBookCategory;
import net.minecraft.world.item.crafting.CustomRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.Level;

import java.util.function.Predicate;

public class AcidResistantItemRecipe extends ItemCombinerCustomRecipe {
    public AcidResistantItemRecipe() { super(); }

    @Override
    public Predicate<ItemStack> getFirst() {
        return stack -> !stack.isEmpty() && !com.kyanite.deeperdarker.content.components.DDItemProperties.isAcidResistant(stack);
    }

    @Override
    public Predicate<ItemStack> getSecond() {
        return stack -> stack.is(net.minecraft.core.registries.BuiltInRegistries.ITEM.getValue(Identifier.fromNamespaceAndPath("deeperdarker", "fizz")));
    }

    @Override
    public ItemStack assemble(ItemStack first, ItemStack second) {
        ItemStack result = first.copyWithCount(1);
        com.kyanite.deeperdarker.content.components.DDItemProperties.setAcidResistant(result);
        return result;
    }


    @Override
    public RecipeSerializer<? extends net.minecraft.world.item.crafting.CustomRecipe> getSerializer() {
        return DDRecipeSerializers.ACID_RESISTANT_ITEM;
    }
}
