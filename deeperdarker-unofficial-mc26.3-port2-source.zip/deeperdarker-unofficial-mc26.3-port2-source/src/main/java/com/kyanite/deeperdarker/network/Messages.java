// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.network;

import com.kyanite.deeperdarker.DeeperDarker;
import com.kyanite.deeperdarker.content.DDItems;
import com.kyanite.deeperdarker.content.DDSounds;
import com.kyanite.deeperdarker.content.entities.SyncedOwnedEntity;
import com.kyanite.deeperdarker.content.items.SculkTransmitterItem;
import com.kyanite.deeperdarker.util.DDTags;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

public class Messages {
    public static void registerReceivers() {
        PacketRegistration.register();
        ServerPlayNetworking.registerGlobalReceiver(SoulElytraBoostPacket.TYPE, (packet, context) -> {
            var player = context.player();
            var level = player.level();
            int cooldown = DeeperDarker.CONFIG.server.soulElytraCooldown();
            if (cooldown == -1) {
                player.sendSystemMessage(Component.translatable(DDItems.SOUL_ELYTRA.getDescriptionId() + ".boost_disabled")
                        .withStyle(ChatFormatting.RED), true);
                return;
            }
            ItemStack elytra = player.getItemBySlot(EquipmentSlot.CHEST);
            if (player.isFallFlying() && elytra.is(DDItems.SOUL_ELYTRA) && !player.getCooldowns().isOnCooldown(elytra)) {
                var lookAngle = player.getLookAngle();
                player.addDeltaMovement(lookAngle.multiply(1.5F, 1.5F, 1.5F));
                player.connection.send(new ClientboundSetEntityMotionPacket(player));
                lookAngle = lookAngle.reverse();
                for (int i = 0; i < 5; i++) {
                    level.sendParticles(ParticleTypes.SONIC_BOOM, player.getX() + lookAngle.x() * i,
                            player.getY() + lookAngle.y() * i, player.getZ() + lookAngle.z() * i, 1, 0, 0, 0, 0);
                }
                player.getCooldowns().addCooldown(elytra, cooldown);
            }
        });
        ServerPlayNetworking.registerGlobalReceiver(UseTransmitterPacket.TYPE, (packet, context) -> {
            var player = context.player();
            for (ItemStack stack : player.getInventory().getNonEquipmentItems()) {
                if (stack.getItem() instanceof SculkTransmitterItem && SculkTransmitterItem.isLinked(stack)) {
                    SculkTransmitterItem.transmit(player.level(), player, stack, null, null);
                    break;
                }
            }
        });
        ServerPlayNetworking.registerGlobalReceiver(UnlinkTransmitterPacket.TYPE, (packet, context) -> {
            var player = context.player();
            if (packet.slot() < 0 || packet.slot() >= player.getInventory().getContainerSize()) return;
            ItemStack stack = player.getInventory().getItem(packet.slot());
            if (stack.getItem() instanceof SculkTransmitterItem) {
                SculkTransmitterItem.actionBarMessage(player.level(), player, "unlinked", DDSounds.TRANSMITTER_UNLINK);
                SculkTransmitterItem.formConnection(player.level(), stack, null);
            }
        });
        ServerPlayNetworking.registerGlobalReceiver(LinkTransmitterPacket.TYPE, (packet, context) -> {
            var player = context.player();
            if (packet.slot() < 0 || packet.slot() >= player.getInventory().getContainerSize()) return;
            if (!player.level().hasChunkAt(packet.blockPos()) || !player.isWithinBlockInteractionRange(packet.blockPos(), 1)) return;
            if (!player.level().getBlockState(packet.blockPos()).is(DDTags.Blocks.TRANSMITTABLE)) return;
            ItemStack stack = player.getInventory().getItem(packet.slot());
            if (stack.getItem() instanceof SculkTransmitterItem) {
                SculkTransmitterItem.actionBarMessage(player.level(), player, "linked", DDSounds.TRANSMITTER_LINK);
                SculkTransmitterItem.formConnection(player.level(), stack, packet.blockPos());
            }
        });
    }

    @Environment(EnvType.CLIENT)
    public static void registerClientReceivers() {
        ClientPlayNetworking.registerGlobalReceiver(LinkOwnedEntityPacket.TYPE, (packet, context) -> {
            if (packet.ownedEntityId() == 0) return;
            var entity = context.player().level().getEntity(packet.ownedEntityId());
            if (entity instanceof SyncedOwnedEntity ownedEntity) ownedEntity.setDelayedOwnerId(packet.ownerId());
        });
    }
}
