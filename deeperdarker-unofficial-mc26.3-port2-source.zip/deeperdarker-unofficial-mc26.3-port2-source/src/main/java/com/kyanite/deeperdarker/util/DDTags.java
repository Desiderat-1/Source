// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.util;


import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.decoration.painting.PaintingVariant;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.material.Fluid;

public class DDTags {
    public static class Blocks {
        public static final TagKey<Block> ECHO_LOGS = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "echo_logs"));
        public static final TagKey<Block> BLOOMING_STEMS = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "blooming_stems"));
        public static final TagKey<Block> SCULK_SPRUCE_LOGS = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "sculk_spruce_logs"));

        public static final TagKey<Block> OTHERSIDE_CARVER_REPLACEABLES = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "otherside_carver_replaceables"));
        public static final TagKey<Block> SCULK_STONE_REPLACEABLES = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "sculk_stone_replaceables"));
        public static final TagKey<Block> SCULK_REPLACEABLES = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "sculk_replaceables"));
        public static final TagKey<Block> DEEPLANDS_COLUMN_REPLACEABLE = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "deeplands_column_replaceable"));
        public static final TagKey<Block> DEEPLANDS_COLUMN_BASE = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "deeplands_column_base"));

        public static final TagKey<Block> GLOOMSLATE_REPLACEABLE = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "gloomslate_replaceable"));
        public static final TagKey<Block> GLOOMY_SCULK_REPLACEABLE = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "gloomy_sculk_replaceable"));
        public static final TagKey<Block> OVERCAST_COLUMN_REPLACEABLE = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "overcast_column_replaceable"));
        public static final TagKey<Block> OVERCAST_COLUMN_BASE = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "overcast_column_base"));

        public static final TagKey<Block> BLOOMING_POOL_REPLACEABLE = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "blooming_pool_replaceable"));

        public static final TagKey<Block> SCULK_VINE_PLACEABLE = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "sculk_vine_placeable"));
        public static final TagKey<Block> GLOWING_VINE_PLACEABLE = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "glowing_vine_placeable"));

        public static final TagKey<Block> SCULK_SPRUCE_FOREST_REPLACEABLE = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "sculk_spruce_forest_replaceable"));
        public static final TagKey<Block> ICE_REPLACEABLE = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "ice_replaceable"));
        public static final TagKey<Block> ICE_BASE = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "ice_base"));

        public static final TagKey<Block> DARK_FOUNTAIN_BEAM_PASSTHROUGH = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "dark_fountain_beam_passthrough"));

        public static final TagKey<Block> TRANSMITTABLE = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "transmittable"));
        public static final TagKey<Block> INFINIBURN_OTHERSIDE = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "infiniburn_otherside"));

        public static final TagKey<Block> ECHO_SOIL = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "echo_soil"));

        public static final TagKey<Block> MAZE_CANNOT_HIDE_CHEST = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "maze/cannot_hide_chest"));
        public static final TagKey<Block> BLOOMING_GOLEM_CAN_WALK_THROUGH = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "blooming_golem_can_walk_through"));
        public static final TagKey<Block> BLOOMING_GOLEM_CAN_DESTROY = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "blooming_golem_can_destroy"));

        public static final TagKey<Block> SCULK_LIGHT_SOURCES = TagKey.create(
                Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "sculk_light_sources"));
    }

    public static class Items {
        public static final TagKey<Item> ECHO_LOGS = TagKey.create(
                Registries.ITEM, Identifier.fromNamespaceAndPath("deeperdarker", "echo_logs"));

        public static final TagKey<Item> BLOOMING_STEMS = TagKey.create(
                Registries.ITEM, Identifier.fromNamespaceAndPath("deeperdarker", "blooming_stems"));

        public static final TagKey<Item> SCULK_SPRUCE_LOGS = TagKey.create(
                Registries.ITEM, Identifier.fromNamespaceAndPath("deeperdarker", "sculk_spruce_logs"));

        public static final TagKey<Item> DAMPENS_VIBRATIONS = TagKey.create(
                Registries.ITEM, Identifier.fromNamespaceAndPath("deeperdarker", "dampens_vibrations"));

        public static final TagKey<Item> PAINTINGS = TagKey.create(
                Registries.ITEM, Identifier.fromNamespaceAndPath("deeperdarker", "paintings"));

        public static final TagKey<Item> SCUTES = TagKey.create(
                Registries.ITEM, Identifier.fromNamespaceAndPath("deeperdarker", "scutes"));

        public static final TagKey<Item> RESONARIUM_ARMOR = TagKey.create(
                Registries.ITEM, Identifier.fromNamespaceAndPath("deeperdarker", "resonarium_armor"));

        public static final TagKey<Item> SCULK_TRANSMITTERS = TagKey.create(
                Registries.ITEM, Identifier.fromNamespaceAndPath("deeperdarker", "sculk_transmitters"));

        public static final TagKey<Item> UNLOCKS_SMALL_LOCK = TagKey.create(
                Registries.ITEM, Identifier.fromNamespaceAndPath("deeperdarker", "unlocks_small_lock"));

        public static final TagKey<Item> UNLOCKS_LARGE_LOCK = TagKey.create(
                Registries.ITEM, Identifier.fromNamespaceAndPath("deeperdarker", "unlocks_large_lock"));

        public static final TagKey<Item> FULLBRIGHT = TagKey.create(
                Registries.ITEM, Identifier.fromNamespaceAndPath("deeperdarker", "fullbright"));

        public static final TagKey<Item> ACID_RESISTANT = TagKey.create(
                Registries.ITEM, Identifier.fromNamespaceAndPath("deeperdarker", "acid_resistant"));

        public static final TagKey<Item> ACID_IMMUNE_ARMOR = TagKey.create(
                Registries.ITEM, Identifier.fromNamespaceAndPath("deeperdarker", "acid_immune_armor"));

        public static final TagKey<Item> ALLOWS_ACID_SPRITE_TRADES = TagKey.create(
                Registries.ITEM, Identifier.fromNamespaceAndPath("deeperdarker", "allows_acid_sprite_trades"));

        public static final TagKey<Item> SHIELD_AUGMENT_ITEMS = TagKey.create(
                Registries.ITEM, Identifier.fromNamespaceAndPath("deeperdarker", "shield_augment_items"));

        public static final TagKey<Item> CLUTTER_ITEMS = TagKey.create(
                Registries.ITEM, Identifier.fromNamespaceAndPath("deeperdarker", "clutter_items"));
    }

    public static class EntityTypes {
        public static final TagKey<EntityType<?>> TOXIC_AIR_IMMUNE = TagKey.create(Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "toxic_air_immune"));
        public static final TagKey<EntityType<?>> ACID_IMMUNE = TagKey.create(Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "acid_immune"));
        public static final TagKey<EntityType<?>> OVERCASTERS = TagKey.create(Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "overcasters"));
    }

    public static class Biomes {
        public static final TagKey<Biome> HAS_ANCIENT_TEMPLE = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("deeperdarker", "has_structure/ancient_temple"));
        public static final TagKey<Biome> HAS_BLOOMAZE = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("deeperdarker", "has_structure/bloomaze"));
        public static final TagKey<Biome> HAS_GLOOMAZE = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("deeperdarker", "has_structure/gloomaze"));
        public static final TagKey<Biome> HAS_CASTLE = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("deeperdarker", "has_structure/castle"));
        public static final TagKey<Biome> HAS_SCULK_RUINS = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("deeperdarker", "has_structure/sculk_ruins"));
        public static final TagKey<Biome> HAS_WATCHTOWER = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("deeperdarker", "has_structure/watchtower"));
        public static final TagKey<Biome> HAS_VILLAGER_CAMP = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("deeperdarker", "has_structure/villager_camp"));
        public static final TagKey<Biome> HAS_ACID_FLOES = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("deeperdarker", "has_acid_floes"));
        public static final TagKey<Biome> SCULK_PHANTOM_BIOMES = TagKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("deeperdarker", "sculk_phantom_biomes"));
    }

    public static class Paintings {
        public static final TagKey<PaintingVariant> ANCIENT = TagKey.create(Registries.PAINTING_VARIANT, Identifier.fromNamespaceAndPath("deeperdarker", "ancient"));
    }

    public static class Structures {
        public static final TagKey<Structure> WARDEN_HEART_PULSES = TagKey.create(
                Registries.STRUCTURE, Identifier.fromNamespaceAndPath("deeperdarker", "warden_heart_pulses"));

        public static final TagKey<Structure> NO_BLOOMING_POOL_GENERATION = TagKey.create(
                Registries.STRUCTURE, Identifier.fromNamespaceAndPath("deeperdarker", "no_blooming_pool_generation"));
    }

    public static class GameEvents {
        public static final TagKey<GameEvent> CHEST_VIBRATIONS = TagKey.create(Registries.GAME_EVENT, Identifier.fromNamespaceAndPath("deeperdarker", "chest_vibrations"));
        public static final TagKey<GameEvent> FEET_VIBRATIONS = TagKey.create(Registries.GAME_EVENT, Identifier.fromNamespaceAndPath("deeperdarker", "feet_vibrations"));
    }

    public static class Fluids {
        public static final TagKey<Fluid> BLOCKS_DARK_FOUNTAIN_BEAM = TagKey.create(
                Registries.FLUID, Identifier.fromNamespaceAndPath("deeperdarker", "blocks_dark_fountain_beam"));

        public static final TagKey<Fluid> ACID = TagKey.create(
                Registries.FLUID, Identifier.fromNamespaceAndPath("deeperdarker", "acid"));
    }
}
