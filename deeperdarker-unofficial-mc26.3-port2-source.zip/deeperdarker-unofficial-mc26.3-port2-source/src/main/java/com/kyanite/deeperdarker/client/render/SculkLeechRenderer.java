// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.client.render;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import com.kyanite.deeperdarker.client.model.SculkLeechModel;
import com.kyanite.deeperdarker.content.entities.SculkLeech;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

@SuppressWarnings("NullableProblems")
public class SculkLeechRenderer extends MobRenderer<SculkLeech, LivingEntityRenderState, SculkLeechModel> {
    public static final ModelLayerLocation MODEL = new ModelLayerLocation(Identifier.fromNamespaceAndPath("deeperdarker", "sculk_leech"), "main");
    private static final Identifier TEXTURE = Identifier.fromNamespaceAndPath("deeperdarker", "textures/entity/sculk_leech.png");

    public SculkLeechRenderer(EntityRendererProvider.Context pContext) {
        super(pContext, new SculkLeechModel(pContext.bakeLayer(MODEL)), 0.4f);
    }

    @Override public LivingEntityRenderState createRenderState() { return new LivingEntityRenderState(); }

    @Override
    public Identifier getTextureLocation(LivingEntityRenderState state) {
        return TEXTURE;
    }
}
