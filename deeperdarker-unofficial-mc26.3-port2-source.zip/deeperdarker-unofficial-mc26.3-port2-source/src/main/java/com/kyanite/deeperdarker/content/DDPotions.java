// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.content;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.item.alchemy.Potion;
public final class DDPotions {
    public static final Holder<Potion> SCULK_AFFINITY = register("sculk_affinity", new MobEffectInstance(DDEffects.SCULK_AFFINITY, 3600));
    public static final Holder<Potion> LONG_SCULK_AFFINITY = register("long_sculk_affinity", new MobEffectInstance(DDEffects.SCULK_AFFINITY, 9600));
    public static final Holder<Potion> FIZZY = register("fizzy");
    public static final Holder<Potion> CORRUPTION = register("corruption", new MobEffectInstance(DDEffects.CORRUPTION, 1));
    public static final Holder<Potion> PURITY = register("purity", new MobEffectInstance(DDEffects.PURITY, 1));
    private static Holder<Potion> register(String id, MobEffectInstance... effects) {
        return Registry.registerForHolder(BuiltInRegistries.POTION, Identifier.fromNamespaceAndPath("deeperdarker", id), new Potion(id, effects));
    }
    public static void init() {
        // Brewing is data driven in 26.3: all seven original transformations are in recipe/brewing.
        org.slf4j.LoggerFactory.getLogger("deeperdarker").debug("Registering potions and brewing recipes");
    }
}
