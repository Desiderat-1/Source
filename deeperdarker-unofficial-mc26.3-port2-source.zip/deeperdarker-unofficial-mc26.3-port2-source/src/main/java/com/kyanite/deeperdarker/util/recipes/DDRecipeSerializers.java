// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.util.recipes;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.crafting.CustomRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import java.util.function.Supplier;

public final class DDRecipeSerializers {
    public static final RecipeSerializer<SculkTransmitterDyeRecipe> SCULK_TRANSMITTER_DYE = register("crafting_special_sculktransmitterdye", SculkTransmitterDyeRecipe::new);
    public static final RecipeSerializer<AcidResistantItemRecipe> ACID_RESISTANT_ITEM = register("crafting_special_acidresistantitem", AcidResistantItemRecipe::new);
    public static final RecipeSerializer<AugmentShieldRecipe> AUGMENT_SHIELD = register("crafting_special_augmentshield", AugmentShieldRecipe::new);
    public static final RecipeSerializer<RemoveHornsRecipe> REMOVE_HORNS = register("crafting_special_removehorns", RemoveHornsRecipe::new);
    public static final RecipeSerializer<AddHornsRecipe> ADD_HORNS = register("crafting_special_addhorns", AddHornsRecipe::new);
    private static <T extends CustomRecipe> RecipeSerializer<T> register(String id, Supplier<T> factory) {
        return Registry.register(BuiltInRegistries.RECIPE_SERIALIZER, Identifier.fromNamespaceAndPath("deeperdarker", id),
            new RecipeSerializer<>(MapCodec.unit(factory), StreamCodec.unit(factory.get())));
    }
    private DDRecipeSerializers() {}
    public static void init() {}
}
