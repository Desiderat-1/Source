// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.client.render;

import com.kyanite.deeperdarker.DeeperDarker;
import com.kyanite.deeperdarker.client.DDModelLayers;
import com.kyanite.deeperdarker.client.model.AcidSpriteModel;
import com.kyanite.deeperdarker.content.entities.acidsprite.AcidSprite;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;

@SuppressWarnings("NullableProblems")
public class AcidSpriteRenderer extends DDMobRenderer<AcidSprite, AcidSpriteModel<AcidSprite>> {
    private static final Identifier TEXTURE = Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "textures/entity/acid_sprite.png");

    public AcidSpriteRenderer(EntityRendererProvider.Context context) {
        super(context, new AcidSpriteModel<>(context.bakeLayer(DDModelLayers.ACID_SPRITE)), 0.25f);
    }

    @Override
    public Identifier getTextureLocation(AcidSprite entity) {
        return TEXTURE;
    }

    @Override
    protected int getBlockLightLevel(AcidSprite entity, BlockPos blockPos) {
        return 15;
    }
}
