// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.client.render;

import com.kyanite.deeperdarker.DeeperDarker;
import com.kyanite.deeperdarker.client.model.StalkerModel;
import com.kyanite.deeperdarker.content.entities.Stalker;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

@SuppressWarnings("NullableProblems")
public class StalkerRenderer extends DDMobRenderer<Stalker, StalkerModel> {
    public static final ModelLayerLocation MODEL = new ModelLayerLocation(Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "stalker"), "main");
    private static final Identifier TEXTURE = Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "textures/entity/stalker.png");

    public StalkerRenderer(EntityRendererProvider.Context pContext) {
        super(pContext, new StalkerModel(pContext.bakeLayer(MODEL)), 1);
    }

    @Override
    public Identifier getTextureLocation(Stalker pEntity) {
        return TEXTURE;
    }
}
