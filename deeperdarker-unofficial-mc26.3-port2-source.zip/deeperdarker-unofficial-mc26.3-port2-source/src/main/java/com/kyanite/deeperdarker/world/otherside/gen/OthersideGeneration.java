// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.world.otherside.gen;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.dimension.LevelStem;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
public final class OthersideGeneration {
    public static final ResourceKey<LevelStem> OTHERSIDE_STEM = ResourceKey.create(Registries.LEVEL_STEM, Identifier.fromNamespaceAndPath("deeperdarker", "otherside"));
    public static final ResourceKey<NoiseGeneratorSettings> OTHERSIDE_GENERATOR = ResourceKey.create(Registries.NOISE_SETTINGS, Identifier.fromNamespaceAndPath("deeperdarker", "otherside"));
    private OthersideGeneration() {}
}
