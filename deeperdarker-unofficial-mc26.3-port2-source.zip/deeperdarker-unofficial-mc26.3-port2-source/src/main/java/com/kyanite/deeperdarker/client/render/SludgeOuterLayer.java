// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.client.render;
import com.kyanite.deeperdarker.client.DDModelLayers;
import com.kyanite.deeperdarker.client.model.SludgeModel;
import com.kyanite.deeperdarker.client.state.DDModelRenderState;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.rendertype.RenderTypes;
public class SludgeOuterLayer extends RenderLayer<DDModelRenderState, SludgeModel> {
    private final SludgeModel model;
    public SludgeOuterLayer(RenderLayerParent<DDModelRenderState, SludgeModel> parent, EntityModelSet models) {
        super(parent); model = new SludgeModel(models.bakeLayer(DDModelLayers.SLUDGE_OUTER));
    }
    @Override public void submit(PoseStack poses, SubmitNodeCollector nodes, int light,
            DDModelRenderState state, float yaw, float pitch) {
        boolean outline = state.appearsGlowing() && state.isInvisible;
        if (state.isInvisible && !outline) return;
        var type = outline ? RenderTypes.outline(state.texture) : RenderTypes.entityTranslucent(state.texture);
        nodes.submitModel(model, state, poses, type, light,
                LivingEntityRenderer.getOverlayCoords(state, 0), 0xFFFFFFFF, null, state.outlineColor);
    }
}
