package com.kyanite.deeperdarker.client.state;

import net.minecraft.client.renderer.state.level.PlayerRenderState;
import org.jetbrains.annotations.Nullable;
public interface AcidOverlayState {
    @Nullable PlayerRenderState.WaterOverlay deeperdarker$acidOverlay();
    void deeperdarker$setAcidOverlay(@Nullable PlayerRenderState.WaterOverlay overlay);
}
