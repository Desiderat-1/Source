// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.util.datagen.loot;

import com.kyanite.deeperdarker.content.DDBlocks;
import com.kyanite.deeperdarker.content.DDItems;
import com.kyanite.deeperdarker.content.blocks.SculkBerryBlock;
import com.kyanite.deeperdarker.content.blocks.vegetation.GlowingVinesPlantBlock;
import com.kyanite.deeperdarker.content.blocks.vegetation.IceLilyBlock;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.advancements.predicates.BlockPredicate;
import net.minecraft.advancements.predicates.LocationPredicate;
import net.minecraft.advancements.predicates.StatePropertiesPredicate;
import net.minecraft.core.BlockPos;
import net.minecraft.data.loot.BlockLootSubProvider;
import net.minecraft.data.loot.packs.VanillaBlockLoot;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoublePlantBlock;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.entries.*;
import net.minecraft.world.level.storage.loot.functions.*;
import net.minecraft.world.level.storage.loot.predicates.BonusLevelTableCondition;
import net.minecraft.world.level.storage.loot.predicates.LocationCheck;
import net.minecraft.world.level.storage.loot.predicates.LootItemBlockStatePropertyCondition;
import net.minecraft.world.level.storage.loot.predicates.LootItemRandomChanceCondition;
import net.minecraft.world.level.storage.loot.providers.number.floats.ConstantValue;
import net.minecraft.world.level.storage.loot.providers.number.floats.UniformGenerator;

public class DDBlockLootTableProvider extends FabricBlockLootTableProvider {
    public DDBlockLootTableProvider(FabricDataOutput dataOutput) {
        super(dataOutput);
    }

    @Override
    public void generate() {
        dropSelf(DDBlocks.ENRICHED_ECHO_LOG);
        dropSelf(DDBlocks.ECHO_LOG);
        dropSelf(DDBlocks.ECHO_WOOD);
        dropSelf(DDBlocks.STRIPPED_ECHO_LOG);
        dropSelf(DDBlocks.STRIPPED_ECHO_WOOD);
        dropSelf(DDBlocks.ECHO_PLANKS);
        dropSelf(DDBlocks.ECHO_STAIRS);
        add(DDBlocks.ECHO_SLAB, this::createSlabItemTable);
        dropSelf(DDBlocks.ECHO_FENCE);
        dropSelf(DDBlocks.ECHO_FENCE_GATE);
        add(DDBlocks.ECHO_DOOR, this::createDoorTable);
        dropSelf(DDBlocks.ECHO_TRAPDOOR);
        dropSelf(DDBlocks.ECHO_PRESSURE_PLATE);
        dropSelf(DDBlocks.ECHO_BUTTON);
        add(DDBlocks.ECHO_LEAVES, (block) -> this.createLeavesDrops(block, DDBlocks.ECHO_SAPLING, NORMAL_LEAVES_SAPLING_CHANCES));
        dropSelf(DDBlocks.ECHO_SAPLING);
        dropSelf(DDBlocks.ECHO_SIGN);
        dropSelf(DDBlocks.ECHO_HANGING_SIGN);
        dropPottedContents(DDBlocks.POTTED_ECHO_SAPLING);
        dropPottedContents(DDBlocks.POTTED_BLOOMING_STEM);

        dropSelf(DDBlocks.BLOOMING_STEM);
        dropSelf(DDBlocks.STRIPPED_BLOOMING_STEM);
        dropSelf(DDBlocks.BLOOM_PLANKS);
        dropSelf(DDBlocks.BLOOM_STAIRS);
        dropSelf(DDBlocks.BLOOM_SLAB);
        dropSelf(DDBlocks.BLOOM_FENCE);
        dropSelf(DDBlocks.BLOOM_FENCE_GATE);
        add(DDBlocks.BLOOM_DOOR, this::createDoorTable);
        dropSelf(DDBlocks.BLOOM_TRAPDOOR);
        dropSelf(DDBlocks.BLOOM_PRESSURE_PLATE);
        dropSelf(DDBlocks.BLOOM_BUTTON);
        dropSelf(DDBlocks.BLOOM_SIGN);
        dropSelf(DDBlocks.BLOOM_HANGING_SIGN);

        dropSelf(DDBlocks.SCULK_SPRUCE_LOG);
        dropSelf(DDBlocks.SCULK_SPRUCE_WOOD);
        dropSelf(DDBlocks.STRIPPED_SCULK_SPRUCE_LOG);
        dropSelf(DDBlocks.STRIPPED_SCULK_SPRUCE_WOOD);
        dropSelf(DDBlocks.SCULK_SPRUCE_PLANKS);
        dropSelf(DDBlocks.SCULK_SPRUCE_STAIRS);
        add(DDBlocks.SCULK_SPRUCE_SLAB, this::createSlabItemTable);
        dropSelf(DDBlocks.SCULK_SPRUCE_FENCE);
        dropSelf(DDBlocks.SCULK_SPRUCE_FENCE_GATE);
        add(DDBlocks.SCULK_SPRUCE_DOOR, this::createDoorTable);
        dropSelf(DDBlocks.SCULK_SPRUCE_TRAPDOOR);
        dropSelf(DDBlocks.SCULK_SPRUCE_PRESSURE_PLATE);
        dropSelf(DDBlocks.SCULK_SPRUCE_BUTTON);
        add(DDBlocks.SCULK_SPRUCE_LEAVES, (block) -> this.createLeavesDrops(block, DDBlocks.SCULK_SPRUCE_SAPLING, NORMAL_LEAVES_SAPLING_CHANCES));
        dropSelf(DDBlocks.SCULK_SPRUCE_SAPLING);
        dropSelf(DDBlocks.SCULK_SPRUCE_SIGN);
        dropSelf(DDBlocks.SCULK_SPRUCE_HANGING_SIGN);
        dropPottedContents(DDBlocks.POTTED_SCULK_SPRUCE_SAPLING);

        add(DDBlocks.SCULK_STONE, (block) -> this.createSingleItemTableWithSilkTouch(block, DDBlocks.COBBLED_SCULK_STONE));
        dropSelf(DDBlocks.SCULK_STONE_STAIRS);
        add(DDBlocks.SCULK_STONE_SLAB, this::createSlabItemTable);
        dropSelf(DDBlocks.SCULK_STONE_WALL);
        dropSelf(DDBlocks.COBBLED_SCULK_STONE);
        dropSelf(DDBlocks.COBBLED_SCULK_STONE_STAIRS);
        add(DDBlocks.COBBLED_SCULK_STONE_SLAB, this::createSlabItemTable);
        dropSelf(DDBlocks.COBBLED_SCULK_STONE_WALL);
        dropSelf(DDBlocks.POLISHED_SCULK_STONE);
        dropSelf(DDBlocks.POLISHED_SCULK_STONE_STAIRS);
        add(DDBlocks.POLISHED_SCULK_STONE_SLAB, this::createSlabItemTable);
        dropSelf(DDBlocks.POLISHED_SCULK_STONE_WALL);
        dropSelf(DDBlocks.SCULK_STONE_BRICKS);
        dropSelf(DDBlocks.SCULK_STONE_BRICK_STAIRS);
        add(DDBlocks.SCULK_STONE_BRICK_SLAB, this::createSlabItemTable);
        dropSelf(DDBlocks.SCULK_STONE_BRICK_WALL);
        dropSelf(DDBlocks.SCULK_STONE_TILES);
        dropSelf(DDBlocks.SCULK_STONE_TILE_STAIRS);
        add(DDBlocks.SCULK_STONE_TILE_SLAB, this::createSlabItemTable);
        dropSelf(DDBlocks.SCULK_STONE_TILE_WALL);
        dropSelf(DDBlocks.SMOOTH_SCULK_STONE);
        dropSelf(DDBlocks.SMOOTH_SCULK_STONE_STAIRS);
        add(DDBlocks.SMOOTH_SCULK_STONE_SLAB, this::createSlabItemTable);
        dropSelf(DDBlocks.SMOOTH_SCULK_STONE_WALL);
        dropSelf(DDBlocks.CUT_SCULK_STONE);
        dropSelf(DDBlocks.CUT_SCULK_STONE_STAIRS);
        add(DDBlocks.CUT_SCULK_STONE_SLAB, this::createSlabItemTable);
        dropSelf(DDBlocks.CUT_SCULK_STONE_WALL);
        dropSelf(DDBlocks.CHISELED_SCULK_STONE);

        add(DDBlocks.SCULK_FERN, BlockLootSubProvider::createShearsOnlyDrop);
        add(DDBlocks.LARGE_SCULK_FERN, (block) -> createDoublePlantWithoutSeedDrops(block, DDBlocks.SCULK_FERN));

        add(DDBlocks.SCULK_GRIME, (block) -> this.createSingleItemTableWithSilkTouch(block, DDItems.GRIME_BALL, UniformGenerator.between(2, 4)));
        dropSelf(DDBlocks.SCULK_GRIME_BRICKS);
        dropSelf(DDBlocks.SCULK_GRIME_BRICK_STAIRS);
        add(DDBlocks.SCULK_GRIME_BRICK_SLAB, this::createSlabItemTable);
        dropSelf(DDBlocks.SCULK_GRIME_BRICK_WALL);
        dropSelf(DDBlocks.FORTIFIED_SCULK_GRIME_BRICKS);
        dropWhenSilkTouch(DDBlocks.PROTECTED_SCULK_GRIME_GLASS);
        dropWhenSilkTouch(DDBlocks.SCULK_GRIME_GLASS);
        dropWhenSilkTouch(DDBlocks.SCULK_GRIME_GLASS_PANE);

        dropSelf(DDBlocks.SCULK_PERMAFROST);
        add(DDBlocks.SNOWY_SCULK_PERMAFROST, (block) -> this.createSingleItemTableWithSilkTouch(block, DDBlocks.SCULK_PERMAFROST));
        dropOther(DDBlocks.SCULK_TUBERS, DDItems.SCULK_TUBER);
        dropWhenSilkTouch(DDBlocks.ICICLE);

        add(DDBlocks.BLOOMING_SCULK_STONE, (block) -> this.createSingleItemTableWithSilkTouch(block, DDBlocks.COBBLED_SCULK_STONE));
        dropSelf(DDBlocks.BLOOMING_MOSS_BLOCK);

        LootItemBlockStatePropertyCondition.Builder builder = LootItemBlockStatePropertyCondition.hasBlockStateProperties(DDBlocks.SCULK_BERRY).setProperties(StatePropertiesPredicate.Builder.properties().hasProperty(SculkBerryBlock.AGE, 2));
        add(DDBlocks.SCULK_BERRY, createCropDrops(DDBlocks.SCULK_BERRY, DDItems.SCULK_BERRY, DDItems.SCULK_BERRY_SPROUT, builder));

        add(DDBlocks.GLOOMSLATE, (block) -> this.createSingleItemTableWithSilkTouch(block, DDBlocks.COBBLED_GLOOMSLATE));
        dropSelf(DDBlocks.GLOOMSLATE_STAIRS);
        add(DDBlocks.GLOOMSLATE_SLAB, this::createSlabItemTable);
        dropSelf(DDBlocks.GLOOMSLATE_WALL);
        dropSelf(DDBlocks.COBBLED_GLOOMSLATE);
        dropSelf(DDBlocks.COBBLED_GLOOMSLATE_STAIRS);
        add(DDBlocks.COBBLED_GLOOMSLATE_SLAB, this::createSlabItemTable);
        dropSelf(DDBlocks.COBBLED_GLOOMSLATE_WALL);
        dropSelf(DDBlocks.POLISHED_GLOOMSLATE);
        dropSelf(DDBlocks.POLISHED_GLOOMSLATE_STAIRS);
        add(DDBlocks.POLISHED_GLOOMSLATE_SLAB, this::createSlabItemTable);
        dropSelf(DDBlocks.POLISHED_GLOOMSLATE_WALL);
        dropSelf(DDBlocks.GLOOMSLATE_BRICKS);
        dropSelf(DDBlocks.GLOOMSLATE_BRICK_STAIRS);
        add(DDBlocks.GLOOMSLATE_BRICK_SLAB, this::createSlabItemTable);
        dropSelf(DDBlocks.GLOOMSLATE_BRICK_WALL);
        dropSelf(DDBlocks.GLOOMSLATE_TILES);
        dropSelf(DDBlocks.GLOOMSLATE_TILE_STAIRS);
        add(DDBlocks.GLOOMSLATE_TILE_SLAB, this::createSlabItemTable);
        dropSelf(DDBlocks.GLOOMSLATE_TILE_WALL);
        dropSelf(DDBlocks.SMOOTH_GLOOMSLATE);
        dropSelf(DDBlocks.SMOOTH_GLOOMSLATE_STAIRS);
        add(DDBlocks.SMOOTH_GLOOMSLATE_SLAB, this::createSlabItemTable);
        dropSelf(DDBlocks.SMOOTH_GLOOMSLATE_WALL);
        dropSelf(DDBlocks.CUT_GLOOMSLATE);
        dropSelf(DDBlocks.CUT_GLOOMSLATE_STAIRS);
        add(DDBlocks.CUT_GLOOMSLATE_SLAB, this::createSlabItemTable);
        dropSelf(DDBlocks.CUT_GLOOMSLATE_WALL);
        dropSelf(DDBlocks.CHISELED_GLOOMSLATE);
        dropSelf(DDBlocks.GLOOMSLATE_BARRIER);
        dropSelf(DDBlocks.FORTIFIED_CUT_GLOOMSLATE);

        dropSelf(DDBlocks.ECHO_SOIL);
        dropOther(DDBlocks.ECHO_FARMLAND, DDBlocks.ECHO_SOIL);
        dropWhenSilkTouch(DDBlocks.GLOOMY_SCULK);
        dropWhenSilkTouch(DDBlocks.CRYSTALLIZED_AMBER);
        dropSelf(DDBlocks.SCULK_GLEAM);
        dropWhenSilkTouch(DDBlocks.SCULK_JAW);

        add(DDBlocks.SCULK_STONE_COAL_ORE, (block) -> this.createOreDrop(block, Items.COAL));
        add(DDBlocks.SCULK_STONE_IRON_ORE, (block) -> this.createOreDrop(block, Items.RAW_IRON));
        add(DDBlocks.SCULK_STONE_COPPER_ORE, this::createCopperOreDrops);
        add(DDBlocks.SCULK_STONE_GOLD_ORE, (block) -> this.createOreDrop(block, Items.RAW_GOLD));
        add(DDBlocks.SCULK_STONE_REDSTONE_ORE, this::createRedstoneOreDrops);
        add(DDBlocks.SCULK_STONE_EMERALD_ORE, (block) -> this.createOreDrop(block, Items.EMERALD));
        add(DDBlocks.SCULK_STONE_LAPIS_ORE, this::createLapisOreDrops);
        add(DDBlocks.SCULK_STONE_DIAMOND_ORE, (block) -> this.createOreDrop(block, Items.DIAMOND));
        add(DDBlocks.SCULK_STONE_LEAD_ORE, (block) -> this.createOreDrop(block, DDItems.RAW_LEAD));
        add(DDBlocks.GLOOMSLATE_COAL_ORE, (block) -> this.createOreDrop(block, Items.COAL));
        add(DDBlocks.GLOOMSLATE_IRON_ORE, (block) -> this.createOreDrop(block, Items.RAW_IRON));
        add(DDBlocks.GLOOMSLATE_COPPER_ORE, this::createCopperOreDrops);
        add(DDBlocks.GLOOMSLATE_GOLD_ORE, (block) -> this.createOreDrop(block, Items.RAW_GOLD));
        add(DDBlocks.GLOOMSLATE_REDSTONE_ORE, this::createRedstoneOreDrops);
        add(DDBlocks.GLOOMSLATE_EMERALD_ORE, (block) -> this.createOreDrop(block, Items.EMERALD));
        add(DDBlocks.GLOOMSLATE_LAPIS_ORE, this::createLapisOreDrops);
        add(DDBlocks.GLOOMSLATE_DIAMOND_ORE, (block) -> this.createOreDrop(block, Items.DIAMOND));

        dropSelf(DDBlocks.RAW_LEAD_BLOCK);
        dropSelf(DDBlocks.LEAD_BLOCK);

        add(DDBlocks.GLOOMY_GRASS, BlockLootSubProvider::createShearsOnlyDrop);
        add(DDBlocks.GLOWING_GRASS, BlockLootSubProvider::createShearsOnlyDrop);
        dropSelf(DDBlocks.GLOOMY_CACTUS);
        dropWhenSilkTouch(DDBlocks.GLOOMY_GEYSER);
        addVineAndPlant(DDBlocks.SCULK_TENDRILS_PLANT, DDBlocks.SCULK_TENDRILS);
        addVineAndPlant(DDBlocks.SCULK_VINES_PLANT, DDBlocks.SCULK_VINES);
        addVineAndPlant(DDBlocks.GLOWING_ROOTS_PLANT, DDBlocks.GLOWING_ROOTS);
        add(DDBlocks.GLOWING_VINES_PLANT, this::glowingVinesDrop);
        dropSelf(DDBlocks.ICE_LILY);
        add(DDBlocks.ICE_LILY, this::iceLilyDrop);
        dropSelf(DDBlocks.LILY_FLOWER);
        dropSelf(DDBlocks.GLOWING_FLOWERS);
        dropSelf(DDBlocks.SHATTERED_HEAD);

        ancientVaseDrop();

        otherWhenSilkTouch(DDBlocks.INFESTED_SCULK, Blocks.SCULK);

        dropSelf(DDBlocks.SOUNDPROOF_GLASS);
        dropSelf(DDBlocks.SCULK_LAMP);
        dropWhenSilkTouch(DDBlocks.PROTECTED_SCULK_GLEAM);
        dropSelf(DDBlocks.SCULK_TISSUE);
        dropSelf(DDBlocks.SCULK_TISSUE_BRICKS);
        dropSelf(DDBlocks.SCULK_TISSUE_BRICK_STAIRS);
        add(DDBlocks.SCULK_TISSUE_BRICK_SLAB, this::createSlabItemTable);
        dropSelf(DDBlocks.SCULK_TISSUE_BRICK_WALL);
        dropOther(DDBlocks.DARK_FOUNTAIN, DDItems.SHADOW_CRYSTAL);
        dropSelf(DDBlocks.SHADOW_CRYSTAL_BLOCK);

        dropSelf(DDBlocks.SCULK_BASALT);
        dropSelf(DDBlocks.FIZZ_BLOCK);
        dropSelf(DDBlocks.RADIOACTIVE_BLOCK);

        dropSelf(DDBlocks.RED_CRYSTAL_BLOCK);
        dropSelf(DDBlocks.GREEN_CRYSTAL_BLOCK);
        dropSelf(DDBlocks.BLUE_CRYSTAL_BLOCK);

        dropSelf(DDBlocks.SCULK_TORCH);
        add(DDBlocks.SCULK_CAMPFIRE, (block) -> VanillaBlockLoot.createSilkTouchDispatchTable(block, this.applyExplosionCondition(block, LootItem.lootTableItem(Items.SOUL_SOIL).apply(SetItemCountFunction.setCount(ConstantValue.exactly(1.0f))))));
        dropSelf(DDBlocks.SCULK_LANTERN);

        dropSelf(DDBlocks.PATIENCE_SOUL_FIRE);
        dropSelf(DDBlocks.FORTITUDE_SOUL_FIRE);
        dropSelf(DDBlocks.CORRUPTION_SOUL_FIRE);
        dropSelf(DDBlocks.PURITY_SOUL_FIRE);
        dropSelf(DDBlocks.VIRTUE_SOUL_FIRE);

        dropSelf(DDBlocks.DEAD_MANS_CHEST);
    }

    public LootTable.Builder createDoublePlantWithoutSeedDrops(Block largePlant, Block plant) {
        LootPoolEntryContainer.Builder<?> builder = LootItem.lootTableItem(plant).apply(SetItemCountFunction.setCount(ConstantValue.exactly(2.0f))).when(HAS_SHEARS);
        return LootTable.lootTable().withPool(LootPool.lootPool().add(builder).when(LootItemBlockStatePropertyCondition.hasBlockStateProperties(largePlant).setProperties(StatePropertiesPredicate.Builder.properties().hasProperty(DoublePlantBlock.HALF, DoubleBlockHalf.LOWER))).when(LocationCheck.checkLocation(LocationPredicate.Builder.location().setBlock(BlockPredicate.Builder.block().of(largePlant).setProperties(StatePropertiesPredicate.Builder.properties().hasProperty(DoublePlantBlock.HALF, DoubleBlockHalf.UPPER).build()).build()), new BlockPos(0, 1, 0)))).withPool(LootPool.lootPool().add(builder).when(LootItemBlockStatePropertyCondition.hasBlockStateProperties(largePlant).setProperties(StatePropertiesPredicate.Builder.properties().hasProperty(DoublePlantBlock.HALF, DoubleBlockHalf.UPPER))).when(LocationCheck.checkLocation(LocationPredicate.Builder.location().setBlock(BlockPredicate.Builder.block().of(largePlant).setProperties(StatePropertiesPredicate.Builder.properties().hasProperty(DoublePlantBlock.HALF, DoubleBlockHalf.LOWER).build()).build()), new BlockPos(0, -1, 0))));
    }

    private void addVineAndPlant(Block plant, Block vine) {
        LootTable.Builder builder = createSilkTouchOrShearsDispatchTable(vine, LootItem.lootTableItem(vine).when(BonusLevelTableCondition.bonusLevelFlatChance(Enchantments.BLOCK_FORTUNE, 0.33f, 0.55f, 0.77f, 1.0f)));
        add(plant, builder);
        add(vine, builder);
    }

    private LootTable.Builder glowingVinesDrop(Block block) {
        return LootTable.lootTable().withPool(LootPool.lootPool().add(LootItem.lootTableItem(DDItems.BLOOM_BERRIES)).when(LootItemBlockStatePropertyCondition.hasBlockStateProperties(block).setProperties(StatePropertiesPredicate.Builder.properties().hasProperty(GlowingVinesPlantBlock.BERRIES, true))));
    }

    private void ancientVaseDrop() {
        add(DDBlocks.ANCIENT_VASE, LootTable.lootTable().withPool(LootPool.lootPool().when(HAS_SILK_TOUCH).setRolls(ConstantValue.exactly(1)).add(LootItem.lootTableItem(DDBlocks.ANCIENT_VASE))).withPool(LootPool.lootPool().when(HAS_NO_SILK_TOUCH).setRolls(UniformGenerator.between(1, 3)).add(EmptyLootItem.emptyItem().setWeight(20)).add(LootItem.lootTableItem(Blocks.SAND).setWeight(11).apply(SetItemCountFunction.setCount(UniformGenerator.between(1, 6)))).add(LootItem.lootTableItem(Items.STRING).setWeight(10).apply(SetItemCountFunction.setCount(UniformGenerator.between(3, 9)))).add(LootItem.lootTableItem(Items.ROTTEN_FLESH).setWeight(9).apply(SetItemCountFunction.setCount(UniformGenerator.between(5, 8)))).add(LootItem.lootTableItem(Items.GOLD_INGOT).setWeight(6).apply(SetItemCountFunction.setCount(UniformGenerator.between(1, 5)))).add(LootItem.lootTableItem(Items.IRON_INGOT).setWeight(5).apply(SetItemCountFunction.setCount(UniformGenerator.between(2, 8)))).add(LootItem.lootTableItem(Items.GOLDEN_APPLE).setWeight(4).apply(SetItemCountFunction.setCount(UniformGenerator.between(1, 2)))).add(LootItem.lootTableItem(Items.EMERALD).setWeight(3).apply(SetItemCountFunction.setCount(UniformGenerator.between(1, 3)))).add(LootItem.lootTableItem(Items.DIAMOND).setWeight(2).apply(SetItemCountFunction.setCount(UniformGenerator.between(1, 2)))).add(LootItem.lootTableItem(Items.BOOK).setWeight(2).apply(EnchantRandomlyFunction.randomApplicableEnchantment())).add(LootItem.lootTableItem(Items.ENCHANTED_GOLDEN_APPLE).setWeight(1)).add(LootItem.lootTableItem(DDItems.WARDEN_CARAPACE).setWeight(1))).withPool(LootPool.lootPool().when(HAS_NO_SILK_TOUCH).setRolls(ConstantValue.exactly(2)).add(LootItem.lootTableItem(Blocks.COBWEB).setWeight(13).apply(SetItemCountFunction.setCount(UniformGenerator.between(1, 2)))).add(LootItem.lootTableItem(Items.REDSTONE).setWeight(7).apply(SetItemCountFunction.setCount(UniformGenerator.between(3, 6)))).add(LootItem.lootTableItem(Items.STICK).setWeight(7).apply(SetItemCountFunction.setCount(UniformGenerator.between(1, 2)))).add(LootItem.lootTableItem(Items.ROTTEN_FLESH).setWeight(5).apply(SetItemCountFunction.setCount(UniformGenerator.between(1, 4)))).add(LootItem.lootTableItem(Items.STRING).setWeight(5).apply(SetItemCountFunction.setCount(UniformGenerator.between(1, 4)))).add(LootItem.lootTableItem(Items.LAPIS_LAZULI).setWeight(4).apply(SetItemCountFunction.setCount(UniformGenerator.between(5, 6)))).add(LootItem.lootTableItem(Blocks.SAND).setWeight(3).apply(SetItemCountFunction.setCount(UniformGenerator.between(1, 2))))));
    }

    private LootTable.Builder iceLilyDrop(Block block) {
        CompoundTag noFlower = new CompoundTag();
        noFlower.putBoolean("has_flower", false);
//        CompoundTag flower = new CompoundTag();
//        flower.putBoolean("has_flower", true);
        return LootTable.lootTable().withPool(
                LootPool.lootPool().setRolls(ConstantValue.exactly(1.0f))
                        .add(LootItem.lootTableItem(DDItems.ICE_LILY)
                                .apply(SetNbtFunction.setTag(noFlower).when(LootItemBlockStatePropertyCondition.hasBlockStateProperties(block).setProperties(StatePropertiesPredicate.Builder.properties().hasProperty(IceLilyBlock.HAS_FLOWER, false))))
                        ));
    }
}