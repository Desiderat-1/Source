package com.kyanite.deeperdarker.mixin;

import com.kyanite.deeperdarker.content.fluids.EntityInAcid;
import com.kyanite.deeperdarker.util.DDTags;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.wrapoperation.*;
import net.minecraft.tags.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.level.material.*;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntity.class)
public abstract class AcidLivingEntityMixin {
    @Shadow public abstract boolean isAffectedByFluids();
    @Shadow protected abstract double getEffectiveGravity();
    @Unique private boolean deeperdarker$inAcid(){return ((EntityInAcid)this).deeperdarker$isInAcid();}

    @WrapOperation(method="aiStep",at=@At(value="INVOKE",target="Lnet/minecraft/world/entity/LivingEntity;isInLava()Z"))
    private boolean deeperdarker$enableAcidJumping(LivingEntity entity,Operation<Boolean> original){return original.call(entity)||deeperdarker$inAcid();}
    @WrapOperation(method="aiStep",at=@At(value="INVOKE",target="Lnet/minecraft/world/entity/LivingEntity;getFluidHeight(Lnet/minecraft/tags/TagKey;)D"))
    private double deeperdarker$acidJumpDepth(LivingEntity entity,TagKey<Fluid> fluid,Operation<Double> original){
        return fluid==FluidTags.LAVA&&deeperdarker$inAcid()?entity.getFluidHeight(DDTags.Fluids.ACID):original.call(entity,fluid);
    }
    @ModifyReturnValue(method="shouldTravelInFluid",at=@At("RETURN"))
    private boolean deeperdarker$travelInAcid(boolean original,FluidState fluid){
        return original||(deeperdarker$inAcid()&&isAffectedByFluids()&&!((LivingEntity)(Object)this).canStandOnFluid(fluid));
    }
    @Inject(method="travelInFluid",at=@At("HEAD"),cancellable=true)
    private void deeperdarker$acidMovement(Vec3 input,CallbackInfo ci){
        if(!deeperdarker$inAcid())return;
        LivingEntity entity=(LivingEntity)(Object)this;
        double gravity=getEffectiveGravity(),oldY=entity.getY();boolean falling=entity.getDeltaMovement().y<=0;
        entity.moveRelative(0.02F,input);entity.move(MoverType.SELF,entity.getDeltaMovement());
        if(entity.getFluidHeight(DDTags.Fluids.ACID)<=entity.getFluidJumpThreshold()){
            entity.setDeltaMovement(entity.getDeltaMovement().multiply(0.6,0.9,0.6));
            entity.setDeltaMovement(entity.getFluidFallingAdjustedMovement(gravity,falling,entity.getDeltaMovement()));
        } else entity.setDeltaMovement(entity.getDeltaMovement().scale(0.5));
        if(!entity.isNoGravity())entity.setDeltaMovement(entity.getDeltaMovement().add(0,-gravity/4,0));
        Vec3 movement=entity.getDeltaMovement();
        if(entity.horizontalCollision&&entity.isFree(movement.x,movement.y+0.6-entity.getY()+oldY,movement.z))
            entity.setDeltaMovement(movement.x,0.3,movement.z);
        ci.cancel();
    }
}
