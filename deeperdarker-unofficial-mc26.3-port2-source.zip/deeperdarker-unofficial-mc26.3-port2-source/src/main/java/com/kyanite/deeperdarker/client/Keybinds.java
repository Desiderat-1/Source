// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.slf4j.LoggerFactory;

public final class Keybinds {
    public static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("deeperdarker", "main"));
    public static final KeyMapping BOOST = register("boost", InputConstants.KEY_B);
    public static final KeyMapping TRANSMIT = register("transmit", InputConstants.KEY_V);

    private static KeyMapping register(String id, int key) {
        return KeyMappingHelper.registerKeyMapping(new KeyMapping("key.deeperdarker." + id, InputConstants.Type.KEYBOARD, key, CATEGORY));
    }
    public static void init() { LoggerFactory.getLogger("deeperdarker").debug("Registering key mappings"); }
}
