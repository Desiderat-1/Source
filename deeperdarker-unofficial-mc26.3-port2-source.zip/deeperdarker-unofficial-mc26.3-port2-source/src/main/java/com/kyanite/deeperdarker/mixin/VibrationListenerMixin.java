// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.mixin;

import com.kyanite.deeperdarker.content.DDEffects;
import com.kyanite.deeperdarker.content.entities.DDMobType;
import com.kyanite.deeperdarker.util.DDTags;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.level.gameevent.vibrations.VibrationSystem;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(VibrationSystem.Listener.class)
public abstract class VibrationListenerMixin {
    @Inject(method = "handleGameEvent", at = @At("HEAD"), cancellable = true)
    public void handleGameEvent(ServerLevel level, net.minecraft.core.Holder<GameEvent> event, GameEvent.Context context, Vec3 vec3, CallbackInfoReturnable<Boolean> cir) {
        if(context.sourceEntity() instanceof LivingEntity entity) {
            if(event.is(DDTags.GameEvents.FEET_VIBRATIONS) && hasArmorThatDampensVibrations(entity)) cir.setReturnValue(false);
            if(entity.hasEffect(DDEffects.SCULK_AFFINITY)) cir.setReturnValue(false);
            if(DDMobType.isSculk(entity)) cir.setReturnValue(false);
        }
    }

    @Unique
    private boolean hasArmorThatDampensVibrations(LivingEntity entity) {
        for (ItemStack itemStack : com.kyanite.deeperdarker.util.DDArmorSlots.of(entity)) {
            if (itemStack.is(DDTags.Items.DAMPENS_VIBRATIONS)) {
                return true;
            }
        }
        return false;
    }
}
