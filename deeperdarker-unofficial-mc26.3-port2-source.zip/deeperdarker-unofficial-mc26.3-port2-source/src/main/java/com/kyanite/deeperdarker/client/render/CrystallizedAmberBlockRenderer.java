// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.client.render;
import com.kyanite.deeperdarker.client.model.SculkLeechModel;
import com.kyanite.deeperdarker.content.blocks.CrystallizedAmberBlock;
import com.kyanite.deeperdarker.content.entities.blocks.CrystallizedAmberBlockEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer;
import net.minecraft.client.renderer.item.ItemModelResolver;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.phys.Vec3;
public class CrystallizedAmberBlockRenderer implements BlockEntityRenderer<CrystallizedAmberBlockEntity, CrystallizedAmberBlockRenderer.State> {
    private static final Identifier LEECH_TEXTURE = Identifier.fromNamespaceAndPath("deeperdarker", "textures/entity/sculk_leech.png");
    private final ItemModelResolver itemResolver;
    private final SculkLeechModel leech;
    public static final class State extends BlockEntityRenderState {
        public boolean fossilized, containsLeech;
        public float rotation;
        public final ItemStackRenderState item = new ItemStackRenderState();
        public final LivingEntityRenderState leech = new LivingEntityRenderState();
    }
    public CrystallizedAmberBlockRenderer(BlockEntityRendererProvider.Context context) {
        itemResolver = context.itemModelResolver();
        leech = new SculkLeechModel(context.bakeLayer(SculkLeechRenderer.MODEL));
    }
    @Override public State createRenderState() { return new State(); }
    @Override public void extractRenderState(CrystallizedAmberBlockEntity entity, State state, float partialTick, Vec3 camera, ModelFeatureRenderer.CrumblingOverlay breaking) {
        BlockEntityRenderer.super.extractRenderState(entity, state, partialTick, camera, breaking);
        state.fossilized = entity.getBlockState().getValue(CrystallizedAmberBlock.FOSSILIZED);
        state.containsLeech = entity.fossilizedEntity;
        state.rotation = entity.rotation;
        itemResolver.updateForTopItem(state.item, entity.getLoot(), ItemDisplayContext.FIXED, entity.getLevel(), null, 0);
    }
    @Override public void submit(State state, PoseStack poses, SubmitNodeCollector nodes, CameraRenderState camera) {
        if (!state.fossilized) return;
        poses.pushPose(); poses.translate(0.5F, 0.5F, 0.5F);
        poses.rotateDegrees(Axis.XP, -40); poses.rotateDegrees(Axis.YP, state.rotation);
        if (state.containsLeech) {
            poses.scale(0.9F, 0.9F, 0.9F);
            poses.rotateDegrees(Axis.YP, 180); poses.scale(-1, -1, 1); poses.translate(0, -1.501F, 0);
            nodes.submitModel(leech, state.leech, poses, leech.renderType(LEECH_TEXTURE), state.lightCoords, OverlayTexture.NO_OVERLAY, 0xFFFFFFFF);
        } else {
            poses.scale(0.6F, 0.6F, 0.6F);
            state.item.submit(poses, nodes, state.lightCoords, OverlayTexture.NO_OVERLAY, 0);
        }
        poses.popPose();
    }
}
