package com.kyanite.deeperdarker.client.render;

import com.kyanite.deeperdarker.client.state.DDChestRenderState;
import com.kyanite.deeperdarker.content.entities.blocks.DeadMansChestBlockEntity;
import net.minecraft.client.renderer.blockentity.*;

/** Native chest geometry, paired-block lighting and lid animation, with our own atlas sprites. */
public final class DeadMansChestRenderer extends ChestRenderer<DeadMansChestBlockEntity> {
    public DeadMansChestRenderer(BlockEntityRendererProvider.Context context){super(context);}
    @Override public DDChestRenderState createRenderState(){return new DDChestRenderState();}
}
