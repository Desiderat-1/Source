// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.content;

import com.mojang.serialization.Codec;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtAccounter;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtOps;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.datafix.DataFixers;
import net.minecraft.util.datafix.DataFixTypes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;
import net.minecraft.world.level.storage.LevelResource;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

/** The recovery pool stores independent stacks and migrates the old world data without altering it. */
public class DeadMansChestSavedData extends SavedData {
    public static final String ID = "deeperdarker_dead_mans_chest";
    public static final Codec<DeadMansChestSavedData> CODEC = ItemStack.CODEC.listOf()
            .optionalFieldOf("stacks", List.of()).codec().xmap(DeadMansChestSavedData::new, data -> data.list);
    public static final SavedDataType<DeadMansChestSavedData> TYPE = new SavedDataType<>(
            Identifier.fromNamespaceAndPath("deeperdarker", "dead_mans_chest"), DeadMansChestSavedData::new, CODEC, null);
    private final ArrayList<ItemStack> list;

    public DeadMansChestSavedData() { this(List.of()); }
    private DeadMansChestSavedData(List<ItemStack> stacks) {
        list = new ArrayList<>(stacks.stream().map(ItemStack::copy).toList());
    }

    public static DeadMansChestSavedData get(MinecraftServer server, boolean create) {
        var storage = server.overworld().getDataStorage();
        DeadMansChestSavedData current = storage.get(TYPE);
        if (current != null) return current;
        var oldFile = server.getWorldPath(LevelResource.ROOT).resolve("data").resolve(ID + ".dat");
        if (Files.exists(oldFile)) {
            try {
                current = readLegacy(oldFile, server.registryAccess());
                storage.set(TYPE, current);
                current.setDirty();
                return current;
            } catch (IOException e) { throw new IllegalStateException("Cannot migrate recovery pool " + oldFile, e); }
        }
        return create ? storage.computeIfAbsent(TYPE) : null;
    }

    static DeadMansChestSavedData readLegacy(java.nio.file.Path oldFile, net.minecraft.core.HolderLookup.Provider registries) throws IOException {
        CompoundTag root = NbtIo.readCompressed(oldFile, NbtAccounter.create(64L * 1024 * 1024));
        CompoundTag payload = root.getCompoundOrEmpty("data").copy();
        var fixed = new net.minecraft.nbt.ListTag();
        int version = root.getIntOr("DataVersion", 3465); // Original target: Minecraft 1.20.1.
        for (var tag : payload.getListOrEmpty("stacks")) {
            if (!(tag instanceof CompoundTag stack)) throw new IllegalStateException("Invalid saved item stack in " + oldFile);
            fixed.add(DataFixers.getDataFixer().update(net.minecraft.util.datafix.fixes.References.ITEM_STACK,
                    new com.mojang.serialization.Dynamic<>(NbtOps.INSTANCE, stack.copy()), version,
                    net.minecraft.SharedConstants.getCurrentVersion().dataVersion().version()).getValue());
        }
        payload.put("stacks", fixed);
        return CODEC.parse(registries.createSerializationContext(NbtOps.INSTANCE), payload).getOrThrow();
    }

    public ArrayList<ItemStack> getList() { return list; }

    public void add(ItemStack original) {
        if (original.isEmpty()) return;
        ItemStack remaining = original.copy();
        if (remaining.isStackable()) {
            for (ItemStack existing : list) {
                if (!ItemStack.isSameItemSameComponents(remaining, existing)) continue;
                int moved = Math.min(remaining.getCount(), existing.getMaxStackSize() - existing.getCount());
                if (moved <= 0) continue;
                existing.grow(moved);
                remaining.shrink(moved);
                if (remaining.isEmpty()) { setDirty(); return; }
            }
        }
        list.add(remaining);
        setDirty();
    }
}
