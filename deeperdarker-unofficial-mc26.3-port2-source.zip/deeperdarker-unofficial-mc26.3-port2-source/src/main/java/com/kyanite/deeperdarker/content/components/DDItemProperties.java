// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.content.components;

import com.kyanite.deeperdarker.util.DDTags;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;

/** Typed item flags with read compatibility for the alpha's custom-data fields. */
public final class DDItemProperties {
    private DDItemProperties() {}
    private static boolean read(ItemStack stack, DataComponentType<Boolean> component, String key, boolean fallback) {
        Boolean value = stack.get(component);
        return value != null ? value : stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getBooleanOr(key, fallback);
    }
    private static void write(ItemStack stack, DataComponentType<Boolean> component, String key, boolean value) {
        stack.set(component, value);
        CustomData.update(DataComponents.CUSTOM_DATA, stack, tag -> tag.remove(key));
    }
    public static boolean hasHorns(ItemStack stack) { return read(stack, DDDataComponents.HAS_HORNS, "deeperdarker:has_horns", true); }
    public static void setHasHorns(ItemStack stack, boolean value) { write(stack, DDDataComponents.HAS_HORNS, "deeperdarker:has_horns", value); }
    public static boolean isAcidResistant(ItemStack stack) { return stack.is(DDTags.Items.ACID_RESISTANT) || read(stack, DDDataComponents.ACID_RESISTANT, "deeperdarker:acid_resistant", false); }
    public static void setAcidResistant(ItemStack stack) { write(stack, DDDataComponents.ACID_RESISTANT, "deeperdarker:acid_resistant", true); }
    public static boolean isAugmented(ItemStack stack) { return read(stack, DDDataComponents.AUGMENTED, "deeperdarker:augmented", false); }
    public static void setAugmented(ItemStack stack) { write(stack, DDDataComponents.AUGMENTED, "deeperdarker:augmented", true); }
    public static boolean isReinvoked(ItemStack stack) { return read(stack, DDDataComponents.REINVOKED, "reinvoked", false); }
    public static void setReinvoked(ItemStack stack, boolean value) { write(stack, DDDataComponents.REINVOKED, "reinvoked", value); }
}
