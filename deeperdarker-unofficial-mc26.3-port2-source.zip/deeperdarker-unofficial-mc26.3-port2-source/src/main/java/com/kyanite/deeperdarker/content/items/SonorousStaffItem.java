// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.content.items;

import com.kyanite.deeperdarker.content.DDSounds;
import com.kyanite.deeperdarker.util.DDSettings;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.stats.Stats;
import net.minecraft.tags.TagKey;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUseAnimation;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class SonorousStaffItem extends Item {
    public double dropOffFactor = 1 / 3.0;
    public SonorousStaffItem(Properties properties) {
        super(properties.repairable(TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("deeperdarker", "repairs_sonorous_staff"))));
    }
    @Override public boolean releaseUsing(ItemStack stack, Level level, LivingEntity user, int timeLeft) {
        if (!(user instanceof Player player)) return false;
        int used = Math.max(0, getUseDuration(stack, user) - timeLeft);
        int damage = (int) Math.round(DDSettings.CONFIG.server.sonorousStaffDamage() / (1 + 16 / Math.exp(0.06 * used)));
        int range = (int) Math.min(DDSettings.CONFIG.server.sonorousStaffRange(), Math.round(3 * Math.log(used + 1)));
        Vec3 eye = player.getEyePosition(), facing = player.getForward();
        for (int i = 0; i < range; i++) {
            Vec3 scan = eye.add(facing.scale(i));
            BlockPos pos = BlockPos.containing(scan);
            var state = level.getBlockState(pos);
            if (!state.isAir() && state.canOcclude()) break;
            if (level.isClientSide() && i % 2 == 0) level.addParticle(ParticleTypes.SONIC_BOOM, scan.x, scan.y, scan.z, 1, 0, 0);
            if (level instanceof ServerLevel serverLevel) for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, new AABB(pos).inflate(0.4))) {
                if (target == player) continue;
                int finalDamage = (int) (damage * (1 - dropOffFactor * Math.pow((double) i / range, 2)));
                target.hurtServer(serverLevel, level.damageSources().sonicBoom(player), finalDamage);
                double resistance = 1 - target.getAttributeValue(Attributes.KNOCKBACK_RESISTANCE);
                double knockback = DDSettings.CONFIG.server.sonorousStaffKnockback();
                target.push(facing.x * resistance * knockback, facing.y * resistance * knockback, facing.z * resistance * knockback);
            }
        }
        if (level instanceof ServerLevel serverLevel) {
            player.playSound(DDSounds.SONOROUS_STAFF_SONIC_BOOM);
            stack.hurtAndBreak(1, player, player.getUsedItemHand() == InteractionHand.OFF_HAND ? EquipmentSlot.OFFHAND : EquipmentSlot.MAINHAND);
            player.awardStat(Stats.ITEM_USED.get(this));
            player.getCooldowns().addCooldown(stack, DDSettings.CONFIG.server.sonorousStaffCooldown());
            stack.remove(DataComponents.ENCHANTMENT_GLINT_OVERRIDE);
        }
        return true;
    }
    @Override public InteractionResult use(Level level, Player player, InteractionHand hand) {
        player.startUsingItem(hand);
        return InteractionResult.CONSUME;
    }
    @Override public void inventoryTick(ItemStack stack, ServerLevel level, Entity entity, EquipmentSlot slot) {
        if (entity instanceof Player player && player.getUseItem() == stack && getUseDuration(stack, player) - player.getUseItemRemainingTicks() >= 128)
            stack.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true);
        else stack.remove(DataComponents.ENCHANTMENT_GLINT_OVERRIDE);
    }
    @Override public int getUseDuration(ItemStack stack, LivingEntity entity) { return 72000; }
    @Override public ItemUseAnimation getUseAnimation(ItemStack stack) { return ItemUseAnimation.BOW; }
}
