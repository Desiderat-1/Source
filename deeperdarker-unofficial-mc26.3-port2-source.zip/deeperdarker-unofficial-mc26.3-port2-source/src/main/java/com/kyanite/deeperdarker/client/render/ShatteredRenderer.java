// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.client.render;

import com.kyanite.deeperdarker.DeeperDarker;
import com.kyanite.deeperdarker.client.DDModelLayers;
import com.kyanite.deeperdarker.client.model.ShatteredModel;
import com.kyanite.deeperdarker.content.entities.Shattered;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

@SuppressWarnings("NullableProblems")
public class ShatteredRenderer extends DDMobRenderer<Shattered, ShatteredModel> {
    private static final Identifier TEXTURE = Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "textures/entity/shattered.png");

    public ShatteredRenderer(EntityRendererProvider.Context pContext) {
        super(pContext, new ShatteredModel(pContext.bakeLayer(DDModelLayers.SHATTERED)), 0.5f);
    }

    @Override
    public Identifier getTextureLocation(Shattered pEntity) {
        return TEXTURE;
    }
}
