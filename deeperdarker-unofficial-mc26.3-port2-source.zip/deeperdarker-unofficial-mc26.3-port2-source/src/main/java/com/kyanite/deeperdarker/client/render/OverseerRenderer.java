package com.kyanite.deeperdarker.client.render;

import com.kyanite.deeperdarker.client.DDModelLayers;
import com.kyanite.deeperdarker.client.model.OverseerModel;
import com.kyanite.deeperdarker.client.state.DDModelRenderState;
import com.kyanite.deeperdarker.content.entities.overseer.Overseer;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.rendertype.*;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

public final class OverseerRenderer<T extends Overseer> extends DDMobRenderer<T,OverseerModel<T>> {
    private static final Identifier TEXTURE=Identifier.fromNamespaceAndPath("deeperdarker","textures/entity/overseer/overseer.png");
    private static final RenderType BEAM=RenderTypes.endCrystalBeam(Identifier.fromNamespaceAndPath("deeperdarker","textures/entity/overseer/overseer_beam.png"));
    public OverseerRenderer(EntityRendererProvider.Context context){super(context,new OverseerModel<>(context.bakeLayer(DDModelLayers.OVERSEER)),2);}
    @Override
    public Identifier getTextureLocation(T entity){return TEXTURE;}
    @Override
    protected void setupRotations(DDModelRenderState state,PoseStack poses,float bodyRotation,float scale){}
    @Override
    public void extractRenderState(T entity,DDModelRenderState state,float partial){
        super.extractRenderState(entity,state,partial);state.tetherOffset=null;state.tetherVector=null;
        entity.getOriginPos().ifPresent(origin->{
            Vec3 offset=Vec3.atCenterOf(origin.pos()).subtract(entity.position());
            state.tetherOffset=offset;
            state.tetherVector=offset.scale(-1).add(offset.normalize().scale(2)).add(0,entity.getBbHeight()/2,0);
        });
    }
    @Override
    public void submit(DDModelRenderState state,PoseStack poses,SubmitNodeCollector nodes,CameraRenderState camera){
        super.submit(state,poses,nodes,camera);
        if(state.tetherOffset!=null){
            poses.pushPose();poses.translate(state.tetherOffset.x,state.tetherOffset.y,state.tetherOffset.z);
            renderBeams((float)state.tetherVector.x,(float)state.tetherVector.y,(float)state.tetherVector.z,
                    state.ageInTicks,poses,nodes,state.lightCoords,BEAM,32,0.75F);poses.popPose();
        }
    }
    /** Shared eight-sided beam mesh. The collector snapshots the transformed pose before drawing. */
    public static void renderBeams(float dx,float dy,float dz,float age,PoseStack poses,SubmitNodeCollector nodes,
                                    int light,RenderType type,float resolution,float radius){
        float horizontal=Mth.sqrt(dx*dx+dz*dz),length=Mth.sqrt(dx*dx+dy*dy+dz*dz);
        if(length<0.0001F)return;
        poses.pushPose();poses.rotate(Axis.YP.rotation((float)-Math.atan2(dz,dx)-(float)Math.PI/2));
        poses.rotate(Axis.XP.rotation((float)-Math.atan2(horizontal,dy)-(float)Math.PI/2));
        float v1=-age*0.01F,v2=length/resolution-age*0.01F;
        nodes.submitCustomGeometry(poses,type,(pose,vertices)->{
            float px=0,py=radius,pu=0;
            for(int i=1;i<=8;i++){
                float x=Mth.sin(i*(float)Math.PI*2/8)*radius,y=Mth.cos(i*(float)Math.PI*2/8)*radius,u=i/8F;
                vertices.addVertex(pose.pose(),px*0.2F,py*0.2F,0).setColor(0xFF000000).setUv(pu,v1).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(pose,0,-1,0);
                vertices.addVertex(pose.pose(),px,py,length).setColor(0xFFFFFFFF).setUv(pu,v2).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(pose,0,-1,0);
                vertices.addVertex(pose.pose(),x,y,length).setColor(0xFFFFFFFF).setUv(u,v2).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(pose,0,-1,0);
                vertices.addVertex(pose.pose(),x*0.2F,y*0.2F,0).setColor(0xFF000000).setUv(u,v1).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(pose,0,-1,0);
                px=x;py=y;pu=u;
            }
        });poses.popPose();
    }
    @Override
    protected int getBlockLightLevel(T entity,BlockPos pos){return 15;}
    @Override
    public boolean shouldRender(T entity,Frustum frustum,double x,double y,double z,float partial){return true;}
}
