// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.util;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.level.block.Block;

public final class DDTiers {
    public static final ToolMaterial LEAD = create("lead", 250, 6, 2, 14);
    public static final ToolMaterial RADIOACTIVE = create("radioactive", 1661, 8, 4, 11);
    public static final ToolMaterial RESONARIUM = create("resonarium", 1193, 8, 3, 15);
    public static final ToolMaterial WARDEN = create("warden", 2519, 10, 5, 18);
    public static final ToolMaterial GUARDIAN = create("guardian", 11508, 11, 7, 22);
    private DDTiers() {}
    private static ToolMaterial create(String name, int durability, float speed, float damage, int enchantability) {
        TagKey<Block> incorrect = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("deeperdarker", "incorrect_for_" + name + "_tool"));
        return new ToolMaterial(incorrect, durability, speed, damage, enchantability, repairTag(name));
    }
    public static TagKey<Item> repairTag(String name) {
        return TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("deeperdarker", "repairs_" + name + "_equipment"));
    }
}
