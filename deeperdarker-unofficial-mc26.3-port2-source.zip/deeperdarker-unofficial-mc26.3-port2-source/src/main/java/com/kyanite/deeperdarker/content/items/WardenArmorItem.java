// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.content.items;

import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.ChatFormatting;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import java.util.List;
import java.util.function.Consumer;

public class WardenArmorItem extends Item {
    private final ArmorType type;
    private final List<Holder<MobEffect>> immunities;
    public WardenArmorItem(ArmorMaterial material, ArmorType type, Properties properties) {
        this(material, type, properties, List.of());
    }
    public WardenArmorItem(ArmorMaterial material, ArmorType type, Properties properties, List<Holder<MobEffect>> immunities) {
        super(properties(material, type, properties));
        this.type = type;
        this.immunities = List.copyOf(immunities);
    }
    private static Properties properties(ArmorMaterial material, ArmorType type, Properties properties) {
        properties.humanoidArmor(material, type);
        if (type == ArmorType.LEGGINGS) {
            properties.attributes(material.createAttributes(type).withModifierAdded(Attributes.MOVEMENT_SPEED,
                new AttributeModifier(Identifier.fromNamespaceAndPath("deeperdarker", "leggings_speed"), 0.02,
                    AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.LEGS));
        }
        return properties;
    }
    public ArmorType getType() { return type; }
    public EquipmentSlot getEquipmentSlot() { return type.getSlot(); }
    @Override
    public void inventoryTick(ItemStack stack, ServerLevel level, Entity entity, EquipmentSlot slot) {
        super.inventoryTick(stack, level, entity, slot);
        if (slot == type.getSlot() && entity instanceof LivingEntity user) immunities.forEach(user::removeEffect);
    }
    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, TooltipDisplay display, Consumer<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, context, display, tooltip, flag);
        if (!immunities.isEmpty()) {
            tooltip.accept(Component.translatable("item.deeperdarker.perks.immunity").withStyle(ChatFormatting.GRAY));
            for (Holder<MobEffect> effect : immunities) tooltip.accept(effect.value().getDisplayName().copy().withStyle(ChatFormatting.GREEN));
        }
    }
}
