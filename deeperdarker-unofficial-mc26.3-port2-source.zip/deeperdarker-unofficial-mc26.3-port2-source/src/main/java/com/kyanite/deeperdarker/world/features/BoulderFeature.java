// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.world.features;

import com.kyanite.deeperdarker.world.features.config.BoulderFeatureConfiguration;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.levelgen.feature.Feature;

public class BoulderFeature implements Feature {
    public static final MapCodec<BoulderFeature> CODEC = BoulderFeatureConfiguration.CODEC.xmap(BoulderFeature::new, feature -> feature.configuration);
    private final BoulderFeatureConfiguration configuration;
    public BoulderFeature(BoulderFeatureConfiguration configuration) { this.configuration = configuration; }
    @Override public MapCodec<BoulderFeature> codec() { return CODEC; }

    @Override
    public boolean place(net.minecraft.world.level.WorldGenLevel level, net.minecraft.world.level.chunk.ChunkGenerator generator, net.minecraft.util.RandomSource random, net.minecraft.core.BlockPos origin) {
        return generate(new DDFeatureContext<>(configuration, level, generator, random, origin));
    }
    private boolean generate(DDFeatureContext<BoulderFeatureConfiguration> featurePlaceContext) {
        WorldGenLevel level = featurePlaceContext.level();
        RandomSource random = featurePlaceContext.random();
        BlockPos origin = featurePlaceContext.origin();
        BoulderFeatureConfiguration config = featurePlaceContext.config();
        int diameter = config.diameter.sample(featurePlaceContext.random());
        float radius = diameter / 2.0f;
        int radiusInt = Mth.ceil(radius);

        if (level.isEmptyBlock(origin.below())) return false;

        boolean placed = false;
        BlockPos.MutableBlockPos pos = origin.mutable();
        for (int offsetZ = -radiusInt; offsetZ <= radiusInt; offsetZ++) {
            for (int offsetY = -radiusInt; offsetY <= radiusInt; offsetY++) {
                for (int offsetX = -radiusInt; offsetX <= radiusInt; offsetX++) {
                    if (Mth.abs(offsetX * offsetX + offsetY * offsetY + offsetZ * offsetZ) <= radius * radius && level.getBlockState(pos.setWithOffset(origin, offsetX, offsetY, offsetZ)).canBeReplaced()) {
                        placed = true;
                        level.setBlock(pos, config.stateProvider.getState(featurePlaceContext.level(), random, pos), Block.UPDATE_CLIENTS);
                    }
                }
            }
        }
        return placed;
    }
}
