// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.world.features;

import com.kyanite.deeperdarker.content.DDBlocks;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;

public class SculkGleamFeature implements Feature {
    public static final MapCodec<SculkGleamFeature> CODEC = MapCodec.unit(SculkGleamFeature::new);
    public SculkGleamFeature() {}
    @Override public MapCodec<SculkGleamFeature> codec() { return CODEC; }

    @Override
    public boolean place(net.minecraft.world.level.WorldGenLevel level, net.minecraft.world.level.chunk.ChunkGenerator generator, net.minecraft.util.RandomSource random, net.minecraft.core.BlockPos origin) {
        return generate(new DDFeatureContext<>(null, level, generator, random, origin));
    }
    private boolean generate(DDFeatureContext<Void> pContext) {
        WorldGenLevel level = pContext.level();
        BlockPos origin = pContext.origin();
        RandomSource random = pContext.random();

        if(level.isEmptyBlock(origin)) {
            BlockState state = level.getBlockState(origin.above());
            if(state.is(Blocks.SCULK) || state.is(DDBlocks.SCULK_STONE)) {
                level.setBlock(origin, DDBlocks.SCULK_GLEAM.defaultBlockState(), 3);

                for(int i = 0; i < 1500; ++i) {
                    BlockPos pos = origin.offset(random.nextInt(8) - random.nextInt(8), -random.nextInt(12), random.nextInt(8) - random.nextInt(8));
                    if(level.getBlockState(pos).isAir()) {
                        int j = 0;

                        for(Direction direction : Direction.values()) {
                            if(level.getBlockState(pos.relative(direction)).is(DDBlocks.SCULK_GLEAM)) j++;
                            if(j > 1) break;
                        }

                        if(j == 1) level.setBlock(pos, DDBlocks.SCULK_GLEAM.defaultBlockState(), 3);
                    }
                }

                return true;
            }
        }

        return false;
    }
}
