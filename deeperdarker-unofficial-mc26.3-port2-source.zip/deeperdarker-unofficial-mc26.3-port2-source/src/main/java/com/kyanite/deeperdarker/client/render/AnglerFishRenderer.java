// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.client.render;

import com.kyanite.deeperdarker.DeeperDarker;
import com.kyanite.deeperdarker.client.DDModelLayers;
import com.kyanite.deeperdarker.client.model.AnglerFishModel;
import com.kyanite.deeperdarker.content.entities.AnglerFish;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

@SuppressWarnings("NullableProblems")
public class AnglerFishRenderer extends DDMobRenderer<AnglerFish, AnglerFishModel> {
    private static final Identifier TEXTURE = Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "textures/entity/angler_fish/angler_fish.png");
    private static final Identifier EMISSIVE_TEXTURE = Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "textures/entity/angler_fish/angler_fish_bioluminescent_layer.png");

    public AnglerFishRenderer(EntityRendererProvider.Context pContext) {
        super(pContext, new AnglerFishModel(pContext.bakeLayer(DDModelLayers.ANGLER_FISH)), 0.4f);
        this.addLayer(new AnglerFishEmissiveLayer<>(this, EMISSIVE_TEXTURE));
    }


    @Override
    public Identifier getTextureLocation(AnglerFish pEntity) {
        return TEXTURE;
    }

    @Override
    protected void setupRotations(AnglerFish pEntityLiving, PoseStack pPoseStack, float pAgeInTicks, float pRotationYaw, float pPartialTicks) {
        super.setupRotations(pEntityLiving, pPoseStack, pAgeInTicks, pRotationYaw, pPartialTicks);
        float f = 1f;
        float f1 = 1f;
        if (!pEntityLiving.isInWater()) {
            f = 1.3f;
            f1 = 1.7f;
        }

        float f2 = f * 4.3f * Mth.sin(f1 * 0.6f * pAgeInTicks);
        pPoseStack.rotate(Axis.YP.rotationDegrees(f2));
        pPoseStack.translate(0, 0, -0.4f);
        if (!pEntityLiving.isInWater()) {
            pPoseStack.translate(0.2f, 0.1f, 0f);
            pPoseStack.rotate(Axis.ZP.rotationDegrees(90f));
        }
    }
}
