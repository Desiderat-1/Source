package com.kyanite.deeperdarker.mixin;

import com.kyanite.deeperdarker.content.DDDamageTypes;
import com.kyanite.deeperdarker.content.fluids.EntityInAcid;
import com.kyanite.deeperdarker.util.*;
import com.llamalad7.mixinextras.injector.wrapoperation.*;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.*;
import net.minecraft.world.level.material.Fluid;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import java.util.Set;
import java.util.HashSet;

@Mixin(Entity.class)
public abstract class AcidEntityMixin implements EntityInAcid {
    @Shadow protected boolean firstTick;
    @Shadow @Final private EntityFluidInteraction fluidInteraction;

    @ModifyArg(method="<init>",at=@At(value="INVOKE",target="Lnet/minecraft/world/entity/EntityFluidInteraction;<init>(Ljava/util/Set;)V"),index=0)
    private Set<TagKey<Fluid>> deeperdarker$trackAcid(Set<TagKey<Fluid>> original){
        var fluids=new HashSet<>(original);fluids.add(DDTags.Fluids.ACID);return Set.copyOf(fluids);
    }
    @Inject(method="updateFluidInteraction",at=@At("RETURN"),cancellable=true)
    private void deeperdarker$acidCurrent(CallbackInfoReturnable<Boolean> cir){
        Entity entity=(Entity)(Object)this;
        if(fluidInteraction.isInFluid(DDTags.Fluids.ACID)){
            if(!entity.isInLava()&&entity.isPushedByFluid())fluidInteraction.applyCurrentTo(DDTags.Fluids.ACID,entity,0.014);
            cir.setReturnValue(true);
        }
    }
    @Inject(method="baseTick",at=@At("TAIL"))
    private void deeperdarker$acidDamage(CallbackInfo ci){
        if(deeperdarker$isInAcid()){deeperdarker$acidHurt();((Entity)(Object)this).fallDistance*=0.5F;}
    }
    @WrapOperation(method="canSpawnSprintParticle",at=@At(value="INVOKE",target="Lnet/minecraft/world/entity/Entity;isInLava()Z"))
    private boolean deeperdarker$noAcidSprintParticles(Entity entity,Operation<Boolean> original){return original.call(entity)||deeperdarker$isInAcid();}
    @Override public boolean deeperdarker$isInAcid(){return !firstTick&&fluidInteraction.isInFluid(DDTags.Fluids.ACID);}
    @Override public boolean deeperdarker$acidImmune(){return ((Entity)(Object)this).getType().builtInRegistryHolder().is(DDTags.EntityTypes.ACID_IMMUNE);}
    @Override public void deeperdarker$acidHurt(){
        if(deeperdarker$acidImmune())return;
        // Retain the alpha's first-equipped-armor immunity rule.
        for(var stack:DDArmorSlots.of((Entity)(Object)this)){if(!stack.is(DDTags.Items.ACID_IMMUNE_ARMOR))break;return;}
        Entity entity=(Entity)(Object)this;entity.hurtOrSimulate(entity.damageSources().source(DDDamageTypes.ACID),5);
    }
}
