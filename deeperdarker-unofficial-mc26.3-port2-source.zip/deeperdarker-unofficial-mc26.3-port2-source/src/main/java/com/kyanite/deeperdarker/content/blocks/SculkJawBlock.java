// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.content.blocks;

import com.kyanite.deeperdarker.content.DDDamageTypes;
import com.kyanite.deeperdarker.content.entities.DDMobType;
import com.kyanite.deeperdarker.content.entities.blocks.SculkJawBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.Nullable;

@SuppressWarnings("deprecation, NullableProblems")
public class SculkJawBlock extends BaseEntityBlock {
    public static final BooleanProperty BITING = BooleanProperty.create("biting");
    public static final BooleanProperty CAN_BITE = BooleanProperty.create("can_bite");

    public SculkJawBlock(Properties pProperties) {
        super(pProperties);
        this.registerDefaultState(this.stateDefinition.any().setValue(BITING, false).setValue(CAN_BITE, true));
    }

    @Override
    public void stepOn(Level pLevel, BlockPos pPos, BlockState pState, Entity pEntity) {
        if(pEntity instanceof Player player && (player.isCreative() || player.isCrouching())) return;
        if(pEntity instanceof Monster monster && DDMobType.isSculk(monster)) return;
        if(pState.getValue(CAN_BITE) && pEntity instanceof LivingEntity entity) {
            pLevel.setBlock(pPos, pState.setValue(BITING, true), 3);
            entity.hurtOrSimulate(pLevel.damageSources().source(DDDamageTypes.BITE), 3);
            if (pEntity instanceof Player player && pLevel.getBlockEntity(pPos) instanceof SculkJawBlockEntity jaw) jaw.stealExperienceFromPlayer(player, 4);
            pLevel.scheduleTick(pPos, this, 35);
        }
    }

    @Override
    public void tick(BlockState pState, ServerLevel pLevel, BlockPos pPos, RandomSource pRandom) {
        if(pState.getValue(BITING)) pLevel.setBlock(pPos, pState.setValue(BITING, false), 3);
    }

    @Override
    public void entityInside(BlockState pState, Level pLevel, BlockPos pPos, Entity pEntity, net.minecraft.world.entity.InsideBlockEffectApplier portEffects, boolean portMoving) {
        if(pEntity instanceof LivingEntity entity) entity.hurtOrSimulate(pLevel.damageSources().source(DDDamageTypes.BITE), 3);
        if(pEntity instanceof Player player && pLevel.getBlockEntity(pPos) instanceof SculkJawBlockEntity jaw) jaw.stealExperienceFromPlayer(player, 4);
    }

    public void releaseExperience(ServerLevel level, BlockPos pos, int amount) {
        this.popExperience(level, pos, amount);
    }

    @Override
    public VoxelShape getCollisionShape(BlockState pState, BlockGetter pLevel, BlockPos pPos, CollisionContext pContext) {
        return pState.getValue(BITING) ? Block.box(0, 0, 0, 0, 0, 0) : super.getCollisionShape(pState, pLevel, pPos, pContext);
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> pBuilder) {
        pBuilder.add(BITING, CAN_BITE);
    }

    @Override
    public @Nullable BlockEntity newBlockEntity(BlockPos blockPos, BlockState blockState) {
        return new SculkJawBlockEntity(blockPos, blockState);
    }

    @Override
    public RenderShape getRenderShape(BlockState pState) {
        return RenderShape.MODEL;
    }
}
