// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.client.render;
import com.kyanite.deeperdarker.client.state.DDModelRenderState;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.resources.Identifier;
public class AnglerFishEmissiveLayer<M extends EntityModel<DDModelRenderState>> extends RenderLayer<DDModelRenderState, M> {
    private final Identifier texture;
    public AnglerFishEmissiveLayer(RenderLayerParent<DDModelRenderState, M> parent, Identifier texture) {
        super(parent); this.texture = texture;
    }
    @Override public void submit(PoseStack poses, SubmitNodeCollector nodes, int light,
            DDModelRenderState state, float yaw, float pitch) {
        nodes.submitModel(getParentModel(), state, poses, RenderTypes.entityTranslucentEmissive(texture),
                light, LivingEntityRenderer.getOverlayCoords(state, 0), 0xFFFFFFFF);
    }
}
