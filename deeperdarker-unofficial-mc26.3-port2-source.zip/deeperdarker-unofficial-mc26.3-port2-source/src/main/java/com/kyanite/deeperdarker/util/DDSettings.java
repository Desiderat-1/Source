// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.util;
public final class DDSettings {
    public static final DDConfig CONFIG = DDConfig.createAndLoad();
    private DDSettings() {}
}
