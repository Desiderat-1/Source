package com.kyanite.deeperdarker.mixin;

import com.kyanite.deeperdarker.content.items.ShieldAugmentItem;
import com.kyanite.deeperdarker.content.components.ShieldAugments;
import com.kyanite.deeperdarker.util.DDTags;
import com.kyanite.deeperdarker.util.DDUtil;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.SlotAccess;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickAction;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.tooltip.BundleTooltip;
import net.minecraft.world.inventory.tooltip.TooltipComponent;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;
import java.util.stream.Stream;

@Mixin(value = Item.class, priority = 500)
public abstract class ShieldItemMixin {
    @Inject(method = "overrideStackedOnOther", at = @At("HEAD"), cancellable = true)
    private void deeperdarker$overrideShieldStackedOnOther(ItemStack shield, Slot slot, ClickAction clickAction, Player player, CallbackInfoReturnable<Boolean> cir) {
        if (!shield.is(ConventionalItemTags.SHIELD_TOOLS) || !DDUtil.isAugmented(shield)) {
            return;
        }
        if (clickAction != ClickAction.SECONDARY) {
            return;
        }
        ItemStack previousStack = DDUtil.getAugmentItem(shield, player.level().registryAccess());
        ItemStack slotStack = slot.getItem();
        if (slotStack.isEmpty()) {
            this.playRemoveOneSound(player);
            ShieldAugments.remove(shield, player.level().registryAccess()).ifPresent(itemStack2 -> {
                if (itemStack2.getItem() instanceof ShieldAugmentItem augmentItem) {
                    augmentItem.onAugmentRemoved(shield, slot, player);
                }
                ShieldAugments.add(shield, slot.safeInsert(itemStack2), player.level().registryAccess());
            });
        } else if (ItemStack.isSameItemSameComponents(previousStack, slotStack) && slotStack.getCount() < slotStack.getMaxStackSize()) {
            slotStack.grow(1);
            ShieldAugments.remove(shield, player.level().registryAccess()).ifPresent(itemStack2 -> {
                if (itemStack2.getItem() instanceof ShieldAugmentItem augmentItem) {
                    augmentItem.onAugmentRemoved(shield, slot, player);
                }
            });
        } else if (!slotStack.is(DDTags.Items.SHIELD_AUGMENT_ITEMS)) {
            return;
        } else if (slotStack.getItem().canFitInsideContainerItems()) {
            if (previousStack.isEmpty()) {
                ItemStack addedStack = slot.safeTake(slotStack.getCount(), 1, player);
                boolean added = ShieldAugments.add(shield, addedStack, player.level().registryAccess());
                if (added) {
                    if (addedStack.getItem() instanceof ShieldAugmentItem augmentItem) {
                        augmentItem.onAugmentAdded(shield, previousStack, slot, player);
                    }
                    playInsertSound(player);
                }
            } else if (slotStack.getCount() == 1) {
                ShieldAugments.remove(shield, player.level().registryAccess()).ifPresent(itemStack -> {
                    if (itemStack.getItem() instanceof ShieldAugmentItem augmentItem) {
                        augmentItem.onAugmentRemoved(shield, slot, player);
                    }
                });
                boolean added = ShieldAugments.add(shield, slotStack, player.level().registryAccess());
                if (added) {
                    if (slotStack.getItem() instanceof ShieldAugmentItem augmentItem) {
                        augmentItem.onAugmentAdded(shield, previousStack, slot, player);
                    }
                    slot.setByPlayer(previousStack);
                    playInsertSound(player);
                }
            }
        }
        cir.setReturnValue(true);
    }

    @Inject(method = "overrideOtherStackedOnMe", at = @At("HEAD"), cancellable = true)
    public void deeperdarker$overrideOtherStackedOnShield(ItemStack shield, ItemStack stack, Slot slot, ClickAction clickAction, Player player, SlotAccess slotAccess, CallbackInfoReturnable<Boolean> cir) {
        if (!shield.is(ConventionalItemTags.SHIELD_TOOLS) || !DDUtil.isAugmented(shield)) {
            return;
        }
        if (clickAction != ClickAction.SECONDARY || !slot.allowModification(player)) {
            return;
        }
        if (stack.isEmpty()) {
            ShieldAugments.remove(shield, player.level().registryAccess()).ifPresent(itemStack -> {
                if (itemStack.getItem() instanceof ShieldAugmentItem augmentItem) {
                    augmentItem.onAugmentRemoved(shield, slot, player);
                }
                this.playRemoveOneSound(player);
                slotAccess.set(itemStack);
            });
            cir.setReturnValue(true);
        } else if (stack.is(DDTags.Items.SHIELD_AUGMENT_ITEMS)) {
            ItemStack previousStack = DDUtil.getAugmentItem(shield, player.level().registryAccess());
            if (previousStack.isEmpty()) {
                boolean added = ShieldAugments.add(shield, stack, player.level().registryAccess());
                if (added) {
                    if (stack.getItem() instanceof ShieldAugmentItem augmentItem) {
                        augmentItem.onAugmentAdded(shield, previousStack, slot, player);
                    }
                    stack.shrink(1);
                    playInsertSound(player);
                }
                cir.setReturnValue(true);
            } else if (stack.getCount() == 1) {
                ShieldAugments.remove(shield, player.level().registryAccess()).ifPresent(itemStack -> {
                    if (itemStack.getItem() instanceof ShieldAugmentItem augmentItem) {
                        augmentItem.onAugmentRemoved(shield, slot, player);
                    }
                });
                boolean added = ShieldAugments.add(shield, stack, player.level().registryAccess());
                if (added) {
                    if (stack.getItem() instanceof ShieldAugmentItem augmentItem) {
                        augmentItem.onAugmentAdded(shield, previousStack, slot, player);
                    }
                    slotAccess.set(previousStack);
                    playInsertSound(player);
                }
                cir.setReturnValue(true);
            }
        }
    }

    @Inject(method = "inventoryTick", at = @At("TAIL"))
    private void deeperdarker$tickShieldAugment(ItemStack stack, net.minecraft.server.level.ServerLevel level, Entity entity, net.minecraft.world.entity.EquipmentSlot slot, CallbackInfo ci) {
        if (DDUtil.isAugmentedShield(stack)) {
            ShieldAugments.migrate(stack, level.registryAccess());
            ItemStack augmentStack = DDUtil.getAugmentItem(stack, level.registryAccess());
            if (augmentStack.getItem() instanceof ShieldAugmentItem augmentItem) {
                augmentItem.augmentTick(stack, level, entity, slot);
            }
        }
    }

    @Unique
    private static Stream<ItemStack> getStackAsStream(ItemStack shield) {
        ItemStack stack = DDUtil.getAugmentItem(shield);
        if (stack.isEmpty()) return Stream.empty();
        return Stream.of(stack);
    }

    @ModifyReturnValue(method = "getTooltipImage", at = @At("RETURN"))
    public Optional<TooltipComponent> getTooltipImage(Optional<TooltipComponent> original, @Local(argsOnly = true) ItemStack shield) {
        if (!DDUtil.isAugmentedShield(shield)) return original;
        ItemStack augment = DDUtil.getAugmentItem(shield);
        var contents = augment.isEmpty() ? java.util.List.<net.minecraft.world.item.ItemStackTemplate>of()
                : java.util.List.of(net.minecraft.world.item.ItemStackTemplate.fromNonEmptyStack(augment));
        return Optional.of(new BundleTooltip(new net.minecraft.world.item.component.BundleContents(contents)));
    }

    @Inject(method = "onDestroyed", at = @At("HEAD"))
    public void deeperdarker$onShieldDestroyed(ItemEntity itemEntity, CallbackInfo ci) {
        if (!itemEntity.getItem().is(ConventionalItemTags.SHIELD_TOOLS)) return;
        ShieldAugments.migrate(itemEntity.getItem(), itemEntity.level().registryAccess());
        ItemUtils.onContainerDestroyed(itemEntity, getStackAsStream(itemEntity.getItem()));
    }

    @Unique
    private void playRemoveOneSound(Entity entity) {
        entity.playSound(SoundEvents.BUNDLE_REMOVE_ONE, 0.8f, 0.8f + entity.level().getRandom().nextFloat() * 0.4f);
    }

    @Unique
    private void playInsertSound(Entity entity) {
        entity.playSound(SoundEvents.BUNDLE_INSERT, 0.8f, 0.8f + entity.level().getRandom().nextFloat() * 0.4f);
    }
}

