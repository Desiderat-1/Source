// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.client.render;

import com.kyanite.deeperdarker.DeeperDarker;
import com.kyanite.deeperdarker.client.model.SculkCentipedeModel;
import com.kyanite.deeperdarker.content.entities.SculkCentipede;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

@SuppressWarnings("NullableProblems")
public class SculkCentipedeRenderer extends DDMobRenderer<SculkCentipede, SculkCentipedeModel> {
    public static final ModelLayerLocation MODEL = new ModelLayerLocation(Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "sculk_centipede"), "main");
    private static final Identifier TEXTURE = Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "textures/entity/sculk_centipede.png");

    public SculkCentipedeRenderer(EntityRendererProvider.Context pContext) {
        super(pContext, new SculkCentipedeModel(pContext.bakeLayer(MODEL)), 0.6f);
    }

    @Override
    public Identifier getTextureLocation(SculkCentipede pEntity) {
        return TEXTURE;
    }
}
