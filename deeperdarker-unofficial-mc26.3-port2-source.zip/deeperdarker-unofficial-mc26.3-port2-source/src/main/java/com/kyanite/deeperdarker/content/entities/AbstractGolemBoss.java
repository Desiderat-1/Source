// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.content.entities;

import net.minecraft.core.GlobalPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.animal.golem.AbstractGolem;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.scores.Team;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public abstract class AbstractGolemBoss extends AbstractGolem implements Enemy {
    private final ServerBossEvent bossEvent = (ServerBossEvent) new ServerBossEvent(java.util.UUID.randomUUID(), getDisplayName(), BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS).setDarkenScreen(true);
    private GlobalPos homePos = null;

    public final short COOLDOWN_TIME = 20;
    protected short cooldown = 0;

    public final float MIN_SPEED = 1.0f;
    public final float MAX_SPEED = 5.0f;

    protected static final EntityDataAccessor<Boolean> DATA_SLEEPING_ID = SynchedEntityData.defineId(AbstractGolemBoss.class, EntityDataSerializers.BOOLEAN);
    protected static final EntityDataAccessor<Boolean> DATA_SNAP_TO_BLOCKS_ID = SynchedEntityData.defineId(AbstractGolemBoss.class, EntityDataSerializers.BOOLEAN);

    public AbstractGolemBoss(EntityType<? extends AbstractGolem> entityType, Level level) {
        super(entityType, level);
        setGolemSleeping(true);
        blocksBuilding = true;
        setNoGravity(true);
    }

    @Override
    protected void registerGoals() {
        targetSelector.addGoal(1, new GolemBossHurtByTargetGoal(this));
    }

    @Override
    public void readAdditionalSaveData(net.minecraft.world.level.storage.ValueInput compoundTag) {
        super.readAdditionalSaveData(compoundTag);
        if (!targetPlayers()) {
            reset();
            setGolemSleeping(true);
        } else {
            setGolemSleeping(compoundTag.getBooleanOr("is_golem_sleeping", false));
        }
        homePos = compoundTag.read("home_position", GlobalPos.CODEC).orElse(null);
        setSnapToBlocks(compoundTag.getBooleanOr("snap_to_blocks", false));
        cooldown = (short) compoundTag.getShortOr("cooldown", (short) 0);
        if (hasCustomName()) {
            bossEvent.setName(getDisplayName());
        }
    }

    @Override
    public void addAdditionalSaveData(net.minecraft.world.level.storage.ValueOutput compoundTag) {
        super.addAdditionalSaveData(compoundTag);
        if (homePos != null) {
            compoundTag.store("home_position", GlobalPos.CODEC, homePos);
        }
        compoundTag.putBoolean("is_golem_sleeping", isGolemSleeping());
        compoundTag.putBoolean("snap_to_blocks", snapToBlocks());
        compoundTag.putShort("cooldown", cooldown);
    }

    @Override
    protected void defineSynchedData(net.minecraft.network.syncher.SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_SLEEPING_ID, true);
        builder.define(DATA_SNAP_TO_BLOCKS_ID, true);
    }

    @Override
    public void setCustomName(@Nullable Component component) {
        super.setCustomName(component);
        bossEvent.setName(getDisplayName());
    }

    @Override
    public boolean canUsePortal(boolean allowPassengers) {
        return false;
    }

    @Override
    public void startSeenByPlayer(ServerPlayer serverPlayer) {
        super.startSeenByPlayer(serverPlayer);
        bossEvent.addPlayer(serverPlayer);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer serverPlayer) {
        super.stopSeenByPlayer(serverPlayer);
        bossEvent.removePlayer(serverPlayer);
    }

    @Override
    protected void customServerAiStep(ServerLevel serverLevel) {
        super.customServerAiStep(serverLevel);
        bossEvent.setProgress(getHealth() / getMaxHealth());

        if (isGolemSleeping() || isDeadOrDying() || level().isClientSide()) return;

        if (getTarget() == null && !targetPlayers()) {
            reset();
            return;
        }

        golemServerAiStep();
    }

    @Override
    public void push(Entity entity) {
    }

    @Override
    public boolean canBeCollidedWith(Entity other) {
        return true;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public void knockback(double strength, double x, double z, DamageSource source, float damage, boolean force) {
    }

    public boolean isGolemSleeping() {
        return entityData.get(DATA_SLEEPING_ID);
    }

    public void setGolemSleeping(boolean sleeping) {
        entityData.set(DATA_SLEEPING_ID, sleeping);
        bossEvent.setVisible(!sleeping);
        if (sleeping) {
            heal(getMaxHealth());
            setTarget(null);
        }
    }

    public GlobalPos getHomePos() {
        return homePos;
    }

    public void setHomePos(GlobalPos homePos) {
        this.homePos = homePos;
    }

    @Override
    public void tick() {
        super.tick();
        if (snapToBlocks()) {
            setPos(blockPosition().getX() + 0.5, blockPosition().getY(), blockPosition().getZ() + 0.5);
        }

        if (isOnCooldown()) {
            cooldown--;
            return;
        }

        if (homePos != null && (homePos.dimension() != level().dimension() || distanceToSqr(Vec3.atCenterOf(homePos.pos())) > 4096)) {
            reset();
        }
    }

    protected abstract void golemServerAiStep();

    public void reset() {
        if (homePos != null && level().dimension() == homePos.dimension()) {
            if (level() instanceof ServerLevel serverLevel) {
                serverLevel.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, getParticleState()), getX(), getY(0.5), getZ(), 250, getBbWidth() / 4.0f, getBbHeight() / 4.0f, getBbWidth() / 4.0f, 0.05);
            }
            snapTo(homePos.pos().getX() + 0.5, homePos.pos().getY(), homePos.pos().getZ() + 0.5);
        }
        setCooldown(COOLDOWN_TIME);
        setGolemSleeping(true);
    }

    public abstract BlockState getParticleState();

    @Override
    public boolean fireImmune() {
        return isGolemSleeping() || isOnCooldown() || super.fireImmune();
    }

    @Override
    public boolean isInvulnerable() {
        return isGolemSleeping() || isOnCooldown() || super.isInvulnerable();
    }

    @Override
    public boolean shouldDropExperience() {
        return true;
    }

    public short getCooldown() {
        return cooldown;
    }

    public void setCooldown(short cooldown) {
        this.cooldown = cooldown;
    }

    public boolean snapToBlocks() {
        return entityData.get(DATA_SNAP_TO_BLOCKS_ID);
    }

    public void setSnapToBlocks(boolean snapToBlocks) {
        entityData.set(DATA_SNAP_TO_BLOCKS_ID, snapToBlocks);
    }

    public boolean isOnCooldown() {
        return getCooldown() > 0;
    }

    public boolean targetPlayers() {
        List<Player> players = combatPlayers(this, getBoundingBox().inflate(30.0, 30.0, 30.0));
        if (players.isEmpty()) return false;
        for (Player player : players) {
            if (isEntityValidTarget(player)) {
                setLastHurtByMob(player);
                setTarget(player);
                return true;
            }
        }
        return false;
    }

    public boolean isEntityValidTarget(LivingEntity entity) {
        if (entity == null) {
            return false;
        }

        if (!canAttack(entity)) {
            return false;
        }
        Team team = getTeam();
        Team team2 = entity.getTeam();
        if (team != null && team2 == team) {
            return false;
        }
        double d = getAttributeValue(Attributes.FOLLOW_RANGE);
        if (distanceToSqr(entity) > d * d) {
            return false;
        }
        setTarget(entity);
        return true;
    }

    private static List<Player> combatPlayers(Mob mob, AABB bounds) {
        if (!(mob.level() instanceof ServerLevel server)) return List.of();
        TargetingConditions conditions = TargetingConditions.forCombat().ignoreInvisibilityTesting();
        return server.players().stream().filter(player -> bounds.contains(player.position())
                && conditions.test(server, mob, player)).map(player -> (Player) player).toList();
    }

    public static class GolemBossHurtByTargetGoal extends HurtByTargetGoal {
        public GolemBossHurtByTargetGoal(AbstractGolemBoss golem, Class<?>... classs) {
            super(golem, classs);
        }

        @Override
        public boolean canUse() {
            if (((AbstractGolemBoss) mob).isOnCooldown()) return false;

            if (((AbstractGolemBoss) mob).isGolemSleeping()) {
                return super.canUse();
            }
            List<Player> players = combatPlayers(mob, mob.getBoundingBox().inflate(30.0, 30.0, 30.0));
            if (players.isEmpty()) return false;
            for (Player player : players) {
                if (((AbstractGolemBoss) mob).isEntityValidTarget(player)) {
                    mob.setLastHurtByMob(player);
                    return true;
                }
            }
            return false;
        }

        @Override
        public boolean canContinueToUse() {
            LivingEntity livingEntity = mob.getTarget();
            if (livingEntity == null) {
                livingEntity = targetMob;
            }
            if (!((AbstractGolemBoss) mob).isEntityValidTarget(livingEntity)) {
                List<Player> players = combatPlayers(mob, mob.getBoundingBox().inflate(30.0, 30.0, 30.0));
                if (players.isEmpty()) return false;
                for (Player player : players) {
                    if (((AbstractGolemBoss) mob).isEntityValidTarget(player)) {
                        livingEntity = player;
                        break;
                    }
                }
            }

            return livingEntity != null && !((AbstractGolemBoss) mob).isOnCooldown() && !((AbstractGolemBoss) mob).isGolemSleeping();
        }

        @Override
        public void start() {
            super.start();
            ((AbstractGolemBoss) mob).setGolemSleeping(false);
        }

        @Override
        public void stop() {
            super.stop();
            ((AbstractGolemBoss) mob).reset();
            mob.setLastHurtByMob(null);
        }
    }

    @Override
    public boolean isPushedByFluid() {
        return false;
    }

    @Override
    public boolean isAffectedByPotions() {
        return false;
    }

    @Override
    public boolean doHurtTarget(net.minecraft.server.level.ServerLevel portServerLevel, Entity entity) {
        float attackDamage = (float)this.getAttributeValue(Attributes.ATTACK_DAMAGE);
        float attackKnockback = (float)this.getAttributeValue(Attributes.ATTACK_KNOCKBACK);
        DamageSource source = damageSources().mobAttack(this);
        attackDamage = EnchantmentHelper.modifyDamage(portServerLevel, getMainHandItem(), entity, source, attackDamage);
        attackKnockback = EnchantmentHelper.modifyKnockback(portServerLevel, getMainHandItem(), entity, source, attackKnockback);
        boolean hurt = entity.hurtServer(portServerLevel, source, attackDamage);
        if (hurt) {
            if (attackKnockback > 0.0f && entity instanceof LivingEntity livingEntity) {
                livingEntity.knockback(attackKnockback * 0.5f, getX() - livingEntity.getX(), getZ() - livingEntity.getZ(), source, attackDamage);
            }
            EnchantmentHelper.doPostAttackEffects(portServerLevel, entity, source);
            this.setLastHurtMob(entity);
        }
        return hurt;
    }

    public void hurtPlayersInside() {
        if (!(level() instanceof ServerLevel server)) return;
        level().getEntities(this, getBoundingBox().deflate(0.4), entity -> entity instanceof Player).forEach(player -> {
            if (getRandom().nextBoolean()) {
                player.addDeltaMovement(player.getDeltaMovement().add(0.0, getBbHeight(), 0.0));
            }
            doHurtTarget(server, player);
        });
    }
}
