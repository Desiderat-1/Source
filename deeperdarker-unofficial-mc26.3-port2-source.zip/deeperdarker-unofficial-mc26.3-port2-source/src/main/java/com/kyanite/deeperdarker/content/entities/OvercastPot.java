// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.content.entities;

import com.kyanite.deeperdarker.content.DDEffects;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

public class OvercastPot extends Monster {
    @Nullable
    private UUID owner;

    public OvercastPot(EntityType<? extends Monster> entityType, Level level) {
        super(entityType, level);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new LeapAtTargetGoal(this, 0.4f));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.1, true));
        this.goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.9));
        this.goalSelector.addGoal(4, new RandomStrollGoal(this, 0.7));
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 5));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true));
        this.targetSelector.addGoal(2, new HurtByTargetGoal(this));
    }

    public static AttributeSupplier createAttributes(int extraHealth) {
        return Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH, 250 + extraHealth).add(Attributes.ATTACK_DAMAGE, 22).add(Attributes.MOVEMENT_SPEED, 0.3).build();
    }

    @Override
    public boolean doHurtTarget(net.minecraft.server.level.ServerLevel portServerLevel, Entity entity) {
        if (!super.doHurtTarget(portServerLevel, entity)) {
            return false;
        }
        if (entity instanceof LivingEntity) {
            ((LivingEntity)entity).addEffect(new MobEffectInstance(DDEffects.HEMOPHILIA, 200), this);
        }
        return true;
    }

    @Override
    public void addAdditionalSaveData(net.minecraft.world.level.storage.ValueOutput compoundTag) {
        super.addAdditionalSaveData(compoundTag);
        if (owner != null) {
            compoundTag.store("owner", net.minecraft.core.UUIDUtil.CODEC, owner);
        }
    }

    @Override
    public void readAdditionalSaveData(net.minecraft.world.level.storage.ValueInput compoundTag) {
        super.readAdditionalSaveData(compoundTag);
        if (compoundTag.read("owner", net.minecraft.core.UUIDUtil.CODEC).isPresent()) {
            owner = compoundTag.read("owner", net.minecraft.core.UUIDUtil.CODEC).orElse(null);
        }
    }

    @Override
    public boolean canUsePortal(boolean allowPassengers) {
        return owner == null;
    }

    public void setOwner(@Nullable UUID owner) {
        this.owner = owner;
    }

    public @Nullable UUID getOwner() {
        return owner;
    }
}
