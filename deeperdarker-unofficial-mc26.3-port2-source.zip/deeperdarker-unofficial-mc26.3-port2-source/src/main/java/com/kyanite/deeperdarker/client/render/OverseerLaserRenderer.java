package com.kyanite.deeperdarker.client.render;

import com.kyanite.deeperdarker.content.entities.overseer.OverseerLaser;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

public final class OverseerLaserRenderer<T extends OverseerLaser> extends EntityRenderer<T,OverseerLaserRenderer.State> {
    public static final class State extends EntityRenderState {float scale,animationTime;int[] lights=new int[0];Vec3 center=Vec3.ZERO;}
    public OverseerLaserRenderer(EntityRendererProvider.Context context){super(context);}
    @Override
    public State createRenderState(){return new State();}
    @Override
    public void extractRenderState(T entity,State state,float partial){
        super.extractRenderState(entity,state,partial);state.center=entity.position();
        state.scale=Mth.lerp(partial,entity.oldDespawnTime,entity.getDespawnTime())/OverseerLaser.MAX_DESPAWN_TIME;
        state.animationTime=Math.floorMod(entity.level().getGameTime(),360)+partial;
        state.lights=DarkFountainBlockRenderer.extractLights(entity.level(),entity.blockPosition(),256,256);
    }
    @Override
    public void submit(State state,PoseStack poses,SubmitNodeCollector nodes,CameraRenderState camera){
        super.submit(state,poses,nodes,camera);poses.pushPose();poses.scale(state.scale,1,state.scale);
        DarkFountainBlockRenderer.submitFountainBeam(poses,nodes,state.center,camera.pos,state.animationTime,state.lights,
                OverlayTexture.NO_OVERLAY,0xFFFFFFFF,256,256);poses.popPose();
    }
    @Override
    public boolean shouldRender(T entity,Frustum frustum,double x,double y,double z,float partial){return true;}
}
