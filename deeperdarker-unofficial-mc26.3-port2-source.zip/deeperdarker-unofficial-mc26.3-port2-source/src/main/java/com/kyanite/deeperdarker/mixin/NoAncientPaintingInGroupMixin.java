package com.kyanite.deeperdarker.mixin;
import com.kyanite.deeperdarker.util.DDTags;
import net.minecraft.core.Holder;
import net.minecraft.world.entity.decoration.painting.PaintingVariant;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(CreativeModeTabs.class)
public abstract class NoAncientPaintingInGroupMixin {
    // Vanilla emits preset stacks here; the mod's own tab emits its stacks separately.
    @Inject(method="lambda$generatePresetPaintings$0", at=@At("HEAD"), cancellable=true)
    private static void deeperdarker$noAncientPaintingInGroup(CreativeModeTab.Output output,
            CreativeModeTab.TabVisibility visibility, Holder.Reference<PaintingVariant> variant, CallbackInfo ci) {
        if (variant.is(DDTags.Paintings.ANCIENT)) ci.cancel();
    }
}
