// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.content.entities.acidsprite;

import com.google.common.collect.ImmutableMap;
import com.kyanite.deeperdarker.content.DDBlocks;
import com.kyanite.deeperdarker.content.DDItems;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.trading.VillagerTrades;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.trading.MerchantOffer;
import org.jetbrains.annotations.Nullable;

public final class AcidSpriteTrades {
    public static final Int2ObjectMap<TradeListing[]> TRADES = new Int2ObjectOpenHashMap<>(
            ImmutableMap.of(1, new TradeListing[]{
                    new ItemStacksToItemStack(new ItemStack(Items.QUARTZ, 8), new ItemStack(DDItems.FIZZ), 5, 1),
                    new ItemStacksToItemStack(new ItemStack(Items.SHULKER_SHELL, 4), new ItemStack(DDItems.SHADOW_CRYSTAL), 5, 1),
                    new ItemStacksToItemStack(new ItemStack(Items.BONE, 6), new ItemStack(DDItems.SCULK_BONE), 3, 1),
                    new ItemStacksToItemStack(new ItemStack(DDItems.RADIOACTIVE_INGOT, 2), new ItemStack(Items.ECHO_SHARD), 3, 1)
            }, 2, new TradeListing[]{
                    new ItemStacksToItemStack(new ItemStack(DDItems.PATIENCE_SOUL), new ItemStack(DDItems.SOUL_CRYSTAL, 2), new ItemStack(DDItems.SHIELD_AUGMENT), 5, 2),
                    new ItemStacksToItemStack(new ItemStack(DDItems.FORTITUDE_SOUL), new ItemStack(DDItems.SOUL_CRYSTAL, 2), new ItemStack(DDItems.SHIELD_AUGMENT), 5, 2),
                    new ItemStacksToItemStack(new ItemStack(DDItems.CORRUPTION_SOUL), new ItemStack(DDItems.SOUL_CRYSTAL, 2), new ItemStack(DDItems.SHIELD_AUGMENT), 5, 2)
            }));

    @FunctionalInterface
    public interface TradeListing {
        MerchantOffer getOffer(Entity entity, RandomSource random);
    }

    public static class ItemStacksToItemStack implements TradeListing {
        private final ItemStack fromItem;
        private final ItemStack fromItem2;
        private final ItemStack toItem;
        private final int maxUses;
        private final int villagerXp;
        private final float priceMultiplier;

        public ItemStacksToItemStack(ItemStack fromItem, ItemStack toItem, int maxUses, int villagerXp) {
            this(fromItem, ItemStack.EMPTY, toItem, maxUses, villagerXp);
        }

        public ItemStacksToItemStack(ItemStack fromItem, ItemStack fromItem2, ItemStack toItem, int maxUses, int villagerXp) {
            this.fromItem = fromItem;
            this.fromItem2 = fromItem2;
            this.toItem = toItem;
            this.maxUses = maxUses;
            this.villagerXp = villagerXp;
            this.priceMultiplier = 0.05f;
        }

        @Override
        @Nullable
        public MerchantOffer getOffer(Entity entity, RandomSource randomSource) {
            return new MerchantOffer(new net.minecraft.world.item.trading.ItemCost(fromItem.getItem(), fromItem.getCount()),
                    fromItem2.isEmpty() ? java.util.Optional.empty() : java.util.Optional.of(new net.minecraft.world.item.trading.ItemCost(fromItem2.getItem(), fromItem2.getCount())),
                    toItem.copy(), this.maxUses, this.villagerXp, this.priceMultiplier);
        }
    }
}
