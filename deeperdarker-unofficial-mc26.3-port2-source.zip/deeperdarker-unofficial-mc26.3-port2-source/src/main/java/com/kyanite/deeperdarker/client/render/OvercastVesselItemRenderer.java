package com.kyanite.deeperdarker.client.render;

import com.kyanite.deeperdarker.content.entities.overcastvessel.OvercastVesselItem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.item.*;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.item.ItemDisplayContext;
import org.joml.Quaternionf;

public final class OvercastVesselItemRenderer extends EntityRenderer<OvercastVesselItem,OvercastVesselItemRenderer.State> {
    public static final class State extends EntityRenderState {
        final ItemStackRenderState item=new ItemStackRenderState();float tilt;double lift;
    }
    private final ItemModelResolver resolver;
    public OvercastVesselItemRenderer(EntityRendererProvider.Context context){super(context);resolver=context.getItemModelResolver();}
    @Override
    public State createRenderState(){return new State();}
    @Override
    public void extractRenderState(OvercastVesselItem entity,State state,float partial){
        super.extractRenderState(entity,state,partial);state.item.clear();state.tilt=entity.getTilt(partial);
        resolver.updateForTopItem(state.item,entity.getItem(),ItemDisplayContext.GUI,entity.level(),entity,entity.getId());
        state.lift=state.item.isEmpty()?0:-state.item.getModelBoundingBox().minY;
    }
    @Override
    public void submit(State state,PoseStack poses,SubmitNodeCollector nodes,CameraRenderState camera){
        poses.pushPose();poses.translate(0,state.lift,0);poses.rotate(Axis.ZP.rotation(state.tilt));
        poses.rotate(new Quaternionf().rotationYXZ((float)Math.PI-(float)Math.PI/180*camera.yRot,-(float)Math.PI/180*camera.xRot,0));
        state.item.submit(poses,nodes,state.lightCoords,OverlayTexture.NO_OVERLAY,state.outlineColor);poses.popPose();
        super.submit(state,poses,nodes,camera);
    }
}
