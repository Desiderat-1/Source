// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker;

import net.minecraft.world.entity.EntityTypes;


import com.kyanite.deeperdarker.content.*;
import com.kyanite.deeperdarker.network.Messages;
import com.kyanite.deeperdarker.util.DDConfig;
import com.kyanite.deeperdarker.util.DDCreativeTab;
import com.kyanite.deeperdarker.util.DDLootItemFunctions;
import com.kyanite.deeperdarker.util.SimpleWorleyNoise;
import com.kyanite.deeperdarker.util.recipes.DDRecipeSerializers;
import com.kyanite.deeperdarker.world.DDCarvers;
import com.kyanite.deeperdarker.world.DDFeatures;
import com.kyanite.deeperdarker.world.otherside.gen.OthersideGeneration;
import com.kyanite.deeperdarker.world.otherside.structures.DDStructurePieceTypes;
import com.kyanite.deeperdarker.world.otherside.structures.DDStructureTypes;
import com.kyanite.deeperdarker.world.otherside.structures.maze.rooms.RoomTypeRegistry;
import dev.kyanitemods.kyaniteportals.api.SimplePortalBuilder;
import dev.kyanitemods.kyaniteportals.content.Portal;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.dimension.LevelStem;
import net.minecraft.world.level.storage.loot.BuiltInLootTables;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.functions.SetItemCountFunction;
import net.minecraft.world.level.storage.loot.predicates.LootItemRandomChanceCondition;
import net.minecraft.world.level.storage.loot.providers.number.ints.UniformGenerator;
import net.minecraft.world.level.storage.loot.providers.number.ints.ConstantValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DeeperDarker implements ModInitializer {
	public static final String MOD_ID = "deeperdarker";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static final DDConfig CONFIG = com.kyanite.deeperdarker.util.DDSettings.CONFIG;

	public static final ResourceKey<Portal> OTHERSIDE_PORTAL = SimplePortalBuilder.create()
			.frame(Blocks.REINFORCED_DEEPSLATE)
			.ignition(DDItems.HEART_OF_THE_DEEP)
			.ignition(DDBlocks.SCULK_FIRE)
			.fromDimension(LevelStem.OVERWORLD)
			.toDimension(OthersideGeneration.OTHERSIDE_STEM)
			.color((5 << 16) | (98 << 8) | 93)
			.replaceable(Blocks.AIR, Blocks.CAVE_AIR, Blocks.VOID_AIR, Blocks.SCULK_VEIN, DDBlocks.SCULK_FIRE)
			.ambientSound(Holder.direct(DDSounds.PORTAL_GROAN))
			.generatedSize(10, 6)
			.register(Identifier.fromNamespaceAndPath(MOD_ID, "otherside"));;

	@Override
	public void onInitialize() {
        com.kyanite.deeperdarker.content.components.DDDataComponents.init();
		DDCreativeTab.init();
		DDItems.init();
		DDBlocks.init();
		DDFeatures.init();
		DDSounds.init();
		DDPotions.init();
		DDEnchantments.init();
		DDEntities.init();
		DDBlockEntities.init();
		DDEffects.init();
		AncientPaintings.init();
		DDLootItemFunctions.init();
		DDRecipeSerializers.init();
		DDStructurePieceTypes.init();
		DDStructureTypes.init();
		RoomTypeRegistry.init();
		DDCarvers.init();
		DDParticleTypes.init();
		DDFluids.init();
		DDCriteriaTriggers.init();

		LootTableEvents.MODIFY.register((id, tableBuilder, source, registries) -> {
            // The engine now handles the charged creeper's one-skull limit through this loot table.
            if (BuiltInLootTables.CHARGED_CREEPER.equals(id)) {
                tableBuilder.withPool(LootPool.lootPool().add(LootItem.lootTableItem(DDItems.SHATTERED_HEAD))
                        .when(net.minecraft.world.level.storage.loot.predicates.LootItemEntityPropertyCondition.hasProperties(
                                net.minecraft.world.level.storage.loot.LootContext.EntityTarget.THIS,
                                net.minecraft.advancements.predicates.entity.EntityPredicate.Builder.entity()
                                        .of(registries.lookupOrThrow(net.minecraft.core.registries.Registries.ENTITY_TYPE), DDEntities.SHATTERED))));
            }
			if (EntityTypes.WARDEN.getDefaultLootTable().filter(id::equals).isPresent() && CONFIG.server.addWardenDrops()) {
				LootPool.Builder carapacePoolBuilder = LootPool.lootPool()
						.add(LootItem.lootTableItem(DDItems.WARDEN_CARAPACE).apply(SetItemCountFunction.setCount(
                                Holder.direct(new UniformGenerator(Holder.direct(new ConstantValue(1)), Holder.direct(new ConstantValue(3)))))));
				LootPool.Builder heartPoolBuilder = LootPool.lootPool()
						.add(LootItem.lootTableItem(DDItems.HEART_OF_THE_DEEP));

				tableBuilder.withPool(carapacePoolBuilder);
				tableBuilder.withPool(heartPoolBuilder);
			}
			if (BuiltInLootTables.ANCIENT_CITY.equals(id) && CONFIG.server.addAncientCityLoot()) {
				LootPool.Builder carapacePoolBuilder = LootPool.lootPool()
						.add(LootItem.lootTableItem(DDItems.WARDEN_CARAPACE)
								.when(LootItemRandomChanceCondition.randomChance(0.2f)));
				LootPool.Builder wardenUpgradePoolBuilder = LootPool.lootPool()
						.add(LootItem.lootTableItem(DDItems.WARDEN_UPGRADE_SMITHING_TEMPLATE))
						.when(LootItemRandomChanceCondition.randomChance(0.2f));

				tableBuilder.withPool(carapacePoolBuilder);
				tableBuilder.withPool(wardenUpgradePoolBuilder);
			}
		});


		Messages.registerReceivers();
	}
}
