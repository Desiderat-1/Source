// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28 (AGPL-3.0).
package com.kyanite.deeperdarker.world.otherside;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.dimension.DimensionType;
public final class OthersideDimension {
    public static final ResourceKey<Level> OTHERSIDE_LEVEL = ResourceKey.create(Registries.DIMENSION, Identifier.fromNamespaceAndPath("deeperdarker", "otherside"));
    public static final ResourceKey<DimensionType> OTHERSIDE = ResourceKey.create(Registries.DIMENSION_TYPE, Identifier.fromNamespaceAndPath("deeperdarker", "otherside"));
    public static final Identifier OTHERSIDE_EFFECTS = Identifier.fromNamespaceAndPath("deeperdarker", "otherside_effects");
    private OthersideDimension() {}
}
