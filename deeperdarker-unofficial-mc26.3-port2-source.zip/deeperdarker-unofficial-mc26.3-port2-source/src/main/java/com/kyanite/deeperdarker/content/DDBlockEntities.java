// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.content;

import com.kyanite.deeperdarker.DeeperDarker;
import com.kyanite.deeperdarker.content.entities.blocks.*;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.util.Util;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.util.datafix.fixes.References;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import com.mojang.datafixers.types.Type;

public class DDBlockEntities {
    public static final BlockEntityType<DDHangingSignBlockEntity> HANGING_SIGN;
    public static final BlockEntityType<DDSignBlockEntity> SIGN;
    public static final BlockEntityType<CrystallizedAmberBlockEntity> CRYSTALLIZED_AMBER;
    public static final BlockEntityType<DDSkullBlockEntity> SKULL;
    public static final BlockEntityType<SculkJawBlockEntity> SCULK_JAW;
    public static final BlockEntityType<ReturnStatueBlockEntity> RETURN_STATUE;
    public static final BlockEntityType<IcicleBlockEntity> ICICLE;
    public static final BlockEntityType<DarkFountainBlockEntity> DARK_FOUNTAIN;
    public static final BlockEntityType<DDCampfireBlockEntity> CAMPFIRE;
    public static final BlockEntityType<DeadMansChestBlockEntity> DEAD_MANS_CHEST;

    static {
        HANGING_SIGN = create("hanging_sign", FabricBlockEntityTypeBuilder.create(
                DDHangingSignBlockEntity::new,
                DDBlocks.ECHO_HANGING_SIGN, DDBlocks.ECHO_WALL_HANGING_SIGN,
                DDBlocks.BLOOM_HANGING_SIGN, DDBlocks.BLOOM_WALL_HANGING_SIGN,
                DDBlocks.SCULK_SPRUCE_HANGING_SIGN, DDBlocks.SCULK_SPRUCE_WALL_HANGING_SIGN
        ));
        SIGN = create("sign", FabricBlockEntityTypeBuilder.create(
                DDSignBlockEntity::new,
                DDBlocks.ECHO_SIGN, DDBlocks.ECHO_WALL_SIGN,
                DDBlocks.BLOOM_SIGN, DDBlocks.BLOOM_WALL_SIGN,
                DDBlocks.SCULK_SPRUCE_SIGN, DDBlocks.SCULK_SPRUCE_WALL_SIGN
        ));
        CRYSTALLIZED_AMBER = create("crystallized_amber", FabricBlockEntityTypeBuilder.create(
                CrystallizedAmberBlockEntity::new,
                DDBlocks.CRYSTALLIZED_AMBER
        ));
        SKULL = create("skull", FabricBlockEntityTypeBuilder.create(
                DDSkullBlockEntity::new,
                DDBlocks.SHATTERED_HEAD,
                DDBlocks.SHATTERED_WALL_HEAD
        ));
        SCULK_JAW = create("sculk_jaw", FabricBlockEntityTypeBuilder.create(
                SculkJawBlockEntity::new,
                DDBlocks.SCULK_JAW
        ));
        RETURN_STATUE = create("return_statue", FabricBlockEntityTypeBuilder.create(
                ReturnStatueBlockEntity::new,
                DDBlocks.RETURN_STATUE
        ));
        ICICLE = create("icicle", FabricBlockEntityTypeBuilder.create(
                IcicleBlockEntity::new,
                DDBlocks.ICICLE
        ));
        DARK_FOUNTAIN = create("dark_fountain", FabricBlockEntityTypeBuilder.create(
                DarkFountainBlockEntity::new,
                DDBlocks.DARK_FOUNTAIN
        ));
        CAMPFIRE = create("campfire", FabricBlockEntityTypeBuilder.create(
                DDCampfireBlockEntity::new,
                DDBlocks.SCULK_CAMPFIRE
        ));
        DEAD_MANS_CHEST = create("dead_mans_chest", FabricBlockEntityTypeBuilder.create(
                DeadMansChestBlockEntity::new,
                DDBlocks.DEAD_MANS_CHEST
        ));
    }

    public static <T extends BlockEntity> BlockEntityType<T> create(String id, FabricBlockEntityTypeBuilder<T> builder) {
        return Registry.register(BuiltInRegistries.BLOCK_ENTITY_TYPE, Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, id), builder.build(null));
    }

    public static void init() {
        DeeperDarker.LOGGER.debug("Registering block entities");
    }
}
