// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.mixin;

import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.levelgen.densityfunction.DensityFunction;
import net.minecraft.world.level.levelgen.NoiseRouterData;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(NoiseRouterData.class)
public interface NoiseRouterDataAccessor {
    @Accessor("SHIFT_X")
    static ResourceKey<DensityFunction> shiftX() {
        throw new IllegalStateException("Replaced by mixin");
    }

    @Accessor("SHIFT_Z")
    static ResourceKey<DensityFunction> shiftZ() {
        throw new IllegalStateException("Replaced by mixin");
    }

    @Accessor("BASE_3D_NOISE_NETHER")
    static ResourceKey<DensityFunction> base3dNoiseNether() {
        throw new IllegalStateException("Replaced by mixin");
    }

    @Accessor("BASE_3D_NOISE_OVERWORLD")
    static ResourceKey<DensityFunction> base3dNoiseOverworld() {
        throw new IllegalStateException("Replaced by mixin");
    }
}
