// Development generator separated during the 26.3 port; its API migration is pending.
// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.world.otherside;

import com.kyanite.deeperdarker.DeeperDarker;
import com.kyanite.deeperdarker.util.DDTags;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.worldgen.BootstrapContext;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.util.valueproviders.ConstantInt;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.dimension.DimensionType;

import java.util.OptionalLong;

public class OthersideDimensionBootstrap {
    public static final ResourceKey<Level> OTHERSIDE_LEVEL = ResourceKey.create(Registries.DIMENSION, Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "otherside"));
    public static final ResourceKey<DimensionType> OTHERSIDE = ResourceKey.create(Registries.DIMENSION_TYPE, Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "otherside"));
    public static final Identifier OTHERSIDE_EFFECTS = Identifier.fromNamespaceAndPath(DeeperDarker.MOD_ID, "otherside_effects");

    public static void bootstrap(BootstrapContext<DimensionType> context) {
        context.register(OTHERSIDE, new DimensionType(OptionalLong.of(18000L), false, true, false, true, 1, true, false, 0, 128, 128, DDTags.Blocks.INFINIBURN_OTHERSIDE, OTHERSIDE_EFFECTS, 0.0f, new DimensionType.MonsterSettings(true, false, ConstantInt.of(7), 15)));
    }
}