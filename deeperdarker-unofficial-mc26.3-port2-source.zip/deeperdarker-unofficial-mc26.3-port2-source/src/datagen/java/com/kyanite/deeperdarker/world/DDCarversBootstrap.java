// Unofficial Minecraft 26.3 port: API migration by Desiderat, 2026-10-28.
package com.kyanite.deeperdarker.world;

import com.kyanite.deeperdarker.DeeperDarker;
import com.kyanite.deeperdarker.content.DDBlocks;
import com.kyanite.deeperdarker.util.DDTags;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.worldgen.BootstrapContext;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.util.valueproviders.UniformFloat;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.levelgen.VerticalAnchor;
import net.minecraft.world.level.levelgen.carver.*;
import net.minecraft.world.level.levelgen.heightproviders.UniformHeight;

import static com.kyanite.deeperdarker.world.DDCarvers.*;

/** Original generator recipe retained for the separate, still-unported datagen source set. */
public final class DDCarversBootstrap {
    public static void bootstrap(BootstrapContext<ConfiguredWorldCarver<?>> context) {
        HolderGetter<Block> blocks = context.lookup(Registries.BLOCK);
        context.register(CONFIGURED_LARGE_CAVE, WorldCarver.CAVE.configured(new CaveCarverConfiguration(
                0.65f,
                UniformHeight.of(VerticalAnchor.aboveBottom(10), VerticalAnchor.belowTop(10)),
                UniformFloat.of(0.4f, 0.9f),
                VerticalAnchor.bottom(),
                CarverDebugSettings.of(false, DDBlocks.BLOOM_BUTTON.defaultBlockState()),
                blocks.getOrThrow(DDTags.Blocks.OTHERSIDE_CARVER_REPLACEABLES),
                UniformFloat.of(0.9f, 1.5f),
                UniformFloat.of(1.1f, 1.3f),
                UniformFloat.of(-1, -0.4f)
        )));
        context.register(CONFIGURED_CAVE, WorldCarver.CAVE.configured(new CaveCarverConfiguration(
                0.22f,
                UniformHeight.of(VerticalAnchor.aboveBottom(10), VerticalAnchor.belowTop(10)),
                UniformFloat.of(0.1f, 0.9f),
                VerticalAnchor.bottom(),
                CarverDebugSettings.of(false, DDBlocks.BLOOM_BUTTON.defaultBlockState()),
                blocks.getOrThrow(DDTags.Blocks.OTHERSIDE_CARVER_REPLACEABLES),
                UniformFloat.of(0.7f, 1.4f),
                UniformFloat.of(0.8f, 1.3f),
                UniformFloat.of(-1, -0.4f)
        )));
        context.register(CONFIGURED_LOW_CAVE, WorldCarver.CAVE.configured(new CaveCarverConfiguration(
                0.3f,
                UniformHeight.of(VerticalAnchor.aboveBottom(10), VerticalAnchor.aboveBottom(32)),
                UniformFloat.of(0.1f, 0.9f),
                VerticalAnchor.aboveBottom(15),
                CarverDebugSettings.of(false, DDBlocks.ECHO_BUTTON.defaultBlockState()),
                blocks.getOrThrow(DDTags.Blocks.OTHERSIDE_CARVER_REPLACEABLES),
                UniformFloat.of(0.6f, 1.1f),
                UniformFloat.of(0.8f, 1.1f),
                UniformFloat.of(-1, -0.4f)
        )));
        context.register(CONFIGURED_NOODLES, NOODLES.configured(new CaveCarverConfiguration(
                0.22f,
                UniformHeight.of(VerticalAnchor.aboveBottom(1), VerticalAnchor.belowTop(1)),
                UniformFloat.of(0.1f, 0.9f),
                VerticalAnchor.bottom(),
                CarverDebugSettings.of(false, DDBlocks.BLOOM_BUTTON.defaultBlockState()),
                blocks.getOrThrow(DDTags.Blocks.OTHERSIDE_CARVER_REPLACEABLES),
                UniformFloat.of(0.7f, 1.4f),
                UniformFloat.of(0.8f, 1.3f),
                UniformFloat.of(-1, -0.4f)
        )));
    }

}
