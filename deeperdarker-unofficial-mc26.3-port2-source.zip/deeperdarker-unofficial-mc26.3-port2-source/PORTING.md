# Deeper and Darker — unofficial 26.3 experimental port

Original project: https://github.com/KyaniteMods/DeeperAndDarker
Original authors: Kyanite Mods and the contributors in AUTHORS.
Port changes: Desiderat, with AI assistance, 2026-10-28.
License: AGPL-3.0. This is an unofficial port, not an approved upstream release.

## Provenance

The supplied original alpha JAR has SHA-1
`f2ddd45551bd5f681f7ca0a3999f452778f140dc`, matching Modrinth version
JRleU5be (2.0.0s-alpha.1+1.20.1), published 2026-07-11.

The source baseline is commit `3c7b62f300dc52f7c4adac03beb36a137bb403c6`
on `fabric-1.20.x-2.0.0s`: the last commit before that publication, not an exact
verified upstream release tag. Original LICENSE and AUTHORS are retained.

Kyanite Portals is ported from MIT source commit
`c46229ee57915a22c35f10b4768bec46cfb4ce9a`, upstream version 0.1.8 for 1.21.11.
Its source and license are included under `port-libs/kyanite-portals-26.3`.
Jankson 1.2.3 is MIT licensed; its license is included alongside the dependency.

## Target and installation

- Minecraft Java Edition 26.3; Java 25.
- Fabric Loader 0.20.1+; Fabric API 0.165.0+26.3.
- Install this mod and Fabric API on both the client and server.
- Kyanite Portals and Jankson are nested dependencies, included in the mod JAR.
- This is an experimental port of an alpha mod. Existing 1.20.1 world upgrades
  and long multiplayer sessions have not been validated.

## Runtime migration

### Port 2: acid-floes generation crash

The original 48-block floes scan used chunk-backed, zoomed biome lookups.
At the scan boundary these may sample a chunk two chunks from the generation
center. Minecraft 26.3 only guarantees structure-start data at that distance,
so requesting stored biomes throws `Requested chunk unavailable during world generation`.
Floes now retain the original biome zoom and terrain footprint while resolving
biomes directly from the world-generation resolver, without loading that chunk.
The regression test uses a fixed seed and the failing chunk at (-24, -7), checks
the surrounding nine chunks and verifies that sculk-basalt floes still generate.

The main runtime and required portal dependency compile against the real 26.3
APIs. Ported systems include registration, item/equipment components, five typed
network payloads, effects and brewing, enchantments, recipes, saved recovery data,
block callbacks and block entities, mobs and boss phases, rendering extraction
states, models, custom beam geometry/shaders, HUD, fluid interactions, portals,
structure codecs, carvers and the Otherside data pack.

The original Otherside noise functions, surfaces, biomes and feature settings
were migrated to native 26.3 density functions, material rules, feature and biome
schemas. Generation uses the new Minecraft engine; identical 1.20.1 terrain for
a given seed is not promised. The original source resources remain in the source
archive; migrated runtime data is in `src/portGenerated` with explicit overrides
in `src/main/resources`.

The old configuration generator/backend was replaced by Java configuration
handling. All 22 defaults/getters are preserved. JSON5 migration preserves the
original files, validates values and saves canonical JSON. There is no new
in-game configuration screen; configure the files in the game's config folder.

## Validation performed

Tests use actual Minecraft classes, registries, server worlds and client rendering.
No API stubs or replacement vanilla classes are used.

- Full mod server integration: five required GameTests pass. They load every
  expected runtime resource: 8 biomes, 66 features, 61 placed features, 7 structures,
  226 active loot tables, 318 advancements, 327 recipes and 104 structure templates.
- All 21 mod blocks with block entities construct and save/load the correct custom
  types, including skulls, signs, hanging signs, campfires and the special chest.
- Three real Otherside chunks at positive/negative coordinates generate through
  terrain, carving, decoration and structure generation, with the 128-block height.
- Actual reinforced-deepslate portals ignite with Heart of the Deep. An entity
  standing inside travels automatically from Overworld to Otherside; the actual
  return actions transport it back.
- A real integrated client world connects the player to Otherside, renders chunks,
  places custom block entities, spawns six custom entity types, equips horns,
  sunglasses and Soul Elytra, and immerses the player in acid. Both server and
  client report the expected Sculk Gleam light level. Screenshots were inspected.
- The complete client resource reload and item-model baking run successfully.
  Custom crystal-trail shaders compile on an actual OpenGL device.
- Earlier focused tests: 20 required Minecraft tests cover selected equipment,
  recipes, typed/legacy item data, brewing/effects, recovery-data migration,
  enchantments, shield augments, shared boss combat, Centipede/Snapper behavior,
  paintings, Hemophilia, Resonarium, Reinvoked and acid tracking/damage/movement.
  Configuration, payload codecs, model poses and 306 inventory model definitions
  also pass their focused checks.

Full-server test: `gradlew.bat runIntegrationGameTest`.
Full-client test: `gradlew.bat runIntegrationWorldClientSmoke`.
Focused tests are available through the separate `port-diagnostics` project.
Do not run tasks that rewrite shared build resources while a game test is active.

The GameTest-only flat preset includes the actual Otherside generator because
Minecraft's GameTestServer ignores standalone dimension registry entries.
The ordinary integrated-world test separately confirms normal dimension loading.

## Known limitations

- The configuration GUI is not ported; settings remain available in configuration files.
- Create and Show Me Your Skin adapters are preserved in separate source sets and
  are not active in this port. The Tom's Storage adapter matches its 26.3 method
  signature, but a combined game session with that mod has not been tested.
- Developer data generators are preserved separately and are not compiled by the
  runtime build. Their generated content has been migrated as runtime resources.
- Both the original alpha source and supplied release JAR lack the three listed
  music tracks. Those events remain silent; no replacement music is invented.
- Boss AI, every item interaction, every structure placement, every particle and
  extended multiplayer play have not each been exhaustively tested. Passing the
  listed checks is not a claim that the original alpha or this port is bug free.

## Building and redistribution

Use Java 25 and the included Gradle wrapper: `gradlew.bat build` or `./gradlew build`.
Build outputs are in `build/libs`. Only the runtime JAR belongs in the mods folder.
The complete source archive includes the build scripts/wrapper, source/resources
and dependency source needed to rebuild the distribution. Keep the source archive
available alongside the binary when redistributing this AGPL-3.0 port.
