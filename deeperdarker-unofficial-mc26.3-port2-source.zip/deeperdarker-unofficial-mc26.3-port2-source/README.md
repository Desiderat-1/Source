# Deeper and Darker — unofficial Minecraft 26.3 port

Experimental port by Desiderat, with AI assistance. Original mod by Kyanite Mods.
This project is not an official Kyanite Mods release.

Requires Minecraft 26.3, Java 25, Fabric Loader 0.20.1+ and Fabric API 0.165.0+26.3.
Install the mod JAR and Fabric API on both the client and server. The ported portal
implementation and Jankson parser are included in the mod JAR.

Build the runtime mod with Java 25: `gradlew.bat build` on Windows, or
`./gradlew build` elsewhere. The Gradle wrapper downloads the build dependencies.
The complete corresponding source archive contains the Gradle build, wrapper,
all runtime source/resources and the MIT portal dependency source.

See PORTING.md for provenance, tests and known limits. This port retains AGPL-3.0.
