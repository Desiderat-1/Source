// Unofficial 26.3 port, 2026-10-28. Original library and changes: MIT.
package dev.kyanitemods.kyaniteportals.mixin;

import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Lifecycle;
import dev.kyanitemods.kyaniteportals.KyanitePortals;
import net.minecraft.resources.RegistryDataLoader;
import net.minecraft.resources.RegistryLoadTask;
import net.minecraft.resources.RegistryOps;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceManagerRegistryLoadTask;
import net.minecraft.core.RegistrationInfo;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.stream.Stream;

/** Merge programmatic portals into the new asynchronous registry loading task. */
@Mixin(ResourceManagerRegistryLoadTask.class)
public abstract class AddPortalToRegistryMixin<T> extends RegistryLoadTask<T> {
    @Unique private RegistryOps.RegistryInfoLookup kyanitePortals$lookup;

    protected AddPortalToRegistryMixin(RegistryDataLoader.RegistryData<T> data, Lifecycle lifecycle,
            Map<ResourceKey<?>, Exception> errors) {
        super(data, lifecycle, errors);
    }

    @Inject(method = "load", at = @At("HEAD"))
    private void kyanitePortals$captureLookup(RegistryOps.RegistryInfoLookup lookup, Executor executor,
            CallbackInfoReturnable<CompletableFuture<?>> cir) {
        kyanitePortals$lookup = lookup;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    @ModifyArg(method = "lambda$load$3", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/resources/ResourceManagerRegistryLoadTask;registerElements(Ljava/util/stream/Stream;)V"), index = 0)
    private Stream<PendingRegistration<T>> kyanitePortals$addPortals(Stream<PendingRegistration<T>> resources) {
        if (!registryKey().equals(KyanitePortals.RESOURCE_KEY)) return resources;
        Stream<PendingRegistration<T>> builders = KyanitePortals.PORTAL_REGISTRY_OVERRIDES.entrySet().stream()
                .map(entry -> new PendingRegistration((ResourceKey) entry.getKey(),
                        Either.left(entry.getValue().apply(kyanitePortals$lookup)), RegistrationInfo.BUILT_IN));
        return Stream.concat(builders, resources);
    }
}
