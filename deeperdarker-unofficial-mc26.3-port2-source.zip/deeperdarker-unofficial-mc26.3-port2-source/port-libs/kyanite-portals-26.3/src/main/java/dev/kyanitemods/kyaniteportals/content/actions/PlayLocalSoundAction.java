// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28. Original library: MIT.
package dev.kyanitemods.kyaniteportals.content.actions;

//? if <1.20.6 {
/*import com.mojang.serialization.Codec;
*///? } else
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.kyanitemods.kyaniteportals.content.actions.location.ActionLocation;
import dev.kyanitemods.kyaniteportals.content.registry.PortalActions;
import dev.kyanitemods.kyaniteportals.util.StonecutterUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.valueproviders.FloatProvider;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public final class PlayLocalSoundAction extends PortalAction<PlayLocalSoundAction> {
    //$ map_codec_swap PlayLocalSoundAction
    public static final com.mojang.serialization.MapCodec<PlayLocalSoundAction> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            Settings.optionalLocation(),
            SoundEvent.CODEC.fieldOf("sound_event").forGetter(PlayLocalSoundAction::soundEvent),
            net.minecraft.util.valueproviders.FloatProviders.CODEC.fieldOf("volume").forGetter(PlayLocalSoundAction::volume),
            net.minecraft.util.valueproviders.FloatProviders.CODEC.fieldOf("pitch").forGetter(PlayLocalSoundAction::pitch)
    ).apply(instance, PlayLocalSoundAction::new));

    private final Holder<SoundEvent> soundEvent;
    private final FloatProvider volume;
    private final FloatProvider pitch;

    public PlayLocalSoundAction(Settings settings, Holder<SoundEvent> soundEvent, FloatProvider volume, FloatProvider pitch) {
        super(settings);
        this.soundEvent = soundEvent;
        this.volume = volume;
        this.pitch = pitch;
    }

    @Override
    public PortalActionType<PlayLocalSoundAction> getType() {
        return PortalActions.PLAY_LOCAL_SOUND;
    }

    @Override
    public PortalActionResult execute(Level level, BlockPos pos, @Nullable Entity entity, ActionExecutionData data) {
        ActionLocation location = getSettings().locationOptions().get(level, pos, entity, level.getRandom(), data);
        if (level.isClientSide() && entity == null) {
            level.playLocalSound(location.position().x(), location.position().y(), location.position().z(), soundEvent().value(), SoundSource.AMBIENT, volume().sample(level.getRandom()), pitch().sample(level.getRandom()), false);
            return PortalActionResult.SUCCESS;
        }
        if (!(entity instanceof ServerPlayer player)) return PortalActionResult.FAILURE;

        Optional<ServerLevel> optional = location.getWorld(level);
        if (optional.isEmpty() || !StonecutterUtil.getIdentifier(entity.level().dimension()).equals(StonecutterUtil.getIdentifier(optional.get().dimension()))) return PortalActionResult.FAILURE;

        player.connection.send(new ClientboundSoundPacket(soundEvent(), SoundSource.AMBIENT, location.position().x(), location.position().y(), location.position().z(), volume().sample(level.getRandom()), pitch().sample(level.getRandom()), level.getRandom().nextLong()));
        return PortalActionResult.SUCCESS;
    }

    public Holder<SoundEvent> soundEvent() {
        return soundEvent;
    }

    public FloatProvider volume() {
        return volume;
    }

    public FloatProvider pitch() {
        return pitch;
    }
}
