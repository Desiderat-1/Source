/* Copyright (c) 2026 Desiderat. MIT; see the library LICENSE. */
package dev.kyanitemods.kyaniteportals.util;

import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import java.util.Arrays;
import java.util.List;
import net.minecraft.advancements.predicates.entity.EntityPredicate;
import net.minecraft.core.Holder;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;

/** Portal conditions retain their AND semantics after vanilla removed ContextAwarePredicate. */
public record PortalContextPredicate(List<Holder<LootItemCondition>> conditions) {
    public static final Codec<PortalContextPredicate> CODEC = Codec.either(
            LootItemCondition.CODEC.listOf(), EntityPredicate.CODEC
    ).xmap(either -> either.map(PortalContextPredicate::new, PortalContextPredicate::wrap),
            predicate -> Either.left(predicate.conditions()));

    public PortalContextPredicate {
        conditions = List.copyOf(conditions);
    }

    public static PortalContextPredicate create(LootItemCondition... conditions) {
        return new PortalContextPredicate(Arrays.stream(conditions)
                .<Holder<LootItemCondition>>map(Holder::direct).toList());
    }

    public static PortalContextPredicate wrap(EntityPredicate predicate) {
        return new PortalContextPredicate(List.of(EntityPredicate.wrap(predicate)));
    }

    public boolean matches(LootContext context) {
        for (Holder<LootItemCondition> condition : conditions) {
            if (!condition.value().test(context)) return false;
        }
        return true;
    }
}
