// Unofficial 26.3 port; MIT. Nausea is extracted before rendering.
package dev.kyanitemods.kyaniteportals.mixin.client;
import dev.kyanitemods.kyaniteportals.client.PortalOverlayPlayer;
import dev.kyanitemods.kyaniteportals.client.content.effects.PortalEffects;
import dev.kyanitemods.kyaniteportals.content.interfaces.EntityInPortal;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.renderer.extract.LevelExtractor;
import net.minecraft.client.renderer.state.level.PlayerRenderState;
import net.minecraft.util.Mth;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(LevelExtractor.class)
public class NauseaMixin {
    @Inject(method = "extractPlayerState", at = @At("TAIL"))
    private void kyanitePortals$extractNausea(Camera camera, DeltaTracker tracker, float partialTick,
            PlayerRenderState state, CallbackInfo ci) {
        var player = Minecraft.getInstance().player;
        if (player == null || ((EntityInPortal) player).getPortal() == null
                || PortalEffects.get(((EntityInPortal) player).getPortal(), PortalEffects.NAUSEA).isEmpty()) return;
        var overlay = (PortalOverlayPlayer) player;
        state.portalEffectIntensity = Math.max(state.portalEffectIntensity,
                Mth.lerp(partialTick, overlay.getOldPortalIntensity(), overlay.getPortalIntensity()));
    }
}
