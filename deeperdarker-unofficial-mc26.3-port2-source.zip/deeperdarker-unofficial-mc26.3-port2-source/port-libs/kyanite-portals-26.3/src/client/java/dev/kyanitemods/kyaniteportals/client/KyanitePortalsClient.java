// Unofficial Minecraft 26.3 port by Desiderat, 2026-10-28. Original library: MIT.
package dev.kyanitemods.kyaniteportals.client;

import dev.kyanitemods.kyaniteportals.KyanitePortals;
import dev.kyanitemods.kyaniteportals.client.content.effects.PortalEffectManager;
import dev.kyanitemods.kyaniteportals.client.content.particles.CustomPortalParticle;
import dev.kyanitemods.kyaniteportals.content.blocks.entities.CustomPortalBlockEntity;
import dev.kyanitemods.kyaniteportals.content.registry.KyanitePortalsBlocks;
import dev.kyanitemods.kyaniteportals.content.registry.KyanitePortalsParticleTypes;
import net.fabricmc.api.ClientModInitializer;
// 26.1 Fabric API changes BlockRenderLayerMap to ChunkSectionLayerMap
//? if <1.21.6 {
/*import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.minecraft.client.renderer.rendertype.RenderType;
*///? } else {
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
//? }
import net.fabricmc.fabric.api.client.networking.v1.ClientLoginConnectionEvents;
import net.fabricmc.fabric.api.client.particle.v1.ParticleProviderRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.BlockColorRegistry;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.minecraft.server.packs.PackType;

public class KyanitePortalsClient implements ClientModInitializer {
    public static final PortalEffectManager PORTAL_EFFECT_MANAGER = new PortalEffectManager();

    @Override
    public void onInitializeClient() {
        ResourceManagerHelper.get(PackType.CLIENT_RESOURCES).registerReloadListener(PORTAL_EFFECT_MANAGER);
        ParticleProviderRegistry.getInstance().register(KyanitePortalsParticleTypes.PORTAL, CustomPortalParticle.Provider::new);
        ClientLoginConnectionEvents.INIT.register((handler, client) -> {
            if (client.level != null) {
                KyanitePortals.reloadListeners(client.level.registryAccess());
            }
        });

        //? if <1.21.6 {
        /*BlockRenderLayerMap.INSTANCE.putBlock(KyanitePortalsBlocks.CUSTOM_PORTAL, RenderType.translucent());
        *///? } else        BlockColorRegistry.register(java.util.List.of(new net.minecraft.client.color.block.BlockTintSource() {
            @Override
            public int color(net.minecraft.world.level.block.state.BlockState state) {
                return 0xFFFFFFFF;
            }

            @Override
            public int colorInWorld(net.minecraft.world.level.block.state.BlockState state,
                    net.minecraft.client.renderer.block.BlockAndTintGetter level, net.minecraft.core.BlockPos pos) {
                if (level.getBlockEntity(pos) instanceof CustomPortalBlockEntity blockEntity) {
                    return 0xFF000000 | blockEntity.getColor();
                }
                return color(state);
            }
        }), KyanitePortalsBlocks.CUSTOM_PORTAL);
    }
}
