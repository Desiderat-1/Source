// Unofficial 26.3 port; MIT.
package dev.kyanitemods.kyaniteportals.mixin.client;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import dev.kyanitemods.kyaniteportals.client.PortalOverlayPlayer;
import dev.kyanitemods.kyaniteportals.client.content.effects.PortalEffects;
import dev.kyanitemods.kyaniteportals.content.interfaces.EntityInPortal;
import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
@Mixin(LocalPlayer.class)
public class NauseaSpeedMixin {
    @WrapOperation(method = "tickSpinningEffect", at = @At(value = "FIELD",
            target = "Lnet/minecraft/client/player/LocalPlayer;portalEffectIntensity:F"))
    private float kyanitePortals$applySpeed(LocalPlayer player, Operation<Float> original) {
        float vanilla = original.call(player);
        var key = ((EntityInPortal) player).getPortal();
        if (key == null || PortalEffects.get(key, PortalEffects.NAUSEA).isEmpty()) return vanilla;
        return Math.max(vanilla, ((PortalOverlayPlayer) player).getPortalIntensity());
    }
}
