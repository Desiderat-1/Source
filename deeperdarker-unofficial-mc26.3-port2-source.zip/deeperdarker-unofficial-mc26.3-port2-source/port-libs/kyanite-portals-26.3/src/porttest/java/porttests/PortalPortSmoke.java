package porttests;

import dev.kyanitemods.kyaniteportals.KyanitePortals;
import dev.kyanitemods.kyaniteportals.content.registry.KyanitePortalsBlocks;
import dev.kyanitemods.kyaniteportals.content.blocks.entities.CustomPortalBlockEntity;
import net.fabricmc.fabric.api.gametest.v1.GameTest;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTestHelper;

public final class PortalPortSmoke {
    @GameTest
    public void portalRegistration(GameTestHelper helper) {
        var portals = helper.getLevel().registryAccess().lookupOrThrow(KyanitePortals.RESOURCE_KEY);
        if (portals.get(KyanitePortals.id("test_portal")).isEmpty()) throw new AssertionError("Builder portal missing from dynamic registry");
        helper.setBlock(new BlockPos(1, 2, 1), KyanitePortalsBlocks.CUSTOM_PORTAL);
        if (!(helper.getLevel().getBlockEntity(helper.absolutePos(new BlockPos(1, 2, 1))) instanceof CustomPortalBlockEntity)) throw new AssertionError("Portal block entity missing");
        helper.succeed();
    }

    @GameTest
    public void igniteAndTravelBothWays(GameTestHelper helper) {
        var origin = helper.absolutePos(new BlockPos(1, 2, 1));
        var entryLevel = helper.getLevel();
        var exitLevel = entryLevel.getServer().getLevel(net.minecraft.world.level.Level.END);
        if (exitLevel == null) throw new AssertionError("End dimension missing");
        var exit = new BlockPos(origin.getX(), 80, origin.getZ());
        frame(entryLevel, origin);
        frame(exitLevel, exit);
        ignite(entryLevel, origin);
        ignite(exitLevel, exit);
        var key = net.minecraft.resources.ResourceKey.create(KyanitePortals.RESOURCE_KEY, KyanitePortals.id("test_portal"));
        var portal = entryLevel.registryAccess().lookupOrThrow(KyanitePortals.RESOURCE_KEY).getOrThrow(key).value();
        var ops = entryLevel.registryAccess().createSerializationContext(com.mojang.serialization.JsonOps.INSTANCE);
        var json = dev.kyanitemods.kyaniteportals.content.Portal.CODEC.encodeStart(ops, portal).getOrThrow();
        dev.kyanitemods.kyaniteportals.content.Portal.CODEC.parse(ops, json).getOrThrow();
        var cow = helper.spawn(net.minecraft.world.entity.EntityTypes.COW, new BlockPos(1, 2, 1));
        cow.setNoAi(true);
        cow.setPos(net.minecraft.world.phys.Vec3.atBottomCenterOf(origin));
        var uuid = cow.getUUID();
        helper.runAfterDelay(2, () -> {
            dev.kyanitemods.kyaniteportals.content.Portal.executeAll(entryLevel, origin, cow, portal.travelActions());
            var arrived = exitLevel.getEntity(uuid);
            if (arrived == null || arrived.level() != exitLevel) throw new AssertionError("Portal did not teleport to End");
            arrived.setPos(net.minecraft.world.phys.Vec3.atBottomCenterOf(exit));
            arrived.setPortalCooldown(0);
            dev.kyanitemods.kyaniteportals.content.Portal.executeAll(exitLevel, exit, arrived, portal.travelActions());
            if (entryLevel.getEntity(uuid) == null) throw new AssertionError("Portal did not return to Overworld");
            helper.succeed();
        });
    }

    private static void frame(net.minecraft.server.level.ServerLevel level, BlockPos interior) {
        for (int x = -1; x <= 2; x++) for (int y = -1; y <= 3; y++) {
            level.setBlock(interior.offset(x, y, 0), (x == -1 || x == 2 || y == -1 || y == 3)
                    ? net.minecraft.world.level.block.Blocks.OBSIDIAN.defaultBlockState()
                    : net.minecraft.world.level.block.Blocks.AIR.defaultBlockState(), 3);
        }
    }

    private static void ignite(net.minecraft.server.level.ServerLevel level, BlockPos interior) {
        var result = dev.kyanitemods.kyaniteportals.content.registry.PortalTriggers.USE_ITEM.trigger(
                level, interior, null, new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.EMERALD));
        if (result != dev.kyanitemods.kyaniteportals.content.triggers.TriggerResult.PASS) throw new AssertionError("Ignition failed: " + result);
        if (!(level.getBlockEntity(interior) instanceof CustomPortalBlockEntity portalEntity)
                || !portalEntity.getPortalKey().identifier().equals(KyanitePortals.id("test_portal"))) throw new AssertionError("Portal key was not persisted during generation");
    }
}
