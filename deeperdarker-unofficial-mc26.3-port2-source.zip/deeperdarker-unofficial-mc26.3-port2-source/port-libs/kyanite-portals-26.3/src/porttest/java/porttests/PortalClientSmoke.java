package porttests;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;

/** Loads every client Mixin target, then exits after the real client finishes loading. */
public final class PortalClientSmoke implements ClientModInitializer {
    public void onInitializeClient() {
        for (String name : new String[] {
                "net.minecraft.client.player.AbstractClientPlayer",
                "net.minecraft.client.multiplayer.prediction.BlockStatePredictionHandler",
                "net.minecraft.client.multiplayer.prediction.BlockStatePredictionHandler$ServerVerifiedState",
                "net.minecraft.client.multiplayer.ClientPacketListener",
                "net.minecraft.client.gui.screens.LevelLoadingScreen",
                "net.minecraft.client.player.LocalPlayer",
                "net.minecraft.client.renderer.extract.LevelExtractor",
                "net.minecraft.client.gui.Hud"
        }) {
            try { Class.forName(name, false, getClass().getClassLoader()); }
            catch (ClassNotFoundException e) { throw new AssertionError(name, e); }
        }
        ClientLifecycleEvents.CLIENT_STARTED.register(client -> {
            System.out.println("PORTAL CLIENT SMOKE PASSED: Mixin targets transformed; client started.");
            client.stop();
        });
    }
}
