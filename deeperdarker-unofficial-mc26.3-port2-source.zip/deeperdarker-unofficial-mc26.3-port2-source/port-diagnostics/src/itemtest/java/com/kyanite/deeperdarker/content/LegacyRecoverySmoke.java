package com.kyanite.deeperdarker.content;
import net.fabricmc.fabric.api.gametest.v1.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.*;
import java.nio.file.*;
public final class LegacyRecoverySmoke {
    @GameTest
    public void oldPoolMigration(GameTestHelper helper) throws java.io.IOException {
        var oldSword = new CompoundTag();
        oldSword.putString("id", "minecraft:diamond_sword"); oldSword.putByte("Count", (byte) 1);
        var oldItemTag = new CompoundTag(); oldItemTag.putInt("Damage", 19);
        var display = new CompoundTag(); display.putString("Name", "{\"text\":\"Legacy sword\"}");
        oldItemTag.put("display", display); oldSword.put("tag", oldItemTag);
        var stacks = new ListTag(); stacks.add(oldSword);
        var payload = new CompoundTag(); payload.put("stacks", stacks);
        var root = new CompoundTag(); root.put("data", payload); root.putInt("DataVersion", 3465);
        var directory = Files.createTempDirectory(Path.of("."), "legacy-recovery-");
        var file = directory.resolve(DeadMansChestSavedData.ID + ".dat");
        NbtIo.writeCompressed(root, file);
        byte[] before = Files.readAllBytes(file);
        var migrated = DeadMansChestSavedData.readLegacy(file, helper.getLevel().registryAccess());
        if (migrated.getList().size() != 1) throw new AssertionError("Lost legacy item");
        var sword = migrated.getList().getFirst();
        if (!sword.is(net.minecraft.world.item.Items.DIAMOND_SWORD) || sword.getCount() != 1
                || sword.getDamageValue() != 19 || !sword.getHoverName().getString().equals("Legacy sword")) {
            throw new AssertionError("Legacy item metadata was not migrated: " + sword);
        }
        if (!java.util.Arrays.equals(before, Files.readAllBytes(file))) throw new AssertionError("Original legacy file changed");
        helper.succeed();
        System.out.println("LEGACY_RECOVERY_PASSED: 1.20.1 compressed NBT, item data fixer, damage/name/count and original-file preservation");
    }
}
