package porttests;
import com.kyanite.deeperdarker.content.DDEnchantments;
import net.fabricmc.fabric.api.gametest.v1.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
public final class EnchantmentPortSmoke {
    @GameTest
    public void loadedEnchantments(GameTestHelper helper) {
        var registry = helper.getLevel().registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
        var smite = registry.getOrThrow(DDEnchantments.SCULK_SMITE);
        var catalysis = registry.getOrThrow(DDEnchantments.CATALYSIS);
        if (smite.value().getMaxLevel() != 5 || smite.value().getMinCost(3) != 21 || smite.value().getMaxCost(3) != 41) throw new AssertionError("Sculk Smite costs/levels changed");
        if (catalysis.value().getMaxLevel() != 3 || catalysis.value().getMinCost(3) != 50 || catalysis.value().getMaxCost(3) != 75) throw new AssertionError("Catalysis costs/levels changed");
        if (Enchantment.areCompatible(smite, registry.getOrThrow(Enchantments.SHARPNESS))) throw new AssertionError("Damage enchantment exclusion lost");
        var sword = new ItemStack(Items.DIAMOND_SWORD); sword.enchant(smite, 3);
        var cow = helper.spawn(EntityTypes.COW, new BlockPos(1, 2, 1)); cow.setNoAi(true);
        var warden = helper.spawn(EntityTypes.WARDEN, new BlockPos(2, 2, 1)); warden.setNoAi(true);
        var source = helper.getLevel().damageSources().generic();
        if (EnchantmentHelper.modifyDamage(helper.getLevel(), sword, cow, source, 1) != 1) throw new AssertionError("Sculk Smite damaged a normal mob");
        if (EnchantmentHelper.modifyDamage(helper.getLevel(), sword, warden, source, 1) != 8.5F) throw new AssertionError("Sculk Smite bonus is not 2.5 per level");
        var phantom = helper.spawn(EntityTypes.PHANTOM, new BlockPos(3, 2, 1)); phantom.setNoAi(true);
        if (EnchantmentHelper.modifyDamage(helper.getLevel(), sword, phantom, source, 1) != 1) throw new AssertionError("Overworld Phantom incorrectly classified as Sculk");
        var player = helper.makeMockServerPlayerInLevel();
        var catalyst = new ItemStack(Items.DIAMOND_SWORD); catalyst.enchant(catalysis, 3);
        player.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND, catalyst);
        for (int x = 0; x <= 6; x++) for (int z = 0; z <= 6; z++) helper.setBlock(new BlockPos(x, 1, z), Blocks.STONE);
        var zombie = helper.spawn(EntityTypes.ZOMBIE, new BlockPos(3, 2, 3)); zombie.setNoAi(true);
        var attack = helper.getLevel().damageSources().playerAttack(player);
        zombie.hurtServer(helper.getLevel(), attack, 1000);
        EnchantmentHelper.doPostAttackEffects(helper.getLevel(), zombie, attack);
        if (!zombie.wasExperienceConsumed()) throw new AssertionError("Catalysis did not consume death experience");
        boolean spread = false;
        for (BlockPos pos : BlockPos.betweenClosed(helper.absolutePos(new BlockPos(-1, 0, -1)), helper.absolutePos(new BlockPos(7, 3, 7)))) {
            var block = helper.getLevel().getBlockState(pos);
            if (block.is(Blocks.SCULK) || block.is(Blocks.SCULK_VEIN)) { spread = true; break; }
        }
        if (!spread) throw new AssertionError("Catalysis produced no Sculk around its kill");
        cow.discard(); warden.discard(); phantom.discard(); zombie.discard();
        helper.succeed();
        System.out.println("ENCHANTMENTS_PASSED: loaded data, original costs/levels, exclusion, Sculk damage condition and Catalysis kill-to-Sculk spread");
    }
}
