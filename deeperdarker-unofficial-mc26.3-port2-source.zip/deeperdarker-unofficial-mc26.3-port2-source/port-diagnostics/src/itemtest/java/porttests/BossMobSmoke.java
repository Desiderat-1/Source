package porttests;

import com.kyanite.deeperdarker.content.entities.*;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.gametest.v1.GameTest;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.*;
import net.minecraft.core.registries.*;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.resources.*;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.golem.AbstractGolem;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.*;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.*;
import net.minecraft.util.ProblemReporter;
import net.minecraft.world.phys.Vec3;

public final class BossMobSmoke implements ModInitializer {
    private static EntityType<TestGolem> golemType;
    private static EntityType<SculkCentipede> centipedeType;
    private static EntityType<SculkSnapper> snapperType;
    public void onInitialize() {
        golemType = register("golem", TestGolem::new);
        FabricDefaultAttributeRegistry.register(golemType, Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH, 100)
                .add(Attributes.ATTACK_DAMAGE, 10).add(Attributes.ATTACK_KNOCKBACK, 2).add(Attributes.FOLLOW_RANGE, 100));
        centipedeType = register("centipede", SculkCentipede::new);
        FabricDefaultAttributeRegistry.register(centipedeType, SculkCentipede.createAttributes());
        snapperType = register("snapper", SculkSnapper::new);
        FabricDefaultAttributeRegistry.register(snapperType, SculkSnapper.createAttributes());
    }
    private static <T extends Entity> EntityType<T> register(String name, EntityType.EntityFactory<T> factory) {
        var key = ResourceKey.create(Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("port_items_test", name));
        return Registry.register(BuiltInRegistries.ENTITY_TYPE, key,
                EntityType.Builder.of(factory, MobCategory.MONSTER).sized(0.8F, 1.5F).build(key));
    }
    private static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    // A fixture supplies only the abstract boss's model-specific state and phase hook.
    // All combat, sleeping, targeting, knockback and persistence logic comes from the actual port.
    public static final class TestGolem extends AbstractGolemBoss {
        public TestGolem(EntityType<? extends AbstractGolem> type, Level level) { super(type, level); }
        protected void golemServerAiStep() { }
        public BlockState getParticleState() { return Blocks.STONE.defaultBlockState(); }
    }
    @GameTest
    public void bossCombatAndReset(GameTestHelper helper) {
        var server = helper.getLevel();
        var golem = helper.spawn(golemType, new BlockPos(2, 2, 2)); golem.setNoAi(true);
        check(!golem.canUsePortal(false) && !golem.canUsePortal(true), "boss can leave its arena through a portal");
        check(!golem.hurtServer(server, server.damageSources().generic(), 10), "sleeping boss took damage");
        golem.setGolemSleeping(false); golem.setCooldown((short) 0);
        golem.setDeltaMovement(Vec3.ZERO);
        golem.knockback(5, 1, 1, server.damageSources().generic(), 10);
        check(golem.getDeltaMovement().equals(Vec3.ZERO), "boss lost knockback immunity");
        check(golem.hurtServer(server, server.damageSources().generic(), 10) && golem.getHealth() == 90, "awake boss damage");
        var sword = new ItemStack(Items.IRON_SWORD);
        sword.enchant(server.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.SHARPNESS), 3);
        golem.setItemInHand(InteractionHand.MAIN_HAND, sword);
        var cow = helper.spawn(EntityTypes.COW, new BlockPos(3, 2, 2)); cow.setNoAi(true);
        cow.getAttribute(Attributes.MAX_HEALTH).setBaseValue(40); cow.setHealth(40);
        check(golem.doHurtTarget(server, cow) && Math.abs(cow.getHealth() - 28) < 0.001F, "boss attack lost enchantment damage: " + cow.getHealth());
        check(cow.getDeltaMovement().lengthSqr() > 0, "boss attack lost knockback");
        var home = helper.absolutePos(new BlockPos(1, 2, 1));
        golem.setHomePos(GlobalPos.of(server.dimension(), home)); golem.reset();
        check(golem.isGolemSleeping() && golem.getHealth() == 100 && golem.getCooldown() == 20, "boss reset state");
        check(golem.position().distanceToSqr(Vec3.atBottomCenterOf(home)) < 0.0001, "boss did not return home");
        golem.setCooldown((short) 7); golem.setSnapToBlocks(false);
        var output = TagValueOutput.createWithContext(ProblemReporter.DISCARDING, server.registryAccess());
        golem.addAdditionalSaveData(output);
        var restored = golemType.create(server, EntitySpawnReason.LOAD);
        restored.readAdditionalSaveData(TagValueInput.create(ProblemReporter.DISCARDING, server.registryAccess(), output.buildResult()));
        check(restored.getHomePos().equals(golem.getHomePos()) && restored.getCooldown() == 7 && !restored.snapToBlocks(), "boss persisted arena/cooldown/snap state");
        cow.discard(); golem.discard(); restored.discard(); helper.succeed();
        System.out.println("BOSS_PORT_PASSED: sleeping, damage, enchantments, knockback immunity/attack, reset and persisted arena");
    }
    @GameTest
    public void centipedeAngerAndSnapperTaming(GameTestHelper helper) {
        var server = helper.getLevel(); var player = helper.makeMockServerPlayerInLevel();
        player.setGameMode(net.minecraft.world.level.GameType.SURVIVAL);
        var centipede = helper.spawn(centipedeType, new BlockPos(1, 2, 1)); centipede.setNoAi(true);
        centipede.setPersistentAngerTarget(EntityReference.of(player)); centipede.startPersistentAngerTimer();
        long remaining = centipede.getPersistentAngerEndTime() - server.getGameTime();
        check(remaining >= 300 && remaining <= 600, "centipede anger duration changed");
        var output = TagValueOutput.createWithContext(ProblemReporter.DISCARDING, server.registryAccess());
        centipede.saveWithoutId(output);
        var restored = centipedeType.create(server, EntitySpawnReason.LOAD);
        restored.load(TagValueInput.create(ProblemReporter.DISCARDING, server.registryAccess(), output.buildResult()));
        check(restored.getPersistentAngerEndTime() == centipede.getPersistentAngerEndTime(), "centipede anger did not survive saving");
        check(restored.getPersistentAngerTarget().getUUID().equals(player.getUUID()), "centipede anger target did not survive saving");
        var snapper = helper.spawn(snapperType, new BlockPos(3, 2, 3)); snapper.setNoAi(true);
        var chestplate = new ItemStack(Items.NETHERITE_CHESTPLATE);
        check(!snapper.isFood(chestplate), "unenchanted chestplate accepted");
        chestplate.enchant(server.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.PROTECTION), 1);
        check(snapper.isFood(chestplate), "enchanted chestplate rejected");
        player.setItemInHand(InteractionHand.MAIN_HAND, chestplate);
        snapper.mobInteract(player, InteractionHand.MAIN_HAND);
        check(snapper.isTame() && snapper.isOwnedBy(player) && snapper.getMaxHealth() == 16 && snapper.getHealth() == 16, "snapper taming/owner/health");
        snapper.setHealth(2);
        var food = new ItemStack(Items.IRON_SWORD);
        food.enchant(server.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.SHARPNESS), 1);
        player.setItemInHand(InteractionHand.MAIN_HAND, food); snapper.mobInteract(player, InteractionHand.MAIN_HAND);
        check(snapper.getHealth() == 16 && food.isEmpty(), "snapper enchantment meal healing/consumption: " + snapper.getHealth() + "/" + food.getCount());
        centipede.discard(); restored.discard(); snapper.discard(); helper.succeed();
        System.out.println("MOB_PORT_PASSED: persistent anger duration/target, Snapper food/taming/owner/healing");
    }
}
