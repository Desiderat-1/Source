package porttests;

import com.kyanite.deeperdarker.content.items.*;
import com.kyanite.deeperdarker.util.*;
import net.minecraft.SharedConstants;
import net.minecraft.server.Bootstrap;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.component.DataComponentMap;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import java.util.List;

public final class ItemPortSmoke implements net.fabricmc.api.ModInitializer {
    private static Item plain, leggings, helmet, resonarium, elytra, glasses, sword, berries, transmitter, drink, staff, amber;
    private static Block block;
    private static net.minecraft.world.entity.EntityType<com.kyanite.deeperdarker.content.entities.AnglerFish> anglerType;
    private static net.minecraft.world.entity.EntityType<com.kyanite.deeperdarker.content.entities.SculkLeech> leechType;
    @Override
    public void onInitialize() {
        com.kyanite.deeperdarker.content.DDEnchantments.init();
        com.kyanite.deeperdarker.content.DDEffects.init();
        com.kyanite.deeperdarker.content.DDPotions.init();
        item("soul_dust", new Item(DDRegistration.itemProperties("soul_dust")));
        drink = item("port_smoke_drink", new SculkDrinkItem(DDRegistration.itemProperties("port_smoke_drink").food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(10).saturationModifier(1.2F).build()).stacksTo(1)));
        staff = item("port_smoke_staff", new SonorousStaffItem(DDRegistration.itemProperties("port_smoke_staff").durability(320)));
        var anglerKey = net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, net.minecraft.resources.Identifier.fromNamespaceAndPath("deeperdarker", "angler_fish"));
        anglerType = Registry.register(BuiltInRegistries.ENTITY_TYPE, anglerKey, net.minecraft.world.entity.EntityType.Builder.<com.kyanite.deeperdarker.content.entities.AnglerFish>of(com.kyanite.deeperdarker.content.entities.AnglerFish::new, net.minecraft.world.entity.MobCategory.WATER_CREATURE).sized(0.7F, 0.4F).clientTrackingRange(10).build(anglerKey));
        net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry.register(anglerType, com.kyanite.deeperdarker.content.entities.AnglerFish.createAttributeSupplier());
        com.kyanite.deeperdarker.mixin.SpawnPlacementsInvoker.deeperdarker$register(anglerType, net.minecraft.world.entity.SpawnPlacementTypes.IN_WATER, net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, com.kyanite.deeperdarker.content.entities.AnglerFish::checkAnglerFishSpawnRules);
        var key = net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, net.minecraft.resources.Identifier.fromNamespaceAndPath("deeperdarker", "sculk_leech"));
        leechType = Registry.register(BuiltInRegistries.ENTITY_TYPE, key, net.minecraft.world.entity.EntityType.Builder.<com.kyanite.deeperdarker.content.entities.SculkLeech>of(com.kyanite.deeperdarker.content.entities.SculkLeech::new, net.minecraft.world.entity.MobCategory.MONSTER).sized(0.42F, 0.2F).clientTrackingRange(10).build(key));
        com.kyanite.deeperdarker.mixin.SpawnPlacementsInvoker.deeperdarker$register(leechType, net.minecraft.world.entity.SpawnPlacementTypes.ON_GROUND, net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, net.minecraft.world.entity.Mob::checkMobSpawnRules);
        net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry.register(leechType, com.kyanite.deeperdarker.content.entities.SculkLeech.createAttributes());
        com.kyanite.deeperdarker.util.recipes.DDRecipeSerializers.init();
        item("fizz", new Item(DDRegistration.itemProperties("fizz")));
        item("shield_augment", new Item(DDRegistration.itemProperties("shield_augment")));
        item("warden_helmet", new WardenArmorItem(DDArmorMaterials.WARDEN, ArmorType.HELMET, DDRegistration.itemProperties("warden_helmet")));
        item("guardian_helmet", new WardenArmorItem(DDArmorMaterials.GUARDIAN, ArmorType.HELMET, DDRegistration.itemProperties("guardian_helmet")));
        item("blue_sculk_transmitter", new SculkTransmitterItem(DDRegistration.itemProperties("blue_sculk_transmitter").stacksTo(1)));
        com.kyanite.deeperdarker.content.components.DDDataComponents.init();
        com.kyanite.deeperdarker.content.DDSounds.init();
        transmitter = item("port_smoke_transmitter", new SculkTransmitterItem(DDRegistration.itemProperties("port_smoke_transmitter").stacksTo(1)));
        Registry.register(BuiltInRegistries.FEATURE_TYPE, net.minecraft.resources.Identifier.fromNamespaceAndPath("deeperdarker", "boulder"), com.kyanite.deeperdarker.world.features.BoulderFeature.CODEC);
        for (String name : List.of("lead_ingot", "radioactive_ingot", "resonarium", "reinforced_echo_shard", "soul_crystal"))
            item(name, new Item(DDRegistration.itemProperties(name)));
        plain = item("port_smoke_plain", new Item(DDRegistration.itemProperties("port_smoke_plain")));
        block = Registry.register(BuiltInRegistries.BLOCK, DDRegistration.blockKey("port_smoke_block"),
            new Block(DDRegistration.blockProperties("port_smoke_block", BlockBehaviour.Properties.of().strength(2))));
        amber = item("port_smoke_amber", new CrystallizedAmberItem(block, DDRegistration.itemProperties("port_smoke_amber")));
        var soulParticle = net.minecraft.core.particles.ParticleTypes.SOUL;
        item("corruption_soul", new CorruptionSoulItem(block, DDRegistration.itemProperties("corruption_soul"), soulParticle));
        item("fortitude_soul", new FortitudeSoulItem(block, DDRegistration.itemProperties("fortitude_soul"), soulParticle));
        item("virtue_soul", new VirtueSoulItem(block, DDRegistration.itemProperties("virtue_soul"), soulParticle));
        item("patience_soul", new PatienceSoulItem(block, DDRegistration.itemProperties("patience_soul"), soulParticle));
        item("purity_soul", new PuritySoulItem(block, DDRegistration.itemProperties("purity_soul"), soulParticle));
        leggings = item("port_smoke_leggings", new WardenArmorItem(DDArmorMaterials.WARDEN, ArmorType.LEGGINGS, DDRegistration.itemProperties("port_smoke_leggings")));
        helmet = item("port_smoke_helmet", new WardenArmorItem(DDArmorMaterials.GUARDIAN, ArmorType.HELMET, DDRegistration.itemProperties("port_smoke_helmet"), List.of(MobEffects.BLINDNESS, MobEffects.DARKNESS)));
        resonarium = item("port_smoke_resonarium", new ResonariumArmorItem(DDArmorMaterials.RESONARIUM, ArmorType.CHESTPLATE, DDRegistration.itemProperties("port_smoke_resonarium")));
        elytra = item("port_smoke_elytra", new SoulElytraItem(DDRegistration.itemProperties("port_smoke_elytra").durability(956)));
        glasses = item("port_smoke_glasses", new SunglassesItem(DDRegistration.itemProperties("port_smoke_glasses").stacksTo(1)));
        sword = item("port_smoke_sword", new Item(DDRegistration.itemProperties("port_smoke_sword").sword(DDTiers.WARDEN, 3, -2.4F)));
        berries = item("bloom_berries", new Item(DDRegistration.itemProperties("bloom_berries")));
    }
    @net.fabricmc.fabric.api.gametest.v1.GameTest
    public void migratedEquipment(net.minecraft.gametest.framework.GameTestHelper helper) {
        check(plain.getDescriptionId().equals("item.deeperdarker.port_smoke_plain"), "item constructor ID");
        check(block.getDescriptionId().equals("block.deeperdarker.port_smoke_block"), "block constructor ID");
        check(DDTiers.GUARDIAN.durability() == 11508 && DDTiers.WARDEN.attackDamageBonus() == 5, "tool statistics");
        check(DDArmorMaterials.WARDEN.defense().get(ArmorType.CHESTPLATE) == 9, "armor defense");
        check(ArmorType.LEGGINGS.getDurability(DDArmorMaterials.WARDEN.durability()) == 600, "armor durability");
        check(leggings.components().get(DataComponents.MAX_DAMAGE) == 600, "actual armor durability component");
        check(helmet.components().get(DataComponents.MAX_DAMAGE) == 1100, "guardian helmet durability");
        check(leggings.components().get(DataComponents.ATTRIBUTE_MODIFIERS).compute(Attributes.MOVEMENT_SPEED, 0.1, EquipmentSlot.LEGS) > 0.11999, "leggings speed bonus");
        check(resonarium.components().get(DataComponents.ENCHANTABLE) == null, "resonarium is not enchanting-table eligible");
        check(elytra.components().has(DataComponents.GLIDER), "elytra flight component");
        check(elytra.components().get(DataComponents.EQUIPPABLE).slot() == EquipmentSlot.CHEST, "elytra chest equipment");
        check(elytra.components().get(DataComponents.ATTRIBUTE_MODIFIERS).compute(Attributes.ARMOR, 0, EquipmentSlot.CHEST) == 3, "elytra armor bonus");
        check(glasses.components().get(DataComponents.EQUIPPABLE).slot() == EquipmentSlot.HEAD, "sunglasses equipment");
        check(sword.components().get(DataComponents.MAX_DAMAGE) == 2519, "tool durability component");
        check(sword.components().get(DataComponents.ATTRIBUTE_MODIFIERS).compute(Attributes.ATTACK_DAMAGE, 1, EquipmentSlot.MAINHAND) == 9, "warden sword damage preserves base and tier bonuses");
        check(berries.components().get(DataComponents.COMPOSTABLE) != null, "compostable berries");
        var zombie = helper.spawn(net.minecraft.world.entity.EntityTypes.ZOMBIE, new net.minecraft.core.BlockPos(1, 2, 1));
        zombie.setNoAi(true);
        zombie.addEffect(new net.minecraft.world.effect.MobEffectInstance(MobEffects.BLINDNESS, 200));
        zombie.addEffect(new net.minecraft.world.effect.MobEffectInstance(MobEffects.DARKNESS, 200));
        helmet.inventoryTick(new net.minecraft.world.item.ItemStack(helmet), helper.getLevel(), zombie, EquipmentSlot.MAINHAND);
        check(zombie.hasEffect(MobEffects.BLINDNESS), "unequipped helmet must not remove effects");
        zombie.setItemSlot(EquipmentSlot.HEAD, new net.minecraft.world.item.ItemStack(helmet));
        helmet.inventoryTick(zombie.getItemBySlot(EquipmentSlot.HEAD), helper.getLevel(), zombie, EquipmentSlot.HEAD);
        check(!zombie.hasEffect(MobEffects.BLINDNESS) && !zombie.hasEffect(MobEffects.DARKNESS), "equipped helmet removes configured effects");
        zombie.discard();
        helper.succeed();
        System.out.println("ITEM_PORT_PASSED: constructor IDs, materials, durability, armor attributes, leggings speed, Resonarium enchanting restriction, Soul Elytra glider, sunglasses equipment");
    }
    @net.fabricmc.fabric.api.gametest.v1.GameTest
    public void configuredBoulder(net.minecraft.gametest.framework.GameTestHelper helper) {
        var level = helper.getLevel();
        var key = net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.FEATURE,
            net.minecraft.resources.Identifier.fromNamespaceAndPath("port_items_test", "boulder"));
        var feature = level.registryAccess().lookupOrThrow(net.minecraft.core.registries.Registries.FEATURE).getValue(key);
        check(feature instanceof com.kyanite.deeperdarker.world.features.BoulderFeature, "custom feature JSON loaded through 26.3 registry codec");
        var origin = helper.absolutePos(new net.minecraft.core.BlockPos(3, 4, 3));
        for (var pos : net.minecraft.core.BlockPos.betweenClosed(origin.offset(-3, -3, -3), origin.offset(3, 3, 3)))
            level.setBlockAndUpdate(pos, net.minecraft.world.level.block.Blocks.AIR.defaultBlockState());
        check(!feature.place(level, level.getChunkSource().getGenerator(), net.minecraft.util.RandomSource.create(12), origin), "unsupported boulder rejected");
        level.setBlockAndUpdate(origin.below(), net.minecraft.world.level.block.Blocks.DIRT.defaultBlockState());
        check(feature.place(level, level.getChunkSource().getGenerator(), net.minecraft.util.RandomSource.create(12), origin), "boulder placed");
        check(level.getBlockState(origin).is(net.minecraft.world.level.block.Blocks.STONE), "boulder center stone");
        check(level.getBlockState(origin.offset(3, 0, 0)).isAir(), "boulder bounded by radius");
        var ops = net.minecraft.resources.RegistryOps.create(com.mojang.serialization.JsonOps.INSTANCE, level.registryAccess());
        var invalid = com.google.gson.JsonParser.parseString("{\"state_provider\":{\"id\":\"minecraft:stone\"},\"diameter\":0}");
        check(com.kyanite.deeperdarker.world.features.BoulderFeature.CODEC.codec().parse(ops, invalid).error().isPresent(), "invalid boulder diameter rejected");
        helper.succeed();
        System.out.println("BOULDER_FEATURE_PASSED: JSON registry loading, unsupported placement, shape bounds, state provider and configuration range checks");
    }
    @net.fabricmc.fabric.api.gametest.v1.GameTest
    public void transmitterPersistence(net.minecraft.gametest.framework.GameTestHelper helper) {
        var stack = new net.minecraft.world.item.ItemStack(transmitter);
        var pos = helper.absolutePos(new net.minecraft.core.BlockPos(1, 2, 1));
        helper.getLevel().setBlockAndUpdate(pos, net.minecraft.world.level.block.Blocks.CHEST.defaultBlockState());
        SculkTransmitterItem.formConnection(helper.getLevel(), stack, pos);
        check(SculkTransmitterItem.isLinked(stack), "new link written");
        var link = com.kyanite.deeperdarker.content.components.TransmitterLink.read(stack).orElseThrow();
        check(link.target().pos().equals(pos) && link.target().dimension().equals(helper.getLevel().dimension()), "link target");
        var ops = net.minecraft.resources.RegistryOps.create(net.minecraft.nbt.NbtOps.INSTANCE, helper.getLevel().registryAccess());
        var encoded = net.minecraft.world.item.ItemStack.CODEC.encodeStart(ops, stack).getOrThrow();
        var restored = net.minecraft.world.item.ItemStack.CODEC.parse(ops, encoded).getOrThrow();
        check(com.kyanite.deeperdarker.content.components.TransmitterLink.read(restored).orElseThrow().equals(link), "saved item restores typed link");
        var buf = io.netty.buffer.Unpooled.buffer();
        try {
            com.kyanite.deeperdarker.content.components.TransmitterLink.STREAM_CODEC.encode(buf, link);
            check(com.kyanite.deeperdarker.content.components.TransmitterLink.STREAM_CODEC.decode(buf).equals(link), "network link codec");
        } finally { buf.release(); }
        var legacy = new net.minecraft.nbt.CompoundTag();
        legacy.putString("dimension", "minecraft:overworld"); legacy.putString("block", "block.minecraft.chest"); legacy.putString("unrelated", "preserve");
        var coords = new net.minecraft.nbt.CompoundTag(); coords.putInt("X", -1234); coords.putInt("Y", -40); coords.putInt("Z", 9876); legacy.put("block_pos", coords);
        var oldStack = new net.minecraft.world.item.ItemStack(transmitter);
        oldStack.set(DataComponents.CUSTOM_DATA, net.minecraft.world.item.component.CustomData.of(legacy));
        check(com.kyanite.deeperdarker.content.components.TransmitterLink.read(oldStack).orElseThrow().target().pos().getX() == -1234, "legacy custom NBT read");
        check(oldStack.get(com.kyanite.deeperdarker.content.components.DDDataComponents.TRANSMITTER_LINK) == null, "reading legacy data does not mutate it");
        SculkTransmitterItem.formConnection(helper.getLevel(), oldStack, pos);
        check(!oldStack.get(DataComponents.CUSTOM_DATA).copyTag().contains("block_pos"), "new link removes old fields");
        check(oldStack.get(DataComponents.CUSTOM_DATA).copyTag().getStringOr("unrelated", "").equals("preserve"), "unrelated custom data retained");
        SculkTransmitterItem.formConnection(helper.getLevel(), oldStack, null);
        check(!SculkTransmitterItem.isLinked(oldStack), "unlink clears typed and old fields");
        helper.succeed();
        System.out.println("TRANSMITTER_LINK_PASSED: save/reload, network codec, legacy NBT, nonmutating read, migration, unrelated-data preservation and unlink");
    }
    @net.fabricmc.fabric.api.gametest.v1.GameTest
    public void customCrafting(net.minecraft.gametest.framework.GameTestHelper helper) {
        var shield = new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.SHIELD);
        var ingredient = new net.minecraft.world.item.ItemStack(net.minecraft.core.registries.BuiltInRegistries.ITEM.getValue(net.minecraft.resources.Identifier.fromNamespaceAndPath("deeperdarker", "shield_augment")));
        var input = net.minecraft.world.item.crafting.CraftingInput.of(2, 1, List.of(shield, ingredient));
        var augment = new com.kyanite.deeperdarker.util.recipes.AugmentShieldRecipe();
        check(augment.matches(input, helper.getLevel()), "shield recipe matches");
        var upgraded = augment.assemble(input);
        check(com.kyanite.deeperdarker.content.components.DDItemProperties.isAugmented(upgraded), "shield flag written");
        check(!com.kyanite.deeperdarker.content.components.DDItemProperties.isAugmented(shield), "recipe input unchanged");
        var helmetItem = net.minecraft.core.registries.BuiltInRegistries.ITEM.getValue(net.minecraft.resources.Identifier.fromNamespaceAndPath("deeperdarker", "warden_helmet"));
        var helmetStack = new net.minecraft.world.item.ItemStack(helmetItem);
        var remove = new com.kyanite.deeperdarker.util.recipes.RemoveHornsRecipe();
        var noHorns = remove.assemble(net.minecraft.world.item.crafting.CraftingInput.of(2, 1, List.of(helmetStack, new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.SHEARS))));
        check(!com.kyanite.deeperdarker.content.components.DDItemProperties.hasHorns(noHorns), "horns removed");
        check(com.kyanite.deeperdarker.content.components.DDItemProperties.hasHorns(helmetStack), "default horns retained on input");
        var withHorns = new com.kyanite.deeperdarker.util.recipes.AddHornsRecipe().assemble(net.minecraft.world.item.crafting.CraftingInput.of(2, 1, List.of(noHorns, new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.SCULK))));
        check(com.kyanite.deeperdarker.content.components.DDItemProperties.hasHorns(withHorns), "horns restored");
        var fizz = net.minecraft.core.registries.BuiltInRegistries.ITEM.getValue(net.minecraft.resources.Identifier.fromNamespaceAndPath("deeperdarker", "fizz"));
        var acidProof = new com.kyanite.deeperdarker.util.recipes.AcidResistantItemRecipe().assemble(net.minecraft.world.item.crafting.CraftingInput.of(2, 1, List.of(new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.STICK), new net.minecraft.world.item.ItemStack(fizz))));
        check(com.kyanite.deeperdarker.content.components.DDItemProperties.isAcidResistant(acidProof), "acid-resistant item recipe");
        var linked = new net.minecraft.world.item.ItemStack(transmitter);
        var pos = helper.absolutePos(new net.minecraft.core.BlockPos(1, 2, 1));
        SculkTransmitterItem.formConnection(helper.getLevel(), linked, pos);
        var dye = new com.kyanite.deeperdarker.util.recipes.SculkTransmitterDyeRecipe();
        var dyeInput = net.minecraft.world.item.crafting.CraftingInput.of(2, 1, List.of(linked, new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.DYE.blue())));
        check(dye.matches(dyeInput, helper.getLevel()), "dye recipe matches");
        var dyed = dye.assemble(dyeInput);
        check(dyed.getItem() == SculkTransmitterItem.fromColor(net.minecraft.world.item.DyeColor.BLUE), "transmitter color changed");
        check(com.kyanite.deeperdarker.content.components.TransmitterLink.read(dyed).equals(com.kyanite.deeperdarker.content.components.TransmitterLink.read(linked)), "dyeing preserves link component");
        var extra = net.minecraft.world.item.crafting.CraftingInput.of(3, 1, List.of(linked, new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.DYE.blue()), new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.STICK)));
        check(!dye.matches(extra, helper.getLevel()), "extra ingredients rejected");
        helper.succeed();
        System.out.println("CUSTOM_RECIPES_PASSED: all five recipes, nonmutating inputs, horn defaults, item flags, transmitter recoloring and link preservation");
    }
    @net.fabricmc.fabric.api.gametest.v1.GameTest
    public void sculkLeechAttack(net.minecraft.gametest.framework.GameTestHelper helper) {
        var leech = helper.spawn(leechType, new net.minecraft.core.BlockPos(1, 2, 1));
        leech.setNoAi(true);
        check(net.minecraft.world.entity.SpawnPlacements.getPlacementType(leechType) == net.minecraft.world.entity.SpawnPlacementTypes.ON_GROUND, "spawn placement registration");
        check(leech.getMaxHealth() == 4, "leech health");
        check(leech.getAttributeValue(Attributes.MOVEMENT_SPEED) == 0.25, "leech speed");
        var cow = helper.spawn(net.minecraft.world.entity.EntityTypes.COW, new net.minecraft.core.BlockPos(2, 2, 1));
        cow.setNoAi(true);
        float before = cow.getHealth();
        check(leech.doHurtTarget(helper.getLevel(), cow), "server-side leech attack");
        check(cow.getHealth() == before - 1, "leech damage");
        check(com.kyanite.deeperdarker.content.entities.DDMobType.isSculk(leech), "sculk tag identifies leech");
        check(!com.kyanite.deeperdarker.content.entities.DDMobType.isSculk(cow), "cow is not sculk");
        var player = helper.makeMockServerPlayerInLevel();
        player.setGameMode(net.minecraft.world.level.GameType.SURVIVAL);
        player.giveExperiencePoints(10);
        int xp = player.totalExperience;
        leech.doHurtTarget(helper.getLevel(), player);
        check(player.totalExperience == xp - 4, "leech drains four experience points");
        cow.discard(); leech.discard();
        helper.succeed();
        System.out.println("SCULK_LEECH_PASSED: spawn, attributes, server-side attack, damage and tag-based classification");
    }
    @net.fabricmc.fabric.api.gametest.v1.GameTest
    public void anglerFishAttack(net.minecraft.gametest.framework.GameTestHelper helper) {
        var fish = helper.spawn(anglerType, new net.minecraft.core.BlockPos(1, 2, 1)); fish.setNoAi(true);
        check(fish.getMaxHealth() == 6 && fish.getAttributeValue(Attributes.ATTACK_DAMAGE) == 3, "angler attributes");
        check(net.minecraft.world.entity.SpawnPlacements.getPlacementType(anglerType) == net.minecraft.world.entity.SpawnPlacementTypes.IN_WATER, "angler water spawn placement");
        var cow = helper.spawn(net.minecraft.world.entity.EntityTypes.COW, new net.minecraft.core.BlockPos(2, 2, 1)); cow.setNoAi(true);
        check(!fish.validTarget(cow), "angler ignores land targets");
        float health = cow.getHealth();
        check(fish.doHurtTarget(helper.getLevel(), cow) && cow.getHealth() == health - 3, "angler attack damage");
        fish.discard(); cow.discard(); helper.succeed();
        System.out.println("ANGLER_FISH_PASSED: spawn, attributes, water placement, target filtering and server damage");
    }
    @net.fabricmc.fabric.api.gametest.v1.GameTest
    public void drinkAndStaff(net.minecraft.gametest.framework.GameTestHelper helper) {
        var player = helper.makeMockServerPlayerInLevel(); player.setGameMode(net.minecraft.world.level.GameType.SURVIVAL);
        player.getFoodData().setFoodLevel(0); player.getFoodData().setSaturation(0);
        var remainder = new net.minecraft.world.item.ItemStack(drink).finishUsingItem(helper.getLevel(), player);
        check(player.getFoodData().getFoodLevel() == 10, "drink restores original nutrition");
        check(remainder.is(net.minecraft.world.item.Items.BUCKET), "drink returns an empty bucket");
        check(drink.getUseAnimation(new net.minecraft.world.item.ItemStack(drink)) == net.minecraft.world.item.ItemUseAnimation.DRINK, "drink animation");
        var start = helper.absolutePos(new net.minecraft.core.BlockPos(2, 4, 1));
        player.setPos(start.getX() + 0.5, start.getY(), start.getZ() + 0.5); player.setYRot(0); player.setXRot(0);
        for (int z = 1; z <= 9; z++) helper.getLevel().setBlockAndUpdate(start.offset(0, 1, z), net.minecraft.world.level.block.Blocks.AIR.defaultBlockState());
        var cow = helper.spawn(net.minecraft.world.entity.EntityTypes.COW, new net.minecraft.core.BlockPos(2, 5, 5)); cow.setNoAi(true); cow.setNoGravity(true);
        var beam = new net.minecraft.world.item.ItemStack(staff); player.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND, beam);
        float health = cow.getHealth();
        check(staff.releaseUsing(beam, helper.getLevel(), player, 71800), "staff release result");
        check(cow.getHealth() < health, "staff sonic damage");
        check(beam.getDamageValue() == 1, "staff durability consumption");
        check(player.getCooldowns().isOnCooldown(beam), "staff cooldown");
        cow.discard();
        var blocked = helper.spawn(net.minecraft.world.entity.EntityTypes.COW, new net.minecraft.core.BlockPos(2, 5, 6)); blocked.setNoAi(true); blocked.setNoGravity(true);
        helper.getLevel().setBlockAndUpdate(start.offset(0, 1, 2), net.minecraft.world.level.block.Blocks.STONE.defaultBlockState());
        float blockedHealth = blocked.getHealth();
        staff.releaseUsing(beam, helper.getLevel(), player, 71800);
        check(blocked.getHealth() == blockedHealth, "solid block stops staff beam");
        blocked.discard(); helper.succeed();
        System.out.println("DRINK_STAFF_PASSED: food restoration, bucket remainder, animation, sonic damage, durability, cooldown and solid-block occlusion");
    }
    @net.fabricmc.fabric.api.gametest.v1.GameTest
    public void savedRecoveryPoolAndFossilTooltip(net.minecraft.gametest.framework.GameTestHelper helper) throws java.io.IOException {
        var data = new com.kyanite.deeperdarker.content.DeadMansChestSavedData();
        var input = new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.DIAMOND, 60);
        data.add(input); data.add(new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.DIAMOND, 10));
        check(input.getCount() == 60, "pool does not alias or mutate the discarded entity stack");
        check(data.getList().size() == 2 && data.getList().get(0).getCount() == 64 && data.getList().get(1).getCount() == 6, "pool merges without losing items or exceeding stack limit");
        var named = new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.DIAMOND_SWORD);
        named.set(DataComponents.CUSTOM_NAME, net.minecraft.network.chat.Component.literal("Recovered sword"));
        named.setDamageValue(19); data.add(named);
        var directory = java.nio.file.Files.createTempDirectory(java.nio.file.Path.of("."), "recovery-pool-");
        var type = com.kyanite.deeperdarker.content.DeadMansChestSavedData.TYPE;
        try (var storage = new net.minecraft.world.level.storage.SavedDataStorage(directory, helper.getLevel().getServer().getFixerUpper(), helper.getLevel().registryAccess())) {
            storage.set(type, data); storage.saveAndJoin();
        }
        try (var storage = new net.minecraft.world.level.storage.SavedDataStorage(directory, helper.getLevel().getServer().getFixerUpper(), helper.getLevel().registryAccess())) {
            var restored = storage.get(type);
            check(restored != null && restored.getList().size() == 3, "pool reloads from the real world data storage");
            check(restored.getList().get(2).getDamageValue() == 19 && restored.getList().get(2).getHoverName().getString().equals("Recovered sword"), "saved stack components survive disk round trip");
        }
        var output = net.minecraft.world.level.storage.TagValueOutput.createWithContext(net.minecraft.util.ProblemReporter.DISCARDING, helper.getLevel().registryAccess());
        output.store("item", net.minecraft.world.item.ItemStack.CODEC, named);
        var fossil = new net.minecraft.world.item.ItemStack(amber);
        net.minecraft.world.item.BlockItem.setBlockEntityData(fossil, net.minecraft.world.level.block.entity.BlockEntityTypes.CHEST, output);
        var lines = new java.util.ArrayList<net.minecraft.network.chat.Component>();
        amber.appendHoverText(fossil, net.minecraft.world.item.Item.TooltipContext.of(helper.getLevel()), net.minecraft.world.item.component.TooltipDisplay.DEFAULT, lines::add, net.minecraft.world.item.TooltipFlag.NORMAL);
        check(lines.stream().anyMatch(line -> line.getString().contains("Recovered sword")), "fossil item tooltip reads persisted loot components");
        helper.succeed();
        System.out.println("RECOVERY_FOSSIL_PASSED: safe stack merging, real disk persistence and fossil tooltip");
    }
    @net.fabricmc.fabric.api.gametest.v1.GameTest
    public void brewingAndEffects(net.minecraft.gametest.framework.GameTestHelper helper) {
        String[][] combinations = {
            {"minecraft:awkward", "deeperdarker:soul_crystal", "sculk_affinity"},
            {"minecraft:invisibility", "deeperdarker:soul_dust", "sculk_affinity"},
            {"deeperdarker:sculk_affinity", "minecraft:redstone", "long_sculk_affinity"},
            {"minecraft:long_invisibility", "deeperdarker:soul_dust", "long_sculk_affinity"},
            {"minecraft:water", "deeperdarker:fizz", "fizzy"},
            {"deeperdarker:fizzy", "deeperdarker:corruption_soul", "corruption"},
            {"deeperdarker:corruption", "minecraft:fermented_spider_eye", "purity"}
        };
        for (var container : java.util.List.of(net.minecraft.world.item.Items.POTION, net.minecraft.world.item.Items.SPLASH_POTION, net.minecraft.world.item.Items.LINGERING_POTION)) {
            for (var entry : combinations) {
                var potion = BuiltInRegistries.POTION.get(net.minecraft.resources.Identifier.parse(entry[0])).orElseThrow();
                var input = net.minecraft.world.item.alchemy.PotionContents.createItemStack(container, potion);
                var reagent = new net.minecraft.world.item.ItemStack(BuiltInRegistries.ITEM.getValue(net.minecraft.resources.Identifier.parse(entry[1])));
                var brewing = new net.minecraft.world.item.crafting.BrewingInput(input, reagent);
                var recipe = helper.getLevel().getServer().getRecipeManager().getRecipeFor(net.minecraft.world.item.crafting.RecipeType.BREWING, brewing, helper.getLevel()).orElseThrow();
                var result = recipe.value().assemble(brewing);
                check(result.is(container), "brewing preserves potion container");
                check(result.get(DataComponents.POTION_CONTENTS).potion().orElseThrow().unwrapKey().orElseThrow().identifier().toString().equals("deeperdarker:" + entry[2]), "brewing produces " + entry[2]);
                check(input.getCount() == 1 && reagent.getCount() == 1, "brewing recipe does not mutate inputs");
            }
        }
        var cow = helper.spawn(net.minecraft.world.entity.EntityTypes.COW, new net.minecraft.core.BlockPos(1, 2, 1));
        cow.setNoAi(true);
        com.kyanite.deeperdarker.content.DDEffects.CORRUPTION.value().applyInstantaneousEffect(helper.getLevel(), null, null, cow, 0, 1);
        check(cow.hasEffect(MobEffects.DARKNESS) && cow.hasEffect(MobEffects.WITHER), "corruption affects ordinary mobs");
        com.kyanite.deeperdarker.content.DDEffects.PURITY.value().applyInstantaneousEffect(helper.getLevel(), null, null, cow, 0, 1);
        check(!cow.hasEffect(MobEffects.DARKNESS) && !cow.hasEffect(MobEffects.WITHER), "purity removes corruption effects");
        var leech = helper.spawn(leechType, new net.minecraft.core.BlockPos(2, 2, 1)); leech.setNoAi(true);
        com.kyanite.deeperdarker.content.DDEffects.CORRUPTION.value().applyInstantaneousEffect(helper.getLevel(), null, null, leech, 0, 1);
        check(leech.hasEffect(MobEffects.REGENERATION), "corruption heals Sculk creatures");
        var pig = helper.spawn(net.minecraft.world.entity.EntityTypes.PIG, new net.minecraft.core.BlockPos(3, 2, 1));
        pig.setNoAi(true); pig.setCustomName(net.minecraft.network.chat.Component.literal("Conversion fixture"));
        pig.setItemSlot(net.minecraft.world.entity.EquipmentSlot.CHEST, new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.GOLDEN_CHESTPLATE));
        com.kyanite.deeperdarker.content.SculkConversionRegistry.addCorruptionConversion(net.minecraft.world.entity.EntityTypes.PIG,
                com.kyanite.deeperdarker.content.SculkConversionRegistry.directConversionToMob(net.minecraft.world.entity.EntityTypes.COW));
        check(com.kyanite.deeperdarker.content.SculkConversionRegistry.corruptionConversion(pig), "conversion registered");
        check(pig.isRemoved(), "old mob removed during conversion");
        var converted = helper.getLevel().getEntitiesOfClass(net.minecraft.world.entity.animal.cow.Cow.class, pig.getBoundingBox().inflate(2),
                mob -> mob.hasCustomName() && mob.getCustomName().getString().equals("Conversion fixture"));
        check(converted.size() == 1 && converted.getFirst().getItemBySlot(net.minecraft.world.entity.EquipmentSlot.CHEST).is(net.minecraft.world.item.Items.GOLDEN_CHESTPLATE), "conversion preserves name and equipment");
        cow.discard(); leech.discard(); converted.forEach(net.minecraft.world.entity.Entity::discard);
        helper.succeed();
        System.out.println("BREWING_EFFECTS_PASSED: all 21 recipes, effects, Sculk healing and real mob conversion");
    }
    private static Item item(String id, Item item) { return Registry.register(BuiltInRegistries.ITEM, DDRegistration.itemKey(id), item); }
    private static void check(boolean result, String message) { if (!result) throw new AssertionError(message); }
}
