package porttests;
import com.kyanite.deeperdarker.content.components.*;
import net.fabricmc.fabric.api.gametest.v1.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.InteractionHand;
import net.minecraft.core.component.DataComponents;
public final class ShieldAugmentSmoke {
    private static Item soul(String id) { return BuiltInRegistries.ITEM.getValue(Identifier.fromNamespaceAndPath("deeperdarker", id + "_soul")); }
    private static ItemStack shield() { var stack = new ItemStack(Items.SHIELD); DDItemProperties.setAugmented(stack); return stack; }
    private static void check(boolean value, String message) { if (!value) throw new AssertionError(message); }
    @GameTest
    public void componentsAndInventoryClicks(GameTestHelper helper) {
        var registries = helper.getLevel().registryAccess();
        var stack = shield();
        var augment = new ItemStack(soul("corruption"), 4);
        augment.set(DataComponents.CUSTOM_NAME, net.minecraft.network.chat.Component.literal("Kept soul"));
        check(ShieldAugments.add(stack, augment, registries), "valid augment rejected");
        check(augment.getCount() == 4 && ShieldAugments.read(stack).getCount() == 1, "insertion aliases input stack");
        check(!ShieldAugments.add(stack, new ItemStack(soul("virtue")), registries), "second augment accepted");
        var encoded = ItemStack.CODEC.encodeStart(registries.createSerializationContext(net.minecraft.nbt.NbtOps.INSTANCE), stack).getOrThrow();
        var decoded = ItemStack.CODEC.parse(registries.createSerializationContext(net.minecraft.nbt.NbtOps.INSTANCE), encoded).getOrThrow();
        check(ShieldAugments.read(decoded).getHoverName().getString().equals("Kept soul"), "saved augment lost components");
        var copy = ShieldAugments.read(decoded); copy.shrink(1);
        check(ShieldAugments.read(decoded).getCount() == 1, "read exposes mutable stored stack");
        check(ShieldAugments.remove(decoded, registries).orElseThrow().getCount() == 1 && ShieldAugments.read(decoded).isEmpty(), "removal failed");
        check(DDItemProperties.isAugmented(decoded), "removal lost augmented-shield upgrade");
        var legacy = shield(); var legacyData = new net.minecraft.nbt.CompoundTag();
        var oldItem = new net.minecraft.nbt.CompoundTag(); oldItem.putString("id", "deeperdarker:corruption_soul"); oldItem.putByte("Count", (byte) 1);
        legacyData.put("deeperdarker:item", oldItem); legacyData.putString("unrelated", "keep");
        legacy.set(DataComponents.CUSTOM_DATA, net.minecraft.world.item.component.CustomData.of(legacyData));
        var before = legacy.copy();
        check(ShieldAugments.read(legacy, registries).is(soul("corruption")), "legacy augment not readable");
        check(ItemStack.matches(before, legacy), "legacy read mutated shield");
        ShieldAugments.migrate(legacy, registries);
        check(legacy.has(DDDataComponents.AUGMENT_ITEM) && legacy.get(DataComponents.CUSTOM_DATA).copyTag().getStringOr("unrelated", "").equals("keep"), "legacy migration lost unrelated data");
        var player = helper.makeMockServerPlayerInLevel();
        var inventoryShield = shield(); var container = new net.minecraft.world.SimpleContainer(inventoryShield);
        var slot = new net.minecraft.world.inventory.Slot(container, 0, 0, 0);
        ItemStack[] cursor = {new ItemStack(soul("corruption"), 2)};
        var access = new SlotAccess() { public ItemStack get() { return cursor[0]; } public boolean set(ItemStack value) { cursor[0] = value; return true; } };
        check(Items.SHIELD.overrideOtherStackedOnMe(inventoryShield, cursor[0], slot, net.minecraft.world.inventory.ClickAction.SECONDARY, player, access), "right-click insertion was not handled");
        check(cursor[0].getCount() == 1 && ShieldAugments.read(inventoryShield).is(soul("corruption")), "inventory insertion duplicates or loses items");
        cursor[0] = ItemStack.EMPTY;
        check(Items.SHIELD.overrideOtherStackedOnMe(inventoryShield, cursor[0], slot, net.minecraft.world.inventory.ClickAction.SECONDARY, player, access), "right-click removal was not handled");
        check(cursor[0].is(soul("corruption")) && cursor[0].getCount() == 1 && ShieldAugments.read(inventoryShield).isEmpty(), "inventory removal duplicates or loses items");
        helper.succeed();
        System.out.println("SHIELD_STORAGE_PASSED: components, saved contents, independent copies, legacy migration and real inventory click hooks");
    }
    @GameTest
    public void attributesAndBlocking(GameTestHelper helper) {
        var player = helper.makeMockServerPlayerInLevel();
        helper.onEachTick(player::doTick);
        var registries = helper.getLevel().registryAccess();
        var shield = shield(); ShieldAugments.add(shield, new ItemStack(soul("corruption")), registries);
        player.setItemInHand(InteractionHand.OFF_HAND, shield);
        helper.runAfterDelay(2, () -> {
            player.doTick();
            check(Math.abs(player.getAttributeValue(Attributes.ATTACK_DAMAGE) - 2) < 0.0001, "held Corruption soul attack modifier");
            ShieldAugments.remove(shield, registries); ShieldAugments.add(shield, new ItemStack(soul("fortitude")), registries);
            player.doTick();
            check(Math.abs(player.getAttributeValue(Attributes.ATTACK_DAMAGE) - 1) < 0.0001, "replaced soul left attack modifier");
            check(player.getAttributeValue(Attributes.MOVEMENT_SPEED) < 0.11, "Fortitude applies before blocking");
            player.startUsingItem(InteractionHand.OFF_HAND);
            helper.runAfterDelay(8, () -> {
                player.doTick();
                check(player.isBlocking() && player.getAttributeValue(Attributes.MOVEMENT_SPEED) > 0.19, "Fortitude speed while blocking");
                player.stopUsingItem(); player.doTick();
                check(player.getAttributeValue(Attributes.MOVEMENT_SPEED) < 0.11, "Fortitude speed persists after blocking");
                ShieldAugments.remove(shield, registries); ShieldAugments.add(shield, new ItemStack(soul("virtue")), registries);
                var pos = helper.absolutePos(new net.minecraft.core.BlockPos(2, 2, 2));
                player.setPos(net.minecraft.world.phys.Vec3.atBottomCenterOf(pos)); player.setYRot(0); player.setYHeadRot(0);
                player.startUsingItem(InteractionHand.OFF_HAND);
                helper.runAfterDelay(8, () -> {
                    player.doTick(); player.setHealth(10);
                    var warden = helper.spawn(EntityTypes.WARDEN, new net.minecraft.core.BlockPos(2, 2, 3)); warden.setNoAi(true);
                    float previousHealth = warden.getHealth();
                    float blocked = player.applyItemBlocking(helper.getLevel(), helper.getLevel().damageSources().mobAttack(warden), 3);
                    check(blocked > 0, "test attack was not blocked");
                    check(player.getHealth() == 11 && warden.getHealth() == previousHealth - 4, "Virtue blocking heal and Sculk retaliation");
                    check(player.getAttributeValue(Attributes.ARMOR) >= 2, "Virtue armor modifier");
                    player.stopUsingItem(); player.setItemInHand(InteractionHand.OFF_HAND, ItemStack.EMPTY); player.doTick();
                    check(player.getAttributeValue(Attributes.ARMOR) == 0, "removed shield left armor modifier");
                    warden.discard(); helper.succeed();
                    System.out.println("SHIELD_BEHAVIOR_PASSED: actual attribute hooks, swap/removal, blocking speed, healing and Sculk retaliation");
                });
            });
        });
    }
}

