package porttests;

import com.kyanite.deeperdarker.content.DDEffects;
import com.kyanite.deeperdarker.content.blocks.Reinvokable;
import com.kyanite.deeperdarker.content.components.DDItemProperties;
import com.kyanite.deeperdarker.util.*;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.gametest.v1.GameTest;
import net.minecraft.core.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.*;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.decoration.painting.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.storage.loot.*;
import java.util.*;

public final class GameplayRulesSmoke implements ModInitializer {
    public void onInitialize() { DDLootItemFunctions.init(); }
    private static void check(boolean ok,String message) { if(!ok)throw new AssertionError(message); }
    @GameTest
    public void ancientPaintingLootAndDrops(GameTestHelper helper) {
        var level=helper.getLevel();
        var variants=level.registryAccess().lookupOrThrow(Registries.PAINTING_VARIANT).getOrThrow(DDTags.Paintings.ANCIENT);
        check(variants.size()==9,"lost original ancient painting variants");
        var maze=level.registryAccess().lookupOrThrow(Registries.PAINTING_VARIANT).getOrThrow(net.minecraft.resources.ResourceKey.create(Registries.PAINTING_VARIANT,Identifier.fromNamespaceAndPath("deeperdarker","maze")));
        check(maze.value().width()==4&&maze.value().height()==3,"painting dimensions are not in blocks");
        var params=new LootParams.Builder(level).create(net.minecraft.world.level.storage.loot.parameters.LootContextParamSets.EMPTY);
        var context=new LootContext.Builder(params).withOptionalRandomSeed(9123).create(Optional.empty());
        var function=SetPaintingVariantFunction.withTag(DDTags.Paintings.ANCIENT).build();
        Set<Holder<PaintingVariant>> seen=new HashSet<>();
        for(int i=0;i<100;i++) {
            var stack=new ItemStack(Items.PAINTING);function.apply(stack,context);
            var variant=stack.get(DataComponents.PAINTING_VARIANT);
            check(variant!=null&&variant.is(DDTags.Paintings.ANCIENT),"painting loot missing typed ancient variant");seen.add(variant);
        }
        check(seen.size()==9,"painting pool is restricted unexpectedly");
        var unrelated=new ItemStack(Items.STICK);function.apply(unrelated,context);
        check(!unrelated.has(DataComponents.PAINTING_VARIANT),"painting function changed another item");
        var emptyTag=net.minecraft.tags.TagKey.create(Registries.PAINTING_VARIANT,Identifier.fromNamespaceAndPath("port_items_test","empty_paintings"));
        var emptyStack=new ItemStack(Items.PAINTING);SetPaintingVariantFunction.withTag(emptyTag).build().apply(emptyStack,context);
        check(!emptyStack.has(DataComponents.PAINTING_VARIANT),"empty painting selection should preserve the input");
        var painting=new Painting(level,helper.absolutePos(new BlockPos(2,3,2)),Direction.NORTH,maze);
        check(painting.getPickResult().get(DataComponents.PAINTING_VARIANT).equals(maze),"middle click lost ancient painting");
        painting.dropItem(level,null);
        var drops=level.getEntitiesOfClass(net.minecraft.world.entity.item.ItemEntity.class,painting.getBoundingBox().inflate(2),
                drop -> maze.equals(drop.getItem().get(DataComponents.PAINTING_VARIANT)));
        check(drops.size()==1,"breaking an ancient painting lost its variant");drops.forEach(Entity::discard);
        helper.succeed();
        System.out.println("PAINTING_PORT_PASSED: nine loaded variants, original sizes, random/tagged loot, empty-tag handling, pick result and actual item drop");
    }
    @GameTest
    public void resonariumHemophiliaAndReinvoked(GameTestHelper helper) {
        var level=helper.getLevel();var player=helper.makeMockServerPlayerInLevel();
        player.setGameMode(net.minecraft.world.level.GameType.SURVIVAL);
        player.setHealth(10);player.getFoodData().setFoodLevel(20);player.getFoodData().setSaturation(10);
        player.addEffect(new net.minecraft.world.effect.MobEffectInstance(DDEffects.HEMOPHILIA,200));
        for(int i=0;i<20;i++)player.getFoodData().tick(player);
        check(player.getHealth()==10,"Hemophilia allowed natural regeneration");
        player.removeEffect(DDEffects.HEMOPHILIA);
        for(int i=0;i<20;i++)player.getFoodData().tick(player);
        check(player.getHealth()>10,"natural regeneration did not return after Hemophilia");
        var armor=new ItemStack(BuiltInRegistries.ITEM.getValue(Identifier.fromNamespaceAndPath("deeperdarker","port_smoke_resonarium")));
        var cow=helper.spawn(EntityTypes.COW,new BlockPos(1,2,1));cow.setNoAi(true);
        cow.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH).setBaseValue(40);cow.setHealth(40);
        cow.setItemSlot(EquipmentSlot.CHEST,armor);
        check(cow.hurtServer(level,level.damageSources().playerAttack(player),8),"Resonarium damage test rejected");
        check(cow.getHealth()>32&&armor.getDamageValue()>=5,"Resonarium failed to reduce damage or consume durability: " + cow.getHealth()+"/"+armor.getDamageValue());cow.discard();
        var reinvoked=new ItemStack(Items.STICK);var old=new net.minecraft.nbt.CompoundTag();old.putBoolean("reinvoked",true);old.putString("other","keep");
        reinvoked.set(DataComponents.CUSTOM_DATA,net.minecraft.world.item.component.CustomData.of(old));
        check(((Reinvokable)(Object)reinvoked).deeperdarker$isReinvoked(),"legacy reinvoked marker unreadable");
        ((Reinvokable)(Object)reinvoked).deeperdarker$setReinvoked(false);
        check(!DDItemProperties.isReinvoked(reinvoked)&&reinvoked.get(DataComponents.CUSTOM_DATA).copyTag().getStringOr("other","").equals("keep"),"reinvoked migration changed unrelated data");
        ((Reinvokable)(Object)reinvoked).deeperdarker$setReinvoked(true);
        var tooltip=reinvoked.getTooltipLines(Item.TooltipContext.of(level),player,TooltipFlag.NORMAL);
        check(tooltip.stream().anyMatch(line -> line.getContents() instanceof net.minecraft.network.chat.contents.TranslatableContents t && t.getKey().equals("tooltips.deeperdarker.reinvoked")),"reinvoked tooltip hook");
        helper.succeed();System.out.println("GAMEPLAY_RULES_PASSED: actual Hemophilia regeneration hook, Resonarium reduction/durability, legacy and typed reinvoked flags and tooltip");
    }
}
