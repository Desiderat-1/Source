package porttests;

import com.kyanite.deeperdarker.world.*;
import com.kyanite.deeperdarker.content.blocks.SculkTissueBlock;
import com.kyanite.deeperdarker.util.DDRegistration;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.gametest.v1.GameTest;
import net.minecraft.core.*;
import net.minecraft.core.registries.*;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.resources.Identifier;
import net.minecraft.util.RandomSource;
import net.minecraft.util.valueproviders.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.chunk.*;
import net.minecraft.world.level.levelgen.*;
import net.minecraft.world.level.levelgen.carver.*;
import net.minecraft.world.level.levelgen.heightproviders.ConstantHeight;
import java.util.*;

public final class CarverPortSmoke implements ModInitializer {
    private static Block tissue;
    public void onInitialize() {
        tissue = Registry.register(BuiltInRegistries.BLOCK, DDRegistration.blockKey("sculk_tissue"),
                new SculkTissueBlock(DDRegistration.blockProperties("sculk_tissue", net.minecraft.world.level.block.state.BlockBehaviour.Properties.ofFullCopy(Blocks.SCULK))));
        DDCarvers.init();
    }
    private static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    @GameTest
    public void registryAndTissueVeins(GameTestHelper helper) {
        var level=helper.getLevel();
        var carvers=level.registryAccess().lookupOrThrow(Registries.CARVER);
        for(var key:List.of(DDCarvers.CONFIGURED_CAVE,DDCarvers.CONFIGURED_LARGE_CAVE,DDCarvers.CONFIGURED_LOW_CAVE))
            check(carvers.getOrThrow(key).value() instanceof CaveWorldCarver,"cave resource failed to load: "+key);
        var loaded=(DDNoodleCarver)carvers.getOrThrow(DDCarvers.CONFIGURED_NOODLES).value();
        check(loaded.fill().is(tissue) && loaded.shape().probability()==0.22F,"noodle configuration lost original probability or tissue");
        var ops=level.registryAccess().createSerializationContext(net.minecraft.nbt.NbtOps.INSTANCE);
        var roundTrip=WorldCarver.DIRECT_CODEC.parse(ops,WorldCarver.DIRECT_CODEC.encodeStart(ops,loaded).getOrThrow()).getOrThrow();
        check(WorldCarver.DIRECT_CODEC.encodeStart(ops,roundTrip).getOrThrow().equals(WorldCarver.DIRECT_CODEC.encodeStart(ops,loaded).getOrThrow()),"noodle codec round trip");
        var shape=new CaveWorldCarver(1,ConstantHeight.of(VerticalAnchor.absolute(24)),ConstantInt.of(12),ConstantFloat.of(3),
                false,ConstantFloat.of(1),ConstantFloat.of(1),ConstantFloat.of(1),ConstantFloat.of(1),ConstantFloat.of(-0.8F));
        var noodle=new DDNoodleCarver(shape,loaded.replaceable(),loaded.fill());
        var target=new ChunkPos(-7,11);
        var height=LevelHeightAccessor.create(0,64);
        var chunk=new ProtoChunk(target,UpgradeData.EMPTY,height,PalettedContainerFactory.create(level.registryAccess()),null);
        var context=new WorldGenerationContext(level.getChunkSource().getGenerator(),height);
        var before=new HashMap<BlockPos,net.minecraft.world.level.block.state.BlockState>();
        for(var pos:BlockPos.betweenClosed(target.getMinBlockX(),0,target.getMinBlockZ(),target.getMaxBlockX(),63,target.getMaxBlockZ())) {
            var state=(pos.getX()&3)==0?Blocks.BEDROCK.defaultBlockState():(pos.getX()&3)==1?Blocks.AIR.defaultBlockState():Blocks.DEEPSLATE.defaultBlockState();
            chunk.setBlockState(pos,state,0); before.put(pos.immutable(),state);
        }
        Set<BlockPos> requested=new HashSet<>();
        CarverOutput recorder=new CarverOutput(){
            public int minY(){return 1;} public int maxY(){return 56;}
            public void carve(int x,int y,int z){requested.add(new BlockPos(target.getMinBlockX()+x,y,target.getMinBlockZ()+z));}
        };
        var airMask=new CarvingMask(1,56);
        shape.carve(context,RandomSource.create(1234),target,target,recorder);
        noodle.carve(context,RandomSource.create(1234),target,target,new DDChunkCarverOutput(chunk,airMask));
        int filledAir=0,filledStone=0,protectedCount=0;
        for(var entry:before.entrySet()) {
            var pos=entry.getKey();var previous=entry.getValue();var actual=chunk.getBlockState(pos);
            if(requested.contains(pos) && (previous.isAir()||previous.is(noodle.replaceable()))) {
                check(actual.is(tissue),"vein left air or failed to fill at "+pos);
                if(previous.isAir())filledAir++;else filledStone++;
            } else check(actual.equals(previous),"vein changed protected or unrequested block at "+pos);
            if(requested.contains(pos)&&previous.is(Blocks.BEDROCK))protectedCount++;
        }
        check(filledAir>0&&filledStone>0&&protectedCount>0,"fixture did not exercise air, replaceable stone and protected blocks");
        check(airMask.isEmpty(),"tissue vein also queued air excavation");
        helper.succeed();
        System.out.println("CARVER_PORT_PASSED: four real registry codecs, deterministic cave geometry, air/tissue filling, protected blocks, negative chunk coordinates and empty air mask");
    }
}
