package porttests;

import com.kyanite.deeperdarker.content.fluids.EntityInAcid;
import com.kyanite.deeperdarker.content.components.DDItemProperties;
import com.kyanite.deeperdarker.util.*;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.gametest.v1.GameTest;
import net.minecraft.core.*;
import net.minecraft.core.registries.*;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.item.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.material.*;

/** A real native fluid fixture exercises the actual acid entity/AI/movement Mixins.
 * The separate AcidFluid bucket/spread implementation is outside this test's scope. */
public final class AcidPortSmoke implements ModInitializer {
    private static FlowingFluid source,flowing;private static Block liquid;
    public void onInitialize(){
        source=Registry.register(BuiltInRegistries.FLUID,Identifier.fromNamespaceAndPath("port_items_test","acid"),new Source());
        flowing=Registry.register(BuiltInRegistries.FLUID,Identifier.fromNamespaceAndPath("port_items_test","flowing_acid"),new Flowing());
        liquid=Registry.register(BuiltInRegistries.BLOCK,DDRegistration.blockKey("port_acid"),new LiquidBlock(source,
                DDRegistration.blockProperties("port_acid",net.minecraft.world.level.block.state.BlockBehaviour.Properties.ofFullCopy(Blocks.WATER))));
    }
    public abstract static class AcidFixtureFluid extends WaterFluid {
        public Fluid getFlowing(){return flowing;}public Fluid getSource(){return source;}
        public boolean isSame(Fluid fluid){return fluid==source||fluid==flowing;}
        public net.minecraft.world.level.block.state.BlockState createLegacyBlock(FluidState state){return liquid.defaultBlockState().setValue(LiquidBlock.LEVEL,getLegacyLevel(state));}
    }
    public static final class Source extends AcidFixtureFluid {
        public int getAmount(FluidState state){return 8;}public boolean isSource(FluidState state){return true;}
    }
    public static final class Flowing extends AcidFixtureFluid {
        protected void createFluidStateDefinition(net.minecraft.world.level.block.state.StateDefinition.Builder<Fluid,FluidState> builder){super.createFluidStateDefinition(builder);builder.add(LEVEL);}
        public int getAmount(FluidState state){return state.getValue(LEVEL);}public boolean isSource(FluidState state){return false;}
    }
    private static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    @GameTest
    public void damageImmunityAndSwimming(GameTestHelper helper){
        var level=helper.getLevel();var origin=helper.absolutePos(new BlockPos(3,2,3));
        for(var pos:BlockPos.betweenClosed(origin.offset(-2,-1,-2),origin.offset(2,2,2)))
            level.setBlock(pos,(pos.getY()<origin.getY()||Math.abs(pos.getX()-origin.getX())==2||Math.abs(pos.getZ()-origin.getZ())==2)?Blocks.STONE.defaultBlockState():liquid.defaultBlockState(),3);
        var cow=helper.spawn(EntityTypes.COW,new BlockPos(3,2,3));cow.setNoAi(true);cow.setNoGravity(true);
        cow.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH).setBaseValue(40);cow.setHealth(40);
        cow.tick();cow.tick();
        check(((EntityInAcid)cow).deeperdarker$isInAcid()&&cow.getFluidHeight(DDTags.Fluids.ACID)>0,"custom fluid was not tracked by native EntityFluidInteraction");
        check(cow.getHealth()==35,"acid damage not applied: "+cow.getHealth());
        check(new FloatGoal(cow).canUse(),"float AI does not recognize acid");
        cow.setDeltaMovement(0.2,0,0);cow.travel(new net.minecraft.world.phys.Vec3(0,0,0));
        check(cow.getDeltaMovement().x<0.15,"acid movement drag not applied");
        cow.setItemSlot(EquipmentSlot.FEET,new ItemStack(Items.NETHERITE_BOOTS));
        check(cow.getItemBySlot(EquipmentSlot.FEET).is(DDTags.Items.ACID_IMMUNE_ARMOR),"fixture immunity tag missing");
        cow.setInvulnerableTime(0);cow.tick();check(cow.getHealth()==35,"original equipped armor immunity was lost");
        var protectedStack=new ItemStack(Items.STICK);DDItemProperties.setAcidResistant(protectedStack);
        var item=new ItemEntity(level,origin.getX()+0.5,origin.getY()+0.5,origin.getZ()+0.5,protectedStack);level.addFreshEntity(item);
        item.tick();item.tick();check(item.isAlive()&&((EntityInAcid)item).deeperdarker$acidImmune(),"acid-resistant item was destroyed");
        item.discard();cow.discard();helper.succeed();
        System.out.println("ACID_ENTITY_PORT_PASSED: native fluid tracking, real damage, armor/item immunity, FloatGoal and movement drag; fluid spread/bucket implementation not covered");
    }
}
