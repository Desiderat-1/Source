package porttests;
import com.kyanite.deeperdarker.client.model.SculkLeechModel;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
public final class LeechModelSmoke {
    public static void main(String[] args) {
        ModelPoseSnapshots.verify();
        var root = SculkLeechModel.createBodyModel().bakeRoot();
        var model = new SculkLeechModel(root);
        var state = new LivingEntityRenderState();
        state.walkAnimationSpeed = 0.8F;
        state.walkAnimationPos = 3F;
        model.setupAnim(state);
        var head = root.getChild("root").getChild("head");
        if (Math.abs(head.yRot) < 0.0001F) throw new AssertionError("Walk animation did not move the head");
        float angle = head.yRot;
        model.setupAnim(state);
        if (Math.abs(head.yRot - angle) > 0.00001F) throw new AssertionError("Animation accumulated between frames");
        state.walkAnimationSpeed = 0;
        model.setupAnim(state);
        if (Math.abs(head.yRot) > 0.00001F) throw new AssertionError("Idle pose did not reset");
        System.out.println("LEECH_MODEL_PASSED: original mesh bakes, walk animation, deterministic frame reset and idle pose");
    }
}
