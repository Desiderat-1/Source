package porttests;
import com.kyanite.deeperdarker.util.DDLegacyBlockStateCodec;
import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import net.minecraft.nbt.*;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.core.Direction;
public final class LegacyBlockStateSmoke {
    public static void verify() {
        var legacy = new CompoundTag(); legacy.putString("Name", "minecraft:oak_log");
        var properties = new CompoundTag(); properties.putString("axis", "x"); legacy.put("Properties", properties);
        var before = legacy.copy();
        var state = DDLegacyBlockStateCodec.CODEC.parse(NbtOps.INSTANCE, legacy).getOrThrow();
        if (!state.is(Blocks.OAK_LOG) || state.getValue(BlockStateProperties.AXIS) != Direction.Axis.X) throw new AssertionError("Legacy state properties lost");
        if (!legacy.equals(before)) throw new AssertionError("Legacy palette NBT mutated");
        var encoded = DDLegacyBlockStateCodec.CODEC.encodeStart(JsonOps.INSTANCE, state).getOrThrow().getAsJsonObject();
        if (!encoded.has("id") || encoded.has("Name") || !encoded.has("properties")) throw new AssertionError("Did not write modern state format");
        if (DDLegacyBlockStateCodec.CODEC.parse(JsonOps.INSTANCE, encoded).getOrThrow() != state) throw new AssertionError("Modern palette state round trip");
        var json = JsonParser.parseString("{\"Name\":\"minecraft:oak_log\",\"Properties\":{\"axis\":\"x\"}}");
        if (DDLegacyBlockStateCodec.CODEC.parse(JsonOps.INSTANCE, json).getOrThrow() != state) throw new AssertionError("Legacy JSON palette state");
        if (DDLegacyBlockStateCodec.CODEC.parse(JsonOps.INSTANCE, JsonParser.parseString("{\"id\":\"minecraft:missing_block_xyz\"}")).error().isEmpty()) throw new AssertionError("Unknown saved block silently replaced");
        System.out.println("LEGACY_BLOCK_STATE_PASSED: old NBT/JSON properties, modern writes, nonmutating reads and invalid-block rejection");
    }
}
