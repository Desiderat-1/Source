package porttests;

import com.kyanite.deeperdarker.client.model.DDHierarchicalModel;
import com.kyanite.deeperdarker.client.state.DDModelRenderState;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.world.entity.Entity;

final class ModelPoseSnapshots {
    private static final class TestModel extends DDHierarchicalModel<Entity> {
        final ModelPart head;
        TestModel(ModelPart root) { super(root); head = root.getChild("head"); }
        @Override public void setupAnim(Entity entity, float swing, float amount, float age, float yaw, float pitch) {
            head.yRot = yaw; head.xRot = pitch;
            head.visible = age > 1; head.skipDraw = amount == 0;
        }
    }
    static void verify() {
        MeshDefinition mesh = new MeshDefinition();
        mesh.getRoot().addOrReplaceChild("head", CubeListBuilder.create().addBox(0, 0, 0, 1, 1, 1), PartPose.ZERO);
        var root = LayerDefinition.create(mesh, 16, 16).bakeRoot();
        var model = new TestModel(root);
        var first = new DDModelRenderState(); first.yRot = 1; first.xRot = 0.25F; first.ageInTicks = 0;
        first.parts = model.capturePose(null, first);
        var second = new DDModelRenderState(); second.yRot = 2; second.xRot = -0.5F; second.ageInTicks = 5; second.walkAnimationSpeed = 1;
        second.parts = model.capturePose(null, second);
        model.setupAnim(first);
        check(model.head.yRot == 1 && model.head.xRot == 0.25F && !model.head.visible && model.head.skipDraw, "first pose was not isolated");
        model.setupAnim(second);
        check(model.head.yRot == 2 && model.head.xRot == -0.5F && model.head.visible && !model.head.skipDraw, "second pose did not restore state");
        boolean immutable = false;
        try { first.parts.clear(); } catch (UnsupportedOperationException expected) { immutable = true; }
        check(immutable, "captured poses must be immutable");
        System.out.println("MODEL_SNAPSHOTS_PASSED: independent captures, rotation, visibility, draw flags and immutable pose lists");
    }
    private static void check(boolean result, String message) { if (!result) throw new AssertionError(message); }
}
