package porttests;

import com.google.gson.JsonParser;
import com.kyanite.deeperdarker.client.item.DDItemModelProperties;
import com.mojang.serialization.JsonOps;
import net.minecraft.client.renderer.item.ClientItem;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ExtraCodecs;
import java.nio.file.*;

public final class ItemModelCodecSmoke {
    public static void main(String[] args) throws Exception {
        net.minecraft.SharedConstants.tryDetectVersion();
        net.minecraft.server.Bootstrap.bootStrap();
        LegacyBlockStateSmoke.verify();
        net.minecraft.client.renderer.item.ItemModels.bootstrap();
        net.minecraft.client.renderer.item.properties.conditional.ConditionalItemModelProperties.bootstrap();
        net.minecraft.client.renderer.item.properties.numeric.RangeSelectItemModelProperties.bootstrap();
        net.minecraft.client.renderer.item.properties.select.SelectItemModelProperties.bootstrap();
        net.minecraft.client.renderer.special.SpecialModelRenderers.bootstrap();
        net.minecraft.client.color.item.ItemTintSources.bootstrap();
        // This standalone codec test has no Mixin class loader. Install the same codecs
        // directly in the test JVM; production registration uses the compiled accessor.
        var field = net.minecraft.client.renderer.item.properties.conditional.ConditionalItemModelProperties.class.getDeclaredField("ID_MAPPER");
        field.setAccessible(true);
        @SuppressWarnings("unchecked")
        var mapper = (ExtraCodecs.LateBoundIdMapper<Identifier, com.mojang.serialization.MapCodec<? extends net.minecraft.client.renderer.item.properties.conditional.ConditionalItemModelProperty>>) field.get(null);
        mapper.put(Identifier.fromNamespaceAndPath("deeperdarker", "linked"), DDItemModelProperties.Linked.CODEC);
        mapper.put(Identifier.fromNamespaceAndPath("deeperdarker", "has_horns"), DDItemModelProperties.HasHorns.CODEC);
        int count = 0;
        try (var files = Files.list(Path.of(args[0]))) {
            for (Path file : files.filter(p -> p.toString().endsWith(".json")).sorted().toList()) {
                try (var reader = Files.newBufferedReader(file)) {
                    var decoded = ClientItem.CODEC.parse(JsonOps.INSTANCE, JsonParser.parseReader(reader));
                    if (decoded.error().isPresent()) throw new AssertionError(file.getFileName() + ": " + decoded.error().get().message());
                    count++;
                }
            }
        }
        if (count != 306) throw new AssertionError("Expected 306 item definitions, got " + count);
        System.out.println("ITEM_MODEL_CODECS_PASSED: all " + count + " modern item definitions decode using the real 26.3 codecs");
    }
}
