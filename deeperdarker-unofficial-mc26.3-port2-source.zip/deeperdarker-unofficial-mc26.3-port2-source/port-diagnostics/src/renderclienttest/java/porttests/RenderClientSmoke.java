package porttests;

import com.kyanite.deeperdarker.client.render.DDCrystalTrail;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public final class RenderClientSmoke implements ClientModInitializer {
    private boolean done;
    private int ticks;
    public void onInitializeClient(){
        var type=DDCrystalTrail.TYPE; // Register before shader/resource loading begins.
        ClientTickEvents.END_CLIENT_TICK.register(client->{
            if(done)return;
            if(++ticks>1200)throw new AssertionError("Client resource load did not complete");
            if(client.gui.overlay()!=null||client.gui.screen()==null||ticks<3)return;
            var compiled=RenderSystem.getCompiledPipeline(DDCrystalTrail.PIPELINE);
            if(compiled==null||compiled.isClosed())throw new AssertionError("Crystal trail shader not compiled");
            if(type.pipeline()!=DDCrystalTrail.PIPELINE)throw new AssertionError("Render type uses another pipeline");
            done=true;
            System.out.println("RENDER_CLIENT_PASSED: actual OpenGL shader compilation, Globals time/projection bindings, custom render type and client resource loading");
            client.stop();
        });
    }
}
