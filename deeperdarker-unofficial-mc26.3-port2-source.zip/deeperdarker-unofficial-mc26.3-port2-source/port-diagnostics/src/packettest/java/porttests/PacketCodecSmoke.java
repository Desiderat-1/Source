package porttests;

import com.kyanite.deeperdarker.network.*;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import net.minecraft.core.BlockPos;
import net.minecraft.network.codec.StreamCodec;

public final class PacketCodecSmoke {
    public static void main(String[] args) {
        roundTrip(SoulElytraBoostPacket.CODEC, new SoulElytraBoostPacket());
        roundTrip(UseTransmitterPacket.CODEC, new UseTransmitterPacket());
        roundTrip(UnlinkTransmitterPacket.CODEC, new UnlinkTransmitterPacket(0));
        roundTrip(UnlinkTransmitterPacket.CODEC, new UnlinkTransmitterPacket(40));
        roundTrip(LinkTransmitterPacket.CODEC, new LinkTransmitterPacket(40, new BlockPos(30_000_000, -64, -30_000_000)));
        roundTrip(LinkOwnedEntityPacket.CODEC, new LinkOwnedEntityPacket(1, 0));
        roundTrip(LinkOwnedEntityPacket.CODEC, new LinkOwnedEntityPacket(2_000_000, 3_000_000));
        ByteBuf truncated = Unpooled.buffer();
        try {
            truncated.writeByte(1);
            boolean rejected = false;
            try { UnlinkTransmitterPacket.CODEC.decode(truncated); } catch (IndexOutOfBoundsException expected) { rejected = true; }
            if (!rejected) throw new AssertionError("Truncated packet was not rejected");
        } finally { truncated.release(); }
        if (!LinkTransmitterPacket.TYPE.id().toString().equals("deeperdarker:link_transmitter")) throw new AssertionError("Packet ID changed");
        if (!LinkOwnedEntityPacket.TYPE.id().toString().equals("deeperdarker:link_owned_entity")) throw new AssertionError("Packet ID changed");
        System.out.println("PACKET_CODECS_PASSED: all five payloads, boundary coordinates, inventory slots, entity IDs, truncated payload rejection, stable packet identifiers");
    }
    private static <T> void roundTrip(StreamCodec<ByteBuf, T> codec, T value) {
        ByteBuf buffer = Unpooled.buffer();
        try {
            codec.encode(buffer, value);
            T decoded = codec.decode(buffer);
            if (!value.equals(decoded) || buffer.readableBytes() != 0) throw new AssertionError("Packet round-trip mismatch: " + value);
        } finally { buffer.release(); }
    }
}
