package porttests;

import com.kyanite.deeperdarker.util.DDConfig;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ConfigMigrationSmoke {
    public static void main(String[] args) throws Exception {
        Path root = Path.of(args[0]);
        Files.createDirectories(root);
        Path defaults = Files.createTempDirectory(root, "defaults-");
        DDConfig config = DDConfig.load(defaults);
        check(config.server.soulElytraCooldown() == 600, "default cooldown");
        check(config.server.geyserLaunchVelocity() == 2.5F, "default velocity");
        check(config.server.addWardenDrops(), "default loot toggle");
        check(config.client.sculkTransmitterLinkCooldownSeconds() == 3, "default client setting");
        check(Files.isRegularFile(defaults.resolve("deeperdarker.json")), "default file saved");

        Path legacy = Files.createTempDirectory(root, "legacy-");
        String json5 = """
            {
                // A real JSON5 configuration with comments and trailing commas.
                server: { soulElytraCooldown: 75, addWardenDrops: false, geyserLaunchVelocity: 3.5, },
                client: { whiteFog: true, sculkTransmitterLinkCooldownSeconds: 7, },
            }
            """;
        Files.writeString(legacy.resolve("deeperdarker.json5"), json5);
        config = DDConfig.load(legacy);
        check(config.server.soulElytraCooldown() == 75, "legacy value preserved");
        check(!config.server.addWardenDrops(), "legacy boolean preserved");
        check(config.server.geyserLaunchVelocity() == 3.5F, "legacy float preserved");
        check(config.client.whiteFog(), "legacy client boolean preserved");
        check(config.client.sculkTransmitterLinkCooldownSeconds() == 7, "legacy client number preserved");
        check(config.server.sonorousStaffRange() == 40, "missing field keeps original default");
        check(Files.readString(legacy.resolve("deeperdarker.json5")).equals(json5), "legacy file must remain untouched");
        check(Files.isRegularFile(legacy.resolve("deeperdarker.json")), "canonical file created");
        config = DDConfig.load(legacy);
        check(config.server.soulElytraCooldown() == 75, "reload retains migrated value");

        Path limits = Files.createTempDirectory(root, "limits-");
        Files.writeString(limits.resolve("deeperdarker.json"), """
            {"server":{"soulElytraCooldown":-99,"sonorousStaffRange":9999,"spawnSomethingFromAncientVaseChance":4},
             "client":{"sculkTransmitterLinkCooldownSeconds":-3}}
            """);
        config = DDConfig.load(limits);
        check(config.server.soulElytraCooldown() == -1, "negative cooldown bound");
        check(config.server.sonorousStaffRange() == 512, "range upper bound");
        check(config.server.spawnSomethingFromAncientVaseChance() == 1F, "chance bound");
        check(config.client.sculkTransmitterLinkCooldownSeconds() == 0, "client lower bound");

        Path nullSections = Files.createTempDirectory(root, "null-sections-");
        Files.writeString(nullSections.resolve("deeperdarker.json"), "{\"server\":null,\"client\":null}");
        config = DDConfig.load(nullSections);
        check(config.server.soulElytraCooldown() == 600 && config.client.renderWardenHelmetHorns(), "null section defaults");

        Path invalid = Files.createTempDirectory(root, "invalid-");
        String broken = "{server: {broken";
        Files.writeString(invalid.resolve("deeperdarker.json"), broken);
        boolean rejected = false;
        try { DDConfig.load(invalid); } catch (IOException expected) { rejected = true; }
        check(rejected, "invalid configuration must be rejected");
        check(Files.readString(invalid.resolve("deeperdarker.json")).equals(broken), "invalid file must not be overwritten");
        System.out.println("CONFIG_MIGRATION_PASSED: defaults, JSON5 import, migration preservation, reload, validation bounds, null sections, invalid-file protection");
    }
    private static void check(boolean condition, String label) { if (!condition) throw new AssertionError(label); }
}
